/*     */ package com.swetake.util;
/*     */ 
/*     */ import B;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class Qrcode
/*     */ {
/*     */   static final String QRCODE_DATA_PATH = "qrcode_data";
/*  29 */   char qrcodeErrorCorrect = 'M';
/*  30 */   char qrcodeEncodeMode = 'B';
/*  31 */   int qrcodeVersion = 0;
/*     */ 
/*  33 */   int qrcodeStructureappendN = 0;
/*  34 */   int qrcodeStructureappendM = 0;
/*  35 */   int qrcodeStructureappendParity = 0;
/*  36 */   String qrcodeStructureappendOriginaldata = "";
/*     */ 
/*     */   public void setQrcodeErrorCorrect(char ecc)
/*     */   {
/*  45 */     this.qrcodeErrorCorrect = ecc;
/*     */   }
/*     */ 
/*     */   public char getQrcodeErrorCorrect()
/*     */   {
/*  54 */     return this.qrcodeErrorCorrect;
/*     */   }
/*     */ 
/*     */   public int getQrcodeVersion()
/*     */   {
/*  63 */     return this.qrcodeVersion;
/*     */   }
/*     */ 
/*     */   public void setQrcodeVersion(int ver)
/*     */   {
/*  73 */     if ((ver >= 0) && (ver <= 40))
/*  74 */       this.qrcodeVersion = ver;
/*     */   }
/*     */ 
/*     */   public void setQrcodeEncodeMode(char encMode)
/*     */   {
/*  85 */     this.qrcodeEncodeMode = encMode;
/*     */   }
/*     */ 
/*     */   public char getQrcodeEncodeMode()
/*     */   {
/*  94 */     return this.qrcodeEncodeMode;
/*     */   }
/*     */ 
/*     */   public void setStructureappend(int m, int n, int p)
/*     */   {
/* 103 */     if ((n > 1) && (n <= 16) && (m > 0) && (m <= 16) && (p >= 0) && (p <= 255)) {
/* 104 */       this.qrcodeStructureappendM = m;
/* 105 */       this.qrcodeStructureappendN = n;
/* 106 */       this.qrcodeStructureappendParity = p;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int calStructureappendParity(byte[] originaldata)
/*     */   {
/* 116 */     int i = 0;
/* 117 */     int structureappendParity = 0;
/*     */ 
/* 119 */     int originaldataLength = originaldata.length;
/*     */ 
/* 121 */     if (originaldataLength > 1) {
/* 122 */       structureappendParity = 0;
/* 123 */       while (i < originaldataLength) {
/* 124 */         structureappendParity ^= originaldata[i] & 0xFF;
/* 125 */         i++;
/*     */       }
/*     */     } else {
/* 128 */       structureappendParity = -1;
/*     */     }
/* 130 */     return structureappendParity;
/*     */   }
/*     */ 
/*     */   public boolean[][] calQrcode(byte[] qrcodeData)
/*     */   {
/* 141 */     int dataCounter = 0;
/*     */ 
/* 143 */     int dataLength = qrcodeData.length;
/*     */ 
/* 145 */     int[] dataValue = new int[dataLength + 32];
/* 146 */     byte[] dataBits = new byte[dataLength + 32];
/*     */ 
/* 148 */     if (dataLength <= 0) {
/* 149 */       boolean[][] ret = { new boolean[1] };
/* 150 */       return ret;
/*     */     }
/*     */ 
/* 153 */     if (this.qrcodeStructureappendN > 1) {
/* 154 */       dataValue[0] = 3;
/* 155 */       dataBits[0] = 4;
/*     */ 
/* 157 */       dataValue[1] = (this.qrcodeStructureappendM - 1);
/* 158 */       dataBits[1] = 4;
/*     */ 
/* 160 */       dataValue[2] = (this.qrcodeStructureappendN - 1);
/* 161 */       dataBits[2] = 4;
/*     */ 
/* 163 */       dataValue[3] = this.qrcodeStructureappendParity;
/* 164 */       dataBits[3] = 8;
/*     */ 
/* 166 */       dataCounter = 4;
/*     */     }
/* 168 */     dataBits[dataCounter] = 4;
/*     */     int[] codewordNumPlus;
/*     */     int codewordNumCounterValue;
/* 175 */     switch (this.qrcodeEncodeMode)
/*     */     {
/*     */     case 'A':
/* 181 */       int[] codewordNumPlus = { 
/* 182 */         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/* 183 */         4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 };
/*     */ 
/* 185 */       dataValue[dataCounter] = 2;
/* 186 */       dataCounter++;
/* 187 */       dataValue[dataCounter] = dataLength;
/* 188 */       dataBits[dataCounter] = 9;
/* 189 */       int codewordNumCounterValue = dataCounter;
/*     */ 
/* 191 */       dataCounter++;
/* 192 */       for (int i = 0; i < dataLength; i++) {
/* 193 */         char chr = (char)qrcodeData[i];
/* 194 */         byte chrValue = 0;
/* 195 */         if ((chr >= '0') && (chr < ':')) {
/* 196 */           chrValue = (byte)(chr - '0');
/*     */         }
/* 198 */         else if ((chr >= 'A') && (chr < '[')) {
/* 199 */           chrValue = (byte)(chr - '7');
/*     */         } else {
/* 201 */           if (chr == ' ') chrValue = 36;
/* 202 */           if (chr == '$') chrValue = 37;
/* 203 */           if (chr == '%') chrValue = 38;
/* 204 */           if (chr == '*') chrValue = 39;
/* 205 */           if (chr == '+') chrValue = 40;
/* 206 */           if (chr == '-') chrValue = 41;
/* 207 */           if (chr == '.') chrValue = 42;
/* 208 */           if (chr == '/') chrValue = 43;
/* 209 */           if (chr == ':') chrValue = 44;
/*     */         }
/*     */ 
/* 212 */         if (i % 2 == 0) {
/* 213 */           dataValue[dataCounter] = chrValue;
/* 214 */           dataBits[dataCounter] = 6;
/*     */         } else {
/* 216 */           dataValue[dataCounter] = (dataValue[dataCounter] * 45 + chrValue);
/* 217 */           dataBits[dataCounter] = 11;
/* 218 */           if (i < dataLength - 1) {
/* 219 */             dataCounter++;
/*     */           }
/*     */         }
/*     */       }
/* 223 */       dataCounter++;
/* 224 */       break;
/*     */     case 'N':
/* 229 */       int[] codewordNumPlus = { 
/* 230 */         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
/* 231 */         4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 };
/*     */ 
/* 233 */       dataValue[dataCounter] = 1;
/* 234 */       dataCounter++;
/* 235 */       dataValue[dataCounter] = dataLength;
/*     */ 
/* 237 */       dataBits[dataCounter] = 10;
/* 238 */       int codewordNumCounterValue = dataCounter;
/*     */ 
/* 240 */       dataCounter++;
/* 241 */       for (int i = 0; i < dataLength; i++)
/*     */       {
/* 243 */         if (i % 3 == 0) {
/* 244 */           qrcodeData[i] -= 48;
/* 245 */           dataBits[dataCounter] = 4;
/*     */         }
/*     */         else {
/* 248 */           dataValue[dataCounter] = (dataValue[dataCounter] * 10 + (qrcodeData[i] - 48));
/*     */ 
/* 250 */           if (i % 3 == 1) {
/* 251 */             dataBits[dataCounter] = 7;
/*     */           } else {
/* 253 */             dataBits[dataCounter] = 10;
/* 254 */             if (i < dataLength - 1) {
/* 255 */               dataCounter++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 260 */       dataCounter++;
/* 261 */       break;
/*     */     default:
/* 266 */       codewordNumPlus = new int[] { 
/* 267 */         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 
/* 268 */         8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 };
/* 269 */       dataValue[dataCounter] = 4;
/* 270 */       dataCounter++;
/* 271 */       dataValue[dataCounter] = dataLength;
/* 272 */       dataBits[dataCounter] = 8;
/* 273 */       codewordNumCounterValue = dataCounter;
/*     */ 
/* 275 */       dataCounter++;
/*     */ 
/* 277 */       for (int i = 0; i < dataLength; i++) {
/* 278 */         dataValue[(i + dataCounter)] = (qrcodeData[i] & 0xFF);
/* 279 */         dataBits[(i + dataCounter)] = 8;
/*     */       }
/* 281 */       dataCounter += dataLength;
/*     */     }
/*     */ 
/* 286 */     int totalDataBits = 0;
/* 287 */     for (int i = 0; i < dataCounter; i++)
/* 288 */       totalDataBits += dataBits[i];
/*     */     int ec;
/*     */     int ec;
/*     */     int ec;
/*     */     int ec;
/* 292 */     switch (this.qrcodeErrorCorrect) {
/*     */     case 'L':
/* 294 */       ec = 1;
/* 295 */       break;
/*     */     case 'Q':
/* 297 */       ec = 3;
/* 298 */       break;
/*     */     case 'H':
/* 300 */       ec = 2;
/* 301 */       break;
/*     */     default:
/* 303 */       ec = 0;
/*     */     }
/*     */ 
/* 307 */     int[][] maxDataBitsArray = { 
/* 308 */       { 0, 128, 224, 352, 512, 688, 864, 992, 1232, 1456, 1728, 
/* 309 */       2032, 2320, 2672, 2920, 3320, 3624, 4056, 4504, 5016, 5352, 
/* 310 */       5712, 6256, 6880, 7312, 8000, 8496, 9024, 9544, 10136, 10984, 
/* 311 */       11640, 12328, 13048, 13800, 14496, 15312, 15936, 16816, 17728, 18672 }, 
/* 313 */       { 0, 152, 272, 440, 640, 864, 1088, 1248, 1552, 1856, 2192, 
/* 314 */       2592, 2960, 3424, 3688, 4184, 4712, 5176, 5768, 6360, 6888, 
/* 315 */       7456, 8048, 8752, 9392, 10208, 10960, 11744, 12248, 13048, 13880, 
/* 316 */       14744, 15640, 16568, 17528, 18448, 19472, 20528, 21616, 22496, 23648 }, 
/* 318 */       { 0, 72, 128, 208, 288, 368, 480, 528, 688, 800, 976, 
/* 319 */       1120, 1264, 1440, 1576, 1784, 2024, 2264, 2504, 2728, 3080, 
/* 320 */       3248, 3536, 3712, 4112, 4304, 4768, 5024, 5288, 5608, 5960, 
/* 321 */       6344, 6760, 7208, 7688, 7888, 8432, 8768, 9136, 9776, 10208 }, 
/* 323 */       { 0, 104, 176, 272, 384, 496, 608, 704, 880, 1056, 1232, 
/* 324 */       1440, 1648, 1952, 2088, 2360, 2600, 2936, 3176, 3560, 3880, 
/* 325 */       4096, 4544, 4912, 5312, 5744, 6032, 6464, 6968, 7288, 7880, 
/* 326 */       8264, 8920, 9368, 9848, 10288, 10832, 11408, 12016, 12656, 13328 } };
/*     */ 
/* 329 */     int maxDataBits = 0;
/*     */ 
/* 331 */     if (this.qrcodeVersion == 0)
/*     */     {
/* 334 */       this.qrcodeVersion = 1;
/* 335 */       for (int i = 1; i <= 40; i++) {
/* 336 */         if (maxDataBitsArray[ec][i] >= totalDataBits + codewordNumPlus[this.qrcodeVersion]) {
/* 337 */           maxDataBits = maxDataBitsArray[ec][i];
/* 338 */           break;
/*     */         }
/* 340 */         this.qrcodeVersion += 1;
/*     */       }
/*     */     } else {
/* 343 */       maxDataBits = maxDataBitsArray[ec][this.qrcodeVersion];
/*     */     }
/* 345 */     totalDataBits += codewordNumPlus[this.qrcodeVersion];
/*     */     int tmp2431_2429 = codewordNumCounterValue;
/*     */     byte[] tmp2431_2427 = dataBits; tmp2431_2427[tmp2431_2429] = (byte)(tmp2431_2427[tmp2431_2429] + codewordNumPlus[this.qrcodeVersion]);
/*     */ 
/* 348 */     int[] maxCodewordsArray = { 0, 26, 44, 70, 100, 134, 172, 196, 242, 
/* 349 */       292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 
/* 350 */       1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 
/* 351 */       2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706 };
/*     */ 
/* 353 */     int maxCodewords = maxCodewordsArray[this.qrcodeVersion];
/* 354 */     int maxModules1side = 17 + (this.qrcodeVersion << 2);
/*     */ 
/* 356 */     int[] matrixRemainBit = { 0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 
/* 357 */       4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3 };
/*     */ 
/* 361 */     int byte_num = matrixRemainBit[this.qrcodeVersion] + (maxCodewords << 3);
/*     */ 
/* 363 */     byte[] matrixX = new byte[byte_num];
/* 364 */     byte[] matrixY = new byte[byte_num];
/* 365 */     byte[] maskArray = new byte[byte_num];
/* 366 */     byte[] formatInformationX2 = new byte[15];
/* 367 */     byte[] formatInformationY2 = new byte[15];
/* 368 */     byte[] rsEccCodewords = new byte[1];
/* 369 */     byte[] rsBlockOrderTemp = new byte[''];
/*     */     try
/*     */     {
/* 372 */       String filename = "qrcode_data/qrv" + Integer.toString(this.qrcodeVersion) + "_" + Integer.toString(ec) + ".dat";
/*     */ 
/* 374 */       InputStream fis = Qrcode.class.getResourceAsStream(filename);
/* 375 */       BufferedInputStream bis = new BufferedInputStream(fis);
/* 376 */       bis.read(matrixX);
/* 377 */       bis.read(matrixY);
/* 378 */       bis.read(maskArray);
/* 379 */       bis.read(formatInformationX2);
/* 380 */       bis.read(formatInformationY2);
/* 381 */       bis.read(rsEccCodewords);
/* 382 */       bis.read(rsBlockOrderTemp);
/* 383 */       bis.close();
/* 384 */       fis.close();
/*     */     } catch (Exception e) {
/* 386 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 389 */     byte rsBlockOrderLength = 1;
/* 390 */     for (byte i = 1; i < 128; i = (byte)(i + 1)) {
/* 391 */       if (rsBlockOrderTemp[i] == 0) {
/* 392 */         rsBlockOrderLength = i;
/* 393 */         break;
/*     */       }
/*     */     }
/* 396 */     byte[] rsBlockOrder = new byte[rsBlockOrderLength];
/* 397 */     System.arraycopy(rsBlockOrderTemp, 0, rsBlockOrder, 0, rsBlockOrderLength);
/*     */ 
/* 400 */     byte[] formatInformationX1 = { 0, 1, 2, 3, 4, 5, 7, 8, 8, 8, 8, 8, 8, 8, 8 };
/* 401 */     byte[] formatInformationY1 = { 8, 8, 8, 8, 8, 8, 8, 8, 7, 5, 4, 3, 2, 1 };
/*     */ 
/* 403 */     int maxDataCodewords = maxDataBits >> 3;
/*     */ 
/* 407 */     int modules1Side = 4 * this.qrcodeVersion + 17;
/* 408 */     int matrixTotalBits = modules1Side * modules1Side;
/* 409 */     byte[] frameData = new byte[matrixTotalBits + modules1Side];
/*     */     try
/*     */     {
/* 412 */       String filename = "qrcode_data/qrvfr" + Integer.toString(this.qrcodeVersion) + ".dat";
/*     */ 
/* 414 */       InputStream fis = Qrcode.class.getResourceAsStream(filename);
/* 415 */       BufferedInputStream bis = new BufferedInputStream(fis);
/* 416 */       bis.read(frameData);
/* 417 */       bis.close();
/* 418 */       fis.close();
/*     */     } catch (Exception e) {
/* 420 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 425 */     if (totalDataBits <= maxDataBits - 4) {
/* 426 */       dataValue[dataCounter] = 0;
/* 427 */       dataBits[dataCounter] = 4;
/*     */     }
/* 429 */     else if (totalDataBits < maxDataBits) {
/* 430 */       dataValue[dataCounter] = 0;
/* 431 */       dataBits[dataCounter] = (byte)(maxDataBits - totalDataBits);
/*     */     }
/* 433 */     else if (totalDataBits > maxDataBits) {
/* 434 */       System.out.println("overflow");
/*     */     }
/*     */ 
/* 438 */     byte[] dataCodewords = divideDataBy8Bits(dataValue, dataBits, maxDataCodewords);
/* 439 */     byte[] codewords = calculateRSECC(dataCodewords, rsEccCodewords[0], rsBlockOrder, maxDataCodewords, maxCodewords);
/*     */ 
/* 443 */     byte[][] matrixContent = new byte[modules1Side][modules1Side];
/*     */ 
/* 445 */     for (int i = 0; i < modules1Side; i++) {
/* 446 */       for (int j = 0; j < modules1Side; j++) {
/* 447 */         matrixContent[j][i] = 0;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 452 */     for (int i = 0; i < maxCodewords; i++)
/*     */     {
/* 454 */       byte codeword_i = codewords[i];
/* 455 */       for (int j = 7; j >= 0; j--)
/*     */       {
/* 457 */         int codewordBitsNumber = i * 8 + j;
/*     */ 
/* 459 */         matrixContent[(matrixX[codewordBitsNumber] & 0xFF)][(matrixY[codewordBitsNumber] & 0xFF)] = (byte)(255 * (codeword_i & 0x1) ^ maskArray[codewordBitsNumber]);
/*     */ 
/* 461 */         codeword_i = (byte)((codeword_i & 0xFF) >>> 1);
/*     */       }
/*     */     }
/*     */ 
/* 465 */     for (int matrixRemain = matrixRemainBit[this.qrcodeVersion]; matrixRemain > 0; matrixRemain--) {
/* 466 */       int remainBitTemp = matrixRemain + maxCodewords * 8 - 1;
/* 467 */       matrixContent[(matrixX[remainBitTemp] & 0xFF)][(matrixY[remainBitTemp] & 0xFF)] = (byte)(0xFF ^ maskArray[remainBitTemp]);
/*     */     }
/*     */ 
/* 471 */     byte maskNumber = selectMask(matrixContent, matrixRemainBit[this.qrcodeVersion] + maxCodewords * 8);
/* 472 */     byte maskContent = (byte)(1 << maskNumber);
/*     */ 
/* 476 */     byte formatInformationValue = (byte)(ec << 3 | maskNumber);
/*     */ 
/* 478 */     String[] formatInformationArray = { "101010000010010", "101000100100101", 
/* 479 */       "101111001111100", "101101101001011", "100010111111001", "100000011001110", 
/* 480 */       "100111110010111", "100101010100000", "111011111000100", "111001011110011", 
/* 481 */       "111110110101010", "111100010011101", "110011000101111", "110001100011000", 
/* 482 */       "110110001000001", "110100101110110", "001011010001001", "001001110111110", 
/* 483 */       "001110011100111", "001100111010000", "000011101100010", "000001001010101", 
/* 484 */       "000110100001100", "000100000111011", "011010101011111", "011000001101000", 
/* 485 */       "011111100110001", "011101000000110", "010010010110100", "010000110000011", 
/* 486 */       "010111011011010", "010101111101101" };
/*     */ 
/* 488 */     for (int i = 0; i < 15; i++)
/*     */     {
/* 490 */       byte content = Byte.parseByte(formatInformationArray[formatInformationValue].substring(i, i + 1));
/*     */ 
/* 492 */       matrixContent[(formatInformationX1[i] & 0xFF)][(formatInformationY1[i] & 0xFF)] = (byte)(content * 255);
/* 493 */       matrixContent[(formatInformationX2[i] & 0xFF)][(formatInformationY2[i] & 0xFF)] = (byte)(content * 255);
/*     */     }
/*     */ 
/* 497 */     boolean[][] out = new boolean[modules1Side][modules1Side];
/*     */ 
/* 499 */     int c = 0;
/* 500 */     for (int i = 0; i < modules1Side; i++) {
/* 501 */       for (int j = 0; j < modules1Side; j++)
/*     */       {
/* 503 */         if (((matrixContent[j][i] & maskContent) != 0) || (frameData[c] == 49))
/* 504 */           out[j][i] = 1;
/*     */         else {
/* 506 */           out[j][i] = 0;
/*     */         }
/* 508 */         c++;
/*     */       }
/* 510 */       c++;
/*     */     }
/*     */ 
/* 513 */     return out;
/*     */   }
/*     */ 
/*     */   private static byte[] divideDataBy8Bits(int[] data, byte[] bits, int maxDataCodewords)
/*     */   {
/* 528 */     int l1 = bits.length;
/*     */ 
/* 530 */     int codewordsCounter = 0;
/* 531 */     int remainingBits = 8;
/* 532 */     int max = 0;
/*     */ 
/* 537 */     data.length;
/*     */ 
/* 539 */     for (int i = 0; i < l1; i++) {
/* 540 */       max += bits[i];
/*     */     }
/* 542 */     int l2 = (max - 1) / 8 + 1;
/* 543 */     byte[] codewords = new byte[maxDataCodewords];
/* 544 */     for (int i = 0; i < l2; i++) {
/* 545 */       codewords[i] = 0;
/*     */     }
/* 547 */     for (int i = 0; i < l1; i++) {
/* 548 */       int buffer = data[i];
/* 549 */       int bufferBits = bits[i];
/* 550 */       boolean flag = true;
/*     */ 
/* 552 */       if (bufferBits == 0) {
/* 553 */         break;
/*     */       }
/*     */       do
/* 556 */         if (remainingBits > bufferBits) {
/* 557 */           codewords[codewordsCounter] = (byte)(codewords[codewordsCounter] << bufferBits | buffer);
/* 558 */           remainingBits -= bufferBits;
/* 559 */           flag = false;
/*     */         } else {
/* 561 */           bufferBits -= remainingBits;
/* 562 */           codewords[codewordsCounter] = (byte)(codewords[codewordsCounter] << remainingBits | buffer >> bufferBits);
/*     */ 
/* 564 */           if (bufferBits == 0) {
/* 565 */             flag = false;
/*     */           } else {
/* 567 */             buffer &= (1 << bufferBits) - 1;
/* 568 */             flag = true;
/*     */           }
/* 570 */           codewordsCounter++;
/* 571 */           remainingBits = 8;
/*     */         }
/* 555 */       while (flag);
/*     */     }
/*     */ 
/* 575 */     if (remainingBits != 8)
/* 576 */       codewords[codewordsCounter] = (byte)(codewords[codewordsCounter] << remainingBits);
/*     */     else {
/* 578 */       codewordsCounter--;
/*     */     }
/* 580 */     if (codewordsCounter < maxDataCodewords - 1) {
/* 581 */       boolean flag = true;
/* 582 */       while (codewordsCounter < maxDataCodewords - 1) {
/* 583 */         codewordsCounter++;
/* 584 */         if (flag)
/* 585 */           codewords[codewordsCounter] = -20;
/*     */         else {
/* 587 */           codewords[codewordsCounter] = 17;
/*     */         }
/* 589 */         flag = !flag;
/*     */       }
/*     */     }
/* 592 */     return codewords;
/*     */   }
/*     */ 
/*     */   private static byte[] calculateRSECC(byte[] codewords, byte rsEccCodewords, byte[] rsBlockOrder, int maxDataCodewords, int maxCodewords)
/*     */   {
/* 598 */     byte[][] rsCalTableArray = new byte[256][rsEccCodewords];
/*     */     try {
/* 600 */       String filename = "qrcode_data/rsc" + Byte.toString(rsEccCodewords) + ".dat";
/* 601 */       InputStream fis = Qrcode.class.getResourceAsStream(filename);
/* 602 */       BufferedInputStream bis = new BufferedInputStream(fis);
/* 603 */       for (int i = 0; i < 256; i++) {
/* 604 */         bis.read(rsCalTableArray[i]);
/*     */       }
/* 606 */       bis.close();
/* 607 */       fis.close();
/*     */     } catch (Exception e) {
/* 609 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 615 */     int i = 0;
/* 616 */     int j = 0;
/* 617 */     int rsBlockNumber = 0;
/*     */ 
/* 619 */     byte[][] rsTemp = new byte[rsBlockOrder.length][];
/* 620 */     byte[] res = new byte[maxCodewords];
/* 621 */     System.arraycopy(codewords, 0, res, 0, codewords.length);
/*     */ 
/* 623 */     i = 0;
/* 624 */     while (i < rsBlockOrder.length) {
/* 625 */       rsTemp[i] = new byte[(rsBlockOrder[i] & 0xFF) - rsEccCodewords];
/* 626 */       i++;
/*     */     }
/* 628 */     i = 0;
/* 629 */     while (i < maxDataCodewords) {
/* 630 */       rsTemp[rsBlockNumber][j] = codewords[i];
/* 631 */       j++;
/* 632 */       if (j >= (rsBlockOrder[rsBlockNumber] & 0xFF) - rsEccCodewords) {
/* 633 */         j = 0;
/* 634 */         rsBlockNumber++;
/*     */       }
/* 636 */       i++;
/*     */     }
/*     */ 
/* 641 */     rsBlockNumber = 0;
/* 642 */     while (rsBlockNumber < rsBlockOrder.length)
/*     */     {
/* 644 */       byte[] rsTempData = (byte[])rsTemp[rsBlockNumber].clone();
/*     */ 
/* 646 */       int rsCodewords = rsBlockOrder[rsBlockNumber] & 0xFF;
/* 647 */       int rsDataCodewords = rsCodewords - rsEccCodewords;
/*     */ 
/* 649 */       j = rsDataCodewords;
/* 650 */       while (j > 0) {
/* 651 */         byte first = rsTempData[0];
/* 652 */         if (first != 0) {
/* 653 */           byte[] leftChr = new byte[rsTempData.length - 1];
/* 654 */           System.arraycopy(rsTempData, 1, leftChr, 0, rsTempData.length - 1);
/* 655 */           byte[] cal = rsCalTableArray[(first & 0xFF)];
/* 656 */           rsTempData = calculateByteArrayBits(leftChr, cal, "xor");
/*     */         }
/* 658 */         else if (rsEccCodewords < rsTempData.length) {
/* 659 */           byte[] rsTempNew = new byte[rsTempData.length - 1];
/* 660 */           System.arraycopy(rsTempData, 1, rsTempNew, 0, rsTempData.length - 1);
/* 661 */           rsTempData = (byte[])rsTempNew.clone();
/*     */         } else {
/* 663 */           byte[] rsTempNew = new byte[rsEccCodewords];
/* 664 */           System.arraycopy(rsTempData, 1, rsTempNew, 0, rsTempData.length - 1);
/* 665 */           rsTempNew[(rsEccCodewords - 1)] = 0;
/* 666 */           rsTempData = (byte[])rsTempNew.clone();
/*     */         }
/*     */ 
/* 669 */         j--;
/*     */       }
/*     */ 
/* 672 */       System.arraycopy(rsTempData, 0, res, codewords.length + rsBlockNumber * rsEccCodewords, rsEccCodewords);
/* 673 */       rsBlockNumber++;
/*     */     }
/* 675 */     return res;
/*     */   }
/*     */ 
/*     */   private static byte[] calculateByteArrayBits(byte[] xa, byte[] xb, String ind)
/*     */   {
/*     */     byte[] xs;
/*     */     byte[] xl;
/*     */     byte[] xs;
/* 685 */     if (xa.length > xb.length) {
/* 686 */       byte[] xl = (byte[])xa.clone();
/* 687 */       xs = (byte[])xb.clone();
/*     */     } else {
/* 689 */       xl = (byte[])xb.clone();
/* 690 */       xs = (byte[])xa.clone();
/*     */     }
/* 692 */     int ll = xl.length;
/* 693 */     int ls = xs.length;
/* 694 */     byte[] res = new byte[ll];
/*     */ 
/* 696 */     for (int i = 0; i < ll; i++) {
/* 697 */       if (i < ls) {
/* 698 */         if (ind == "xor")
/* 699 */           res[i] = (byte)(xl[i] ^ xs[i]);
/*     */         else
/* 701 */           res[i] = (byte)(xl[i] | xs[i]);
/*     */       }
/*     */       else {
/* 704 */         res[i] = xl[i];
/*     */       }
/*     */     }
/* 707 */     return res;
/*     */   }
/*     */ 
/*     */   private static byte selectMask(byte[][] matrixContent, int maxCodewordsBitWithRemain) {
/* 711 */     int l = matrixContent.length;
/* 712 */     int[] d1 = new int[8];
/* 713 */     int[] d2 = new int[8];
/* 714 */     int[] d3 = new int[8];
/* 715 */     int[] d4 = new int[8];
/*     */ 
/* 717 */     int d2And = 0;
/* 718 */     int d2Or = 0;
/* 719 */     int[] d4Counter = new int[8];
/*     */ 
/* 721 */     for (int y = 0; y < l; y++) {
/* 722 */       int[] xData = new int[8];
/* 723 */       int[] yData = new int[8];
/* 724 */       boolean[] xD1Flag = new boolean[8];
/* 725 */       boolean[] yD1Flag = new boolean[8];
/*     */ 
/* 727 */       for (int x = 0; x < l; x++)
/*     */       {
/* 729 */         if ((x > 0) && (y > 0)) {
/* 730 */           d2And = matrixContent[x][y] & matrixContent[(x - 1)][y] & matrixContent[x][(y - 1)] & matrixContent[(x - 1)][(y - 1)] & 0xFF;
/*     */ 
/* 732 */           d2Or = matrixContent[x][y] & 0xFF | matrixContent[(x - 1)][y] & 0xFF | matrixContent[x][(y - 1)] & 0xFF | matrixContent[(x - 1)][(y - 1)] & 0xFF;
/*     */         }
/*     */ 
/* 735 */         for (int maskNumber = 0; maskNumber < 8; maskNumber++)
/*     */         {
/* 737 */           xData[maskNumber] = ((xData[maskNumber] & 0x3F) << 1 | (matrixContent[x][y] & 0xFF) >>> maskNumber & 0x1);
/*     */ 
/* 740 */           yData[maskNumber] = ((yData[maskNumber] & 0x3F) << 1 | (matrixContent[y][x] & 0xFF) >>> maskNumber & 0x1);
/*     */ 
/* 743 */           if ((matrixContent[x][y] & 1 << maskNumber) != 0) {
/* 744 */             d4Counter[maskNumber] += 1;
/*     */           }
/*     */ 
/* 748 */           if (xData[maskNumber] == 93) {
/* 749 */             d3[maskNumber] += 40;
/*     */           }
/*     */ 
/* 752 */           if (yData[maskNumber] == 93) {
/* 753 */             d3[maskNumber] += 40;
/*     */           }
/*     */ 
/* 756 */           if ((x > 0) && (y > 0))
/*     */           {
/* 758 */             if (((d2And & 0x1) != 0) || ((d2Or & 0x1) == 0)) {
/* 759 */               d2[maskNumber] += 3;
/*     */             }
/*     */ 
/* 762 */             d2And >>= 1;
/* 763 */             d2Or >>= 1;
/*     */           }
/*     */ 
/* 766 */           if (((xData[maskNumber] & 0x1F) == 0) || ((xData[maskNumber] & 0x1F) == 31)) {
/* 767 */             if (x > 3)
/* 768 */               if (xD1Flag[maskNumber] != 0) {
/* 769 */                 d1[maskNumber] += 1;
/*     */               } else {
/* 771 */                 d1[maskNumber] += 3;
/* 772 */                 xD1Flag[maskNumber] = true;
/*     */               }
/*     */           }
/*     */           else {
/* 776 */             xD1Flag[maskNumber] = false;
/*     */           }
/* 778 */           if (((yData[maskNumber] & 0x1F) == 0) || ((yData[maskNumber] & 0x1F) == 31)) {
/* 779 */             if (x > 3)
/* 780 */               if (yD1Flag[maskNumber] != 0) {
/* 781 */                 d1[maskNumber] += 1;
/*     */               } else {
/* 783 */                 d1[maskNumber] += 3;
/* 784 */                 yD1Flag[maskNumber] = true;
/*     */               }
/*     */           }
/*     */           else {
/* 788 */             yD1Flag[maskNumber] = false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 794 */     int minValue = 0;
/* 795 */     byte res = 0;
/* 796 */     int[] d4Value = { 90, 80, 70, 60, 50, 40, 30, 20, 10, 0, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 90 };
/* 797 */     for (int maskNumber = 0; maskNumber < 8; maskNumber++)
/*     */     {
/* 799 */       d4[maskNumber] = d4Value[(20 * d4Counter[maskNumber] / maxCodewordsBitWithRemain)];
/*     */ 
/* 801 */       int demerit = d1[maskNumber] + d2[maskNumber] + d3[maskNumber] + d4[maskNumber];
/*     */ 
/* 803 */       if ((demerit < minValue) || (maskNumber == 0)) {
/* 804 */         res = (byte)maskNumber;
/* 805 */         minValue = demerit;
/*     */       }
/*     */     }
/* 808 */     return res;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     com.swetake.util.Qrcode
 * JD-Core Version:    0.6.0
 */