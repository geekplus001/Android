/*   */ package jp.sourceforge.qrcode.exception;
/*   */ 
/*   */ public class FinderPatternNotFoundException extends Exception
/*   */ {
/* 3 */   String message = null;
/*   */ 
/* 5 */   public FinderPatternNotFoundException(String message) { this.message = message; }
/*   */ 
/*   */   public String getMessage() {
/* 8 */     return this.message;
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.exception.FinderPatternNotFoundException
 * JD-Core Version:    0.6.0
 */