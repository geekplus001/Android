/*   */ package jp.sourceforge.qrcode.exception;
/*   */ 
/*   */ public class InvalidVersionException extends VersionInformationException
/*   */ {
/*   */   String message;
/*   */ 
/*   */   public InvalidVersionException(String message)
/*   */   {
/* 5 */     this.message = message;
/*   */   }
/*   */   public String getMessage() {
/* 8 */     return this.message;
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.exception.InvalidVersionException
 * JD-Core Version:    0.6.0
 */