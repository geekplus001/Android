/*    */ package jp.sourceforge.qrcode.exception;
/*    */ 
/*    */ public class DecodingFailedException extends IllegalArgumentException
/*    */ {
/* 15 */   String message = null;
/*    */ 
/* 17 */   public DecodingFailedException(String message) { this.message = message; }
/*    */ 
/*    */   public String getMessage() {
/* 20 */     return this.message;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.exception.DecodingFailedException
 * JD-Core Version:    0.6.0
 */