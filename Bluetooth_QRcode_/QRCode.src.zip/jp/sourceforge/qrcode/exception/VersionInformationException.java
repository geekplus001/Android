package jp.sourceforge.qrcode.exception;

public class VersionInformationException extends IllegalArgumentException
{
}

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.exception.VersionInformationException
 * JD-Core Version:    0.6.0
 */