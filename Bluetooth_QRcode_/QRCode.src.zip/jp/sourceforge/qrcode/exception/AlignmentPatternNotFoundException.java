/*   */ package jp.sourceforge.qrcode.exception;
/*   */ 
/*   */ public class AlignmentPatternNotFoundException extends IllegalArgumentException
/*   */ {
/* 3 */   String message = null;
/*   */ 
/* 5 */   public AlignmentPatternNotFoundException(String message) { this.message = message; }
/*   */ 
/*   */   public String getMessage() {
/* 8 */     return this.message;
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.exception.AlignmentPatternNotFoundException
 * JD-Core Version:    0.6.0
 */