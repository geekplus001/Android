/*     */ package jp.sourceforge.qrcode.ecc;
/*     */ 
/*     */ public class BCH15_5
/*     */ {
/*     */   int[][] gf16;
/*     */   boolean[] receiveData;
/*     */   int numCorrectedError;
/*  99 */   static String[] bitName = { "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", 
/* 100 */     "d0", "d1", "d2", "d3", "d4" };
/*     */ 
/*     */   public BCH15_5(boolean[] source)
/*     */   {
/*   7 */     this.gf16 = createGF16();
/*   8 */     this.receiveData = source;
/*     */   }
/*     */ 
/*     */   public boolean[] correct()
/*     */   {
/*  13 */     int[] s = calcSyndrome(this.receiveData);
/*     */ 
/*  15 */     int[] errorPos = detectErrorBitPosition(s);
/*  16 */     boolean[] output = correctErrorBit(this.receiveData, errorPos);
/*  17 */     return output;
/*     */   }
/*     */ 
/*     */   int[][] createGF16() {
/*  21 */     this.gf16 = new int[16][4];
/*  22 */     int[] seed = { 1, 1 };
/*  23 */     for (int i = 0; i < 4; i++)
/*  24 */       this.gf16[i][i] = 1;
/*  25 */     for (int i = 0; i < 4; i++)
/*  26 */       this.gf16[4][i] = seed[i];
/*  27 */     for (int i = 5; i < 16; i++) {
/*  28 */       for (int j = 1; j < 4; j++) {
/*  29 */         this.gf16[i][j] = this.gf16[(i - 1)][(j - 1)];
/*     */       }
/*  31 */       if (this.gf16[(i - 1)][3] == 1) {
/*  32 */         for (int j = 0; j < 4; j++)
/*  33 */           this.gf16[i][j] = ((this.gf16[i][j] + seed[j]) % 2);
/*     */       }
/*     */     }
/*  36 */     return this.gf16;
/*     */   }
/*     */ 
/*     */   int searchElement(int[] x)
/*     */   {
/*  41 */     for (int k = 0; k < 15; k++) {
/*  42 */       if ((x[0] == this.gf16[k][0]) && 
/*  43 */         (x[1] == this.gf16[k][1]) && 
/*  44 */         (x[2] == this.gf16[k][2]) && 
/*  45 */         (x[3] == this.gf16[k][3]))
/*     */         break;
/*     */     }
/*  48 */     return k;
/*     */   }
/*     */ 
/*     */   int[] getCode(int input)
/*     */   {
/*  69 */     int[] f = new int[15];
/*  70 */     int[] r = new int[8];
/*     */ 
/*  72 */     for (int i = 0; i < 15; i++)
/*     */     {
/*  77 */       int w1 = r[7];
/*     */       int w2;
/*     */       int yin;
/*     */       int w2;
/*  78 */       if (i < 7) {
/*  79 */         int yin = (input >> 6 - i) % 2;
/*  80 */         w2 = (yin + w1) % 2;
/*     */       }
/*     */       else {
/*  83 */         yin = w1;
/*  84 */         w2 = 0;
/*     */       }
/*  86 */       r[7] = ((r[6] + w2) % 2);
/*  87 */       r[6] = ((r[5] + w2) % 2);
/*  88 */       r[5] = r[4];
/*  89 */       r[4] = ((r[3] + w2) % 2);
/*  90 */       r[3] = r[2];
/*  91 */       r[2] = r[1];
/*  92 */       r[1] = r[0];
/*  93 */       r[0] = w2;
/*  94 */       f[(14 - i)] = yin;
/*     */     }
/*  96 */     return f;
/*     */   }
/*     */ 
/*     */   int addGF(int arg1, int arg2)
/*     */   {
/* 117 */     int[] p = new int[4];
/* 118 */     for (int m = 0; m < 4; m++) {
/* 119 */       int w1 = (arg1 < 0) || (arg1 >= 15) ? 0 : this.gf16[arg1][m];
/* 120 */       int w2 = (arg2 < 0) || (arg2 >= 15) ? 0 : this.gf16[arg2][m];
/* 121 */       p[m] = ((w1 + w2) % 2);
/*     */     }
/* 123 */     return searchElement(p);
/*     */   }
/*     */ 
/*     */   int[] calcSyndrome(boolean[] y)
/*     */   {
/* 144 */     int[] s = new int[5];
/* 145 */     int[] p = new int[4];
/*     */ 
/* 147 */     for (int k = 0; k < 15; k++) {
/* 148 */       if (y[k] == 0) continue; for (int m = 0; m < 4; m++)
/* 149 */         p[m] = ((p[m] + this.gf16[k][m]) % 2);
/*     */     }
/* 151 */     k = searchElement(p);
/* 152 */     s[0] = (k >= 15 ? -1 : k);
/*     */ 
/* 158 */     s[1] = (s[0] < 0 ? -1 : s[0] * 2 % 15);
/*     */ 
/* 164 */     p = new int[4];
/* 165 */     for (k = 0; k < 15; k++) {
/* 166 */       if (y[k] == 0) continue; for (int m = 0; m < 4; m++) {
/* 167 */         p[m] = ((p[m] + this.gf16[(k * 3 % 15)][m]) % 2);
/*     */       }
/*     */     }
/* 170 */     k = searchElement(p);
/*     */ 
/* 172 */     s[2] = (k >= 15 ? -1 : k);
/*     */ 
/* 178 */     s[3] = (s[1] < 0 ? -1 : s[1] * 2 % 15);
/*     */ 
/* 184 */     p = new int[4];
/* 185 */     for (k = 0; k < 15; k++) {
/* 186 */       if (y[k] == 0) continue; for (int m = 0; m < 4; m++)
/* 187 */         p[m] = ((p[m] + this.gf16[(k * 5 % 15)][m]) % 2);
/*     */     }
/* 189 */     k = searchElement(p);
/* 190 */     s[4] = (k >= 15 ? -1 : k);
/*     */ 
/* 196 */     return s;
/*     */   }
/*     */ 
/*     */   int[] calcErrorPositionVariable(int[] s)
/*     */   {
/* 201 */     int[] e = new int[4];
/*     */ 
/* 203 */     e[0] = s[0];
/*     */ 
/* 207 */     int t = (s[0] + s[1]) % 15;
/* 208 */     int mother = addGF(s[2], t);
/* 209 */     mother = mother >= 15 ? -1 : mother;
/*     */ 
/* 211 */     t = (s[2] + s[1]) % 15;
/* 212 */     int child = addGF(s[4], t);
/* 213 */     child = child >= 15 ? -1 : child;
/* 214 */     e[1] = ((child < 0) && (mother < 0) ? -1 : (child - mother + 15) % 15);
/*     */ 
/* 219 */     t = (s[1] + e[0]) % 15;
/* 220 */     int t1 = addGF(s[2], t);
/* 221 */     t = (s[0] + e[1]) % 15;
/* 222 */     e[2] = addGF(t1, t);
/*     */ 
/* 225 */     return e;
/*     */   }
/*     */ 
/*     */   int[] detectErrorBitPosition(int[] s)
/*     */   {
/* 230 */     int[] e = calcErrorPositionVariable(s);
/* 231 */     int[] errorPos = new int[4];
/* 232 */     if (e[0] == -1)
/*     */     {
/* 234 */       return errorPos;
/*     */     }
/* 236 */     if (e[1] == -1)
/*     */     {
/* 240 */       errorPos[0] = 1;
/* 241 */       errorPos[1] = e[0];
/* 242 */       return errorPos;
/*     */     }
/*     */ 
/* 252 */     for (int i = 0; i < 15; i++)
/*     */     {
/* 254 */       int x3 = i * 3 % 15;
/* 255 */       int x2 = i * 2 % 15;
/* 256 */       int x1 = i;
/*     */ 
/* 260 */       int t = (e[0] + x2) % 15;
/* 261 */       int t1 = addGF(x3, t);
/*     */ 
/* 263 */       t = (e[1] + x1) % 15;
/* 264 */       int t2 = addGF(t, e[2]);
/*     */ 
/* 266 */       int anError = addGF(t1, t2);
/*     */ 
/* 268 */       if (anError < 15)
/*     */       {
/*     */         continue;
/*     */       }
/* 272 */       errorPos[0] += 1;
/* 273 */       errorPos[errorPos[0]] = i;
/*     */     }
/*     */ 
/* 277 */     return errorPos;
/*     */   }
/*     */ 
/*     */   boolean[] correctErrorBit(boolean[] y, int[] errorPos)
/*     */   {
/* 282 */     for (int i = 1; i <= errorPos[0]; i++) {
/* 283 */       y[errorPos[i]] = (y[errorPos[i]] != 0 ? 0 : true);
/*     */     }
/* 285 */     this.numCorrectedError = errorPos[0];
/*     */ 
/* 287 */     return y;
/*     */   }
/*     */ 
/*     */   public int getNumCorrectedError() {
/* 291 */     return this.numCorrectedError;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.ecc.BCH15_5
 * JD-Core Version:    0.6.0
 */