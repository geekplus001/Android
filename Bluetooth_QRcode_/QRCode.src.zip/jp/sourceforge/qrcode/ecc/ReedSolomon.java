/*     */ package jp.sourceforge.qrcode.ecc;
/*     */ 
/*     */ public class ReedSolomon
/*     */ {
/*     */   int[] y;
/*  13 */   int[] gexp = new int[512];
/*  14 */   int[] glog = new int[256];
/*     */   int NPAR;
/*     */   int MAXDEG;
/*     */   int[] synBytes;
/*     */   int[] Lambda;
/*     */   int[] Omega;
/*  29 */   int[] ErrorLocs = new int[256];
/*     */   int NErrors;
/*  33 */   int[] ErasureLocs = new int[256];
/*  34 */   int NErasures = 0;
/*     */ 
/*  36 */   boolean correctionSucceeded = true;
/*     */ 
/*     */   public ReedSolomon(int[] source, int NPAR) {
/*  39 */     initializeGaloisTables();
/*  40 */     this.y = source;
/*     */ 
/*  42 */     this.NPAR = NPAR;
/*  43 */     this.MAXDEG = (this.NPAR * 2);
/*  44 */     this.synBytes = new int[this.MAXDEG];
/*  45 */     this.Lambda = new int[this.MAXDEG];
/*  46 */     this.Omega = new int[this.MAXDEG];
/*     */   }
/*     */ 
/*     */   void initializeGaloisTables()
/*     */   {
/*     */     int p8;
/*     */     int p7;
/*     */     int p6;
/*     */     int p5;
/*     */     int p4;
/*     */     int p3;
/*     */     int p2;
/*  53 */     int pinit = p2 = p3 = p4 = p5 = p6 = p7 = p8 = 0;
/*  54 */     int p1 = 1;
/*     */ 
/*  56 */     this.gexp[0] = 1;
/*  57 */     this.gexp['ÿ'] = this.gexp[0];
/*  58 */     this.glog[0] = 0;
/*     */ 
/*  60 */     for (int i = 1; i < 256; i++) {
/*  61 */       pinit = p8;
/*  62 */       p8 = p7;
/*  63 */       p7 = p6;
/*  64 */       p6 = p5;
/*  65 */       p5 = p4 ^ pinit;
/*  66 */       p4 = p3 ^ pinit;
/*  67 */       p3 = p2 ^ pinit;
/*  68 */       p2 = p1;
/*  69 */       p1 = pinit;
/*  70 */       this.gexp[i] = (p1 + p2 * 2 + p3 * 4 + p4 * 8 + p5 * 16 + p6 * 32 + p7 * 64 + p8 * 128);
/*  71 */       this.gexp[(i + 255)] = this.gexp[i];
/*     */     }
/*     */ 
/*  74 */     for (i = 1; i < 256; i++)
/*  75 */       for (int z = 0; z < 256; z++)
/*  76 */         if (this.gexp[z] == i) {
/*  77 */           this.glog[i] = z;
/*  78 */           break;
/*     */         }
/*     */   }
/*     */ 
/*     */   int gmult(int a, int b)
/*     */   {
/*  88 */     if ((a == 0) || (b == 0)) return 0;
/*  89 */     int i = this.glog[a];
/*  90 */     int j = this.glog[b];
/*  91 */     return this.gexp[(i + j)];
/*     */   }
/*     */ 
/*     */   int ginv(int elt)
/*     */   {
/*  97 */     return this.gexp[(255 - this.glog[elt])];
/*     */   }
/*     */ 
/*     */   void decode_data(int[] data)
/*     */   {
/* 103 */     for (int j = 0; j < this.MAXDEG; j++) {
/* 104 */       int sum = 0;
/* 105 */       for (int i = 0; i < data.length; i++) {
/* 106 */         sum = data[i] ^ gmult(this.gexp[(j + 1)], sum);
/*     */       }
/* 108 */       this.synBytes[j] = sum;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void correct()
/*     */   {
/* 114 */     decode_data(this.y);
/* 115 */     this.correctionSucceeded = true;
/* 116 */     boolean hasError = false;
/* 117 */     for (int i = 0; i < this.synBytes.length; i++)
/*     */     {
/* 119 */       if (this.synBytes[i] != 0)
/* 120 */         hasError = true;
/*     */     }
/* 122 */     if (hasError)
/* 123 */       this.correctionSucceeded = correct_errors_erasures(this.y, this.y.length, 0, new int[1]);
/*     */   }
/*     */ 
/*     */   public boolean isCorrectionSucceeded() {
/* 127 */     return this.correctionSucceeded;
/*     */   }
/*     */   public int getNumCorrectedErrors() {
/* 130 */     return this.NErrors;
/*     */   }
/*     */ 
/*     */   void Modified_Berlekamp_Massey()
/*     */   {
/* 138 */     int[] psi = new int[this.MAXDEG];
/* 139 */     int[] psi2 = new int[this.MAXDEG];
/* 140 */     int[] D = new int[this.MAXDEG];
/* 141 */     int[] gamma = new int[this.MAXDEG];
/*     */ 
/* 144 */     init_gamma(gamma);
/*     */ 
/* 147 */     copy_poly(D, gamma);
/* 148 */     mul_z_poly(D);
/*     */ 
/* 150 */     copy_poly(psi, gamma);
/* 151 */     int k = -1; int L = this.NErasures;
/*     */ 
/* 153 */     for (int n = this.NErasures; n < 8; n++)
/*     */     {
/* 155 */       int d = compute_discrepancy(psi, this.synBytes, L, n);
/*     */ 
/* 157 */       if (d != 0)
/*     */       {
/* 160 */         for (int i = 0; i < this.MAXDEG; i++) psi[i] ^= gmult(d, D[i]);
/*     */ 
/* 163 */         if (L < n - k) {
/* 164 */           int L2 = n - k;
/* 165 */           k = n - L;
/*     */ 
/* 167 */           for (i = 0; i < this.MAXDEG; i++) D[i] = gmult(psi[i], ginv(d));
/* 168 */           L = L2;
/*     */         }
/*     */ 
/* 172 */         for (i = 0; i < this.MAXDEG; i++) psi[i] = psi2[i];
/*     */       }
/*     */ 
/* 175 */       mul_z_poly(D);
/*     */     }
/*     */ 
/* 178 */     for (int i = 0; i < this.MAXDEG; i++) this.Lambda[i] = psi[i];
/* 179 */     compute_modified_omega();
/*     */   }
/*     */ 
/*     */   void compute_modified_omega()
/*     */   {
/* 192 */     int[] product = new int[this.MAXDEG * 2];
/*     */ 
/* 194 */     mult_polys(product, this.Lambda, this.synBytes);
/* 195 */     zero_poly(this.Omega);
/* 196 */     for (int i = 0; i < this.NPAR; i++) this.Omega[i] = product[i];
/*     */   }
/*     */ 
/*     */   void mult_polys(int[] dst, int[] p1, int[] p2)
/*     */   {
/* 205 */     int[] tmp1 = new int[this.MAXDEG * 2];
/*     */ 
/* 207 */     for (int i = 0; i < this.MAXDEG * 2; i++) dst[i] = 0;
/*     */ 
/* 209 */     for (i = 0; i < this.MAXDEG; i++) {
/* 210 */       for (int j = this.MAXDEG; j < this.MAXDEG * 2; j++) tmp1[j] = 0;
/*     */ 
/* 213 */       for (j = 0; j < this.MAXDEG; j++) tmp1[j] = gmult(p2[j], p1[i]);
/*     */ 
/* 215 */       for (j = this.MAXDEG * 2 - 1; j >= i; j--) tmp1[j] = tmp1[(j - i)];
/* 216 */       for (j = 0; j < i; j++) tmp1[j] = 0;
/*     */ 
/* 219 */       for (j = 0; j < this.MAXDEG * 2; j++) dst[j] ^= tmp1[j];
/*     */     }
/*     */   }
/*     */ 
/*     */   void init_gamma(int[] gamma)
/*     */   {
/* 230 */     int[] tmp = new int[this.MAXDEG];
/*     */ 
/* 232 */     zero_poly(gamma);
/* 233 */     zero_poly(tmp);
/* 234 */     gamma[0] = 1;
/*     */ 
/* 236 */     for (int e = 0; e < this.NErasures; e++) {
/* 237 */       copy_poly(tmp, gamma);
/* 238 */       scale_poly(this.gexp[this.ErasureLocs[e]], tmp);
/* 239 */       mul_z_poly(tmp);
/* 240 */       add_polys(gamma, tmp);
/*     */     }
/*     */   }
/*     */ 
/*     */   void compute_next_omega(int d, int[] A, int[] dst, int[] src)
/*     */   {
/* 250 */     for (int i = 0; i < this.MAXDEG; i++)
/* 251 */       src[i] ^= gmult(d, A[i]);
/*     */   }
/*     */ 
/*     */   int compute_discrepancy(int[] lambda, int[] S, int L, int n)
/*     */   {
/* 260 */     int sum = 0;
/*     */ 
/* 262 */     for (int i = 0; i <= L; i++)
/* 263 */       sum ^= gmult(lambda[i], S[(n - i)]);
/* 264 */     return sum;
/*     */   }
/*     */ 
/*     */   void add_polys(int[] dst, int[] src)
/*     */   {
/* 272 */     for (int i = 0; i < this.MAXDEG; i++) dst[i] ^= src[i];
/*     */   }
/*     */ 
/*     */   void copy_poly(int[] dst, int[] src)
/*     */   {
/* 278 */     for (int i = 0; i < this.MAXDEG; i++) dst[i] = src[i];
/*     */   }
/*     */ 
/*     */   void scale_poly(int k, int[] poly)
/*     */   {
/* 284 */     for (int i = 0; i < this.MAXDEG; i++) poly[i] = gmult(k, poly[i]);
/*     */   }
/*     */ 
/*     */   void zero_poly(int[] poly)
/*     */   {
/* 291 */     for (int i = 0; i < this.MAXDEG; i++) poly[i] = 0;
/*     */   }
/*     */ 
/*     */   void mul_z_poly(int[] src)
/*     */   {
/* 299 */     for (int i = this.MAXDEG - 1; i > 0; i--) src[i] = src[(i - 1)];
/* 300 */     src[0] = 0;
/*     */   }
/*     */ 
/*     */   void Find_Roots()
/*     */   {
/* 314 */     this.NErrors = 0;
/*     */ 
/* 316 */     for (int r = 1; r < 256; r++) {
/* 317 */       int sum = 0;
/*     */ 
/* 319 */       for (int k = 0; k < this.NPAR + 1; k++) {
/* 320 */         sum ^= gmult(this.gexp[(k * r % 255)], this.Lambda[k]);
/*     */       }
/* 322 */       if (sum != 0)
/*     */         continue;
/* 324 */       this.ErrorLocs[this.NErrors] = (255 - r); this.NErrors += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean correct_errors_erasures(int[] codeword, int csize, int nerasures, int[] erasures)
/*     */   {
/* 353 */     this.NErasures = nerasures;
/* 354 */     for (int i = 0; i < this.NErasures; i++) this.ErasureLocs[i] = erasures[i];
/*     */ 
/* 356 */     Modified_Berlekamp_Massey();
/* 357 */     Find_Roots();
/*     */ 
/* 360 */     if ((this.NErrors <= this.NPAR) || (this.NErrors > 0))
/*     */     {
/* 363 */       for (int r = 0; r < this.NErrors; r++) {
/* 364 */         if (this.ErrorLocs[r] >= csize)
/*     */         {
/* 367 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 371 */       for (r = 0; r < this.NErrors; r++)
/*     */       {
/* 373 */         i = this.ErrorLocs[r];
/*     */ 
/* 376 */         int num = 0;
/* 377 */         for (int j = 0; j < this.MAXDEG; j++) {
/* 378 */           num ^= gmult(this.Omega[j], this.gexp[((255 - i) * j % 255)]);
/*     */         }
/*     */ 
/* 381 */         int denom = 0;
/* 382 */         for (j = 1; j < this.MAXDEG; j += 2) {
/* 383 */           denom ^= gmult(this.Lambda[j], this.gexp[((255 - i) * (j - 1) % 255)]);
/*     */         }
/*     */ 
/* 386 */         int err = gmult(num, ginv(denom));
/*     */ 
/* 389 */         codeword[(csize - i - 1)] ^= err;
/*     */       }
/*     */ 
/* 394 */       return true;
/*     */     }
/*     */ 
/* 399 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.ecc.ReedSolomon
 * JD-Core Version:    0.6.0
 */