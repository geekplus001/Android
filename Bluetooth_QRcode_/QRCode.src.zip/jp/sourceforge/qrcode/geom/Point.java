/*    */ package jp.sourceforge.qrcode.geom;
/*    */ 
/*    */ import jp.sourceforge.qrcode.util.QRCodeUtility;
/*    */ 
/*    */ public class Point
/*    */ {
/*    */   public static final int RIGHT = 1;
/*    */   public static final int BOTTOM = 2;
/*    */   public static final int LEFT = 4;
/*    */   public static final int TOP = 8;
/*    */   int x;
/*    */   int y;
/*    */ 
/*    */   public Point()
/*    */   {
/* 19 */     this.x = 0;
/* 20 */     this.y = 0;
/*    */   }
/*    */   public Point(int x, int y) {
/* 23 */     this.x = x;
/* 24 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public int getX() {
/* 28 */     return this.x;
/*    */   }
/*    */   public int getY() {
/* 31 */     return this.y;
/*    */   }
/*    */ 
/*    */   public void setX(int x) {
/* 35 */     this.x = x;
/*    */   }
/*    */ 
/*    */   public void setY(int y) {
/* 39 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public void translate(int dx, int dy) {
/* 43 */     this.x += dx;
/* 44 */     this.y += dy;
/*    */   }
/*    */ 
/*    */   public void set(int x, int y) {
/* 48 */     this.x = x;
/* 49 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 53 */     return "(" + this.x + "," + this.y + ")";
/*    */   }
/*    */ 
/*    */   public static Point getCenter(Point p1, Point p2)
/*    */   {
/* 65 */     return new Point((p1.getX() + p2.getX()) / 2, (p1.getY() + p2.getY()) / 2);
/*    */   }
/*    */ 
/*    */   public boolean equals(Point compare) {
/* 69 */     return (this.x == compare.x) && (this.y == compare.y);
/*    */   }
/*    */ 
/*    */   public int distanceOf(Point other) {
/* 73 */     int x2 = other.getX();
/* 74 */     int y2 = other.getY();
/* 75 */     return QRCodeUtility.sqrt((this.x - x2) * (this.x - x2) + (this.y - y2) * (this.y - y2));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.geom.Point
 * JD-Core Version:    0.6.0
 */