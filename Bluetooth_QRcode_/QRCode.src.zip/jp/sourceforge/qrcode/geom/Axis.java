/*    */ package jp.sourceforge.qrcode.geom;
/*    */ 
/*    */ import jp.sourceforge.qrcode.reader.QRCodeImageReader;
/*    */ 
/*    */ public class Axis
/*    */ {
/*    */   int sin;
/*    */   int cos;
/*    */   int modulePitch;
/*    */   Point origin;
/*    */ 
/*    */   public Axis(int[] angle, int modulePitch)
/*    */   {
/* 16 */     this.sin = angle[0];
/* 17 */     this.cos = angle[1];
/* 18 */     this.modulePitch = modulePitch;
/* 19 */     this.origin = new Point();
/*    */   }
/*    */ 
/*    */   public void setOrigin(Point origin) {
/* 23 */     this.origin = origin;
/*    */   }
/*    */ 
/*    */   public void setModulePitch(int modulePitch) {
/* 27 */     this.modulePitch = modulePitch;
/*    */   }
/*    */ 
/*    */   public Point translate(Point offset) {
/* 31 */     int moveX = offset.getX();
/* 32 */     int moveY = offset.getY();
/* 33 */     return translate(moveX, moveY);
/*    */   }
/*    */ 
/*    */   public Point translate(Point origin, Point offset) {
/* 37 */     setOrigin(origin);
/* 38 */     int moveX = offset.getX();
/* 39 */     int moveY = offset.getY();
/* 40 */     return translate(moveX, moveY);
/*    */   }
/*    */ 
/*    */   public Point translate(Point origin, int moveX, int moveY) {
/* 44 */     setOrigin(origin);
/* 45 */     return translate(moveX, moveY);
/*    */   }
/*    */ 
/*    */   public Point translate(Point origin, int modulePitch, int moveX, int moveY) {
/* 49 */     setOrigin(origin);
/* 50 */     this.modulePitch = modulePitch;
/* 51 */     return translate(moveX, moveY);
/*    */   }
/*    */ 
/*    */   public Point translate(int moveX, int moveY)
/*    */   {
/* 85 */     long dp = QRCodeImageReader.DECIMAL_POINT;
/* 86 */     Point point = new Point();
/* 87 */     int dx = moveX == 0 ? 0 : this.modulePitch * moveX >> (int)dp;
/* 88 */     int dy = moveY == 0 ? 0 : this.modulePitch * moveY >> (int)dp;
/* 89 */     point.translate(dx * this.cos - dy * this.sin >> (int)dp, dx * this.sin + dy * this.cos >> (int)dp);
/* 90 */     point.translate(this.origin.getX(), this.origin.getY());
/*    */ 
/* 93 */     return point;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.geom.Axis
 * JD-Core Version:    0.6.0
 */