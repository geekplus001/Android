/*     */ package jp.sourceforge.qrcode.geom;
/*     */ 
/*     */ import jp.sourceforge.qrcode.util.QRCodeUtility;
/*     */ 
/*     */ public class Line
/*     */ {
/*     */   int x1;
/*     */   int y1;
/*     */   int x2;
/*     */   int y2;
/*     */ 
/*     */   public Line()
/*     */   {
/*  12 */     this.x1 = (this.y1 = this.x2 = this.y2 = 0);
/*     */   }
/*     */   public Line(int x1, int y1, int x2, int y2) {
/*  15 */     this.x1 = x1;
/*  16 */     this.y1 = y1;
/*  17 */     this.x2 = x2;
/*  18 */     this.y2 = y2;
/*     */   }
/*     */   public Line(Point p1, Point p2) {
/*  21 */     this.x1 = p1.getX();
/*  22 */     this.y1 = p1.getY();
/*  23 */     this.x2 = p2.getX();
/*  24 */     this.y2 = p2.getY();
/*     */   }
/*     */   public Point getP1() {
/*  27 */     return new Point(this.x1, this.y1);
/*     */   }
/*     */ 
/*     */   public Point getP2() {
/*  31 */     return new Point(this.x2, this.y2);
/*     */   }
/*     */ 
/*     */   public void setLine(int x1, int y1, int x2, int y2) {
/*  35 */     this.x1 = x1;
/*  36 */     this.y1 = y1;
/*  37 */     this.x2 = x2;
/*  38 */     this.y2 = y2;
/*     */   }
/*     */   public void setP1(Point p1) {
/*  41 */     this.x1 = p1.getX();
/*  42 */     this.y1 = p1.getY();
/*     */   }
/*     */   public void setP1(int x1, int y1) {
/*  45 */     this.x1 = x1;
/*  46 */     this.y1 = y1;
/*     */   }
/*     */   public void setP2(Point p2) {
/*  49 */     this.x2 = p2.getX();
/*  50 */     this.y2 = p2.getY();
/*     */   }
/*     */   public void setP2(int x2, int y2) {
/*  53 */     this.x2 = x2;
/*  54 */     this.y2 = y2;
/*     */   }
/*     */ 
/*     */   public void translate(int dx, int dy) {
/*  58 */     this.x1 += dx;
/*  59 */     this.y1 += dy;
/*  60 */     this.x2 += dx;
/*  61 */     this.y2 += dy;
/*     */   }
/*     */ 
/*     */   public static boolean isNeighbor(Line line1, Line line2)
/*     */   {
/*  69 */     return (Math.abs(line1.getP1().getX() - line2.getP1().getX()) < 2) && 
/*  67 */       (Math.abs(line1.getP1().getY() - line2.getP1().getY()) < 2) && 
/*  68 */       (Math.abs(line1.getP2().getX() - line2.getP2().getX()) < 2) && 
/*  69 */       (Math.abs(line1.getP2().getY() - line2.getP2().getY()) < 2);
/*     */   }
/*     */ 
/*     */   public boolean isHorizontal()
/*     */   {
/*  75 */     return this.y1 == this.y2;
/*     */   }
/*     */ 
/*     */   public boolean isVertical() {
/*  79 */     return this.x1 == this.x2;
/*     */   }
/*     */ 
/*     */   public static boolean isCross(Line line1, Line line2) {
/*  83 */     if ((line1.isHorizontal()) && (line2.isVertical())) {
/*  84 */       if ((line1.getP1().getY() > line2.getP1().getY()) && 
/*  85 */         (line1.getP1().getY() < line2.getP2().getY()) && 
/*  86 */         (line2.getP1().getX() > line1.getP1().getX()) && 
/*  87 */         (line2.getP1().getX() < line1.getP2().getX()))
/*  88 */         return true;
/*  89 */     } else if ((line1.isVertical()) && (line2.isHorizontal()) && 
/*  90 */       (line1.getP1().getX() > line2.getP1().getX()) && 
/*  91 */       (line1.getP1().getX() < line2.getP2().getX()) && 
/*  92 */       (line2.getP1().getY() > line1.getP1().getY()) && 
/*  93 */       (line2.getP1().getY() < line1.getP2().getY())) {
/*  94 */       return true;
/*     */     }
/*     */ 
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */   public Point getCenter() {
/* 101 */     int x = (this.x1 + this.x2) / 2;
/* 102 */     int y = (this.y1 + this.y2) / 2;
/* 103 */     return new Point(x, y);
/*     */   }
/*     */   public int getLength() {
/* 106 */     int x = Math.abs(this.x2 - this.x1);
/* 107 */     int y = Math.abs(this.y2 - this.y1);
/* 108 */     int r = QRCodeUtility.sqrt(x * x + y * y);
/* 109 */     return r;
/*     */   }
/*     */   public static Line getLongest(Line[] lines) {
/* 112 */     Line longestLine = new Line();
/* 113 */     for (int i = 0; i < lines.length; i++) {
/* 114 */       if (lines[i].getLength() > longestLine.getLength()) {
/* 115 */         longestLine = lines[i];
/*     */       }
/*     */     }
/* 118 */     return longestLine;
/*     */   }
/*     */   public String toString() {
/* 121 */     return "(" + this.x1 + "," + this.y1 + ")-(" + this.x2 + "," + this.y2 + ")";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.geom.Line
 * JD-Core Version:    0.6.0
 */