/*     */ package jp.sourceforge.qrcode.geom;
/*     */ 
/*     */ public class SamplingGrid
/*     */ {
/*     */   private AreaGrid[][] grid;
/*     */ 
/*     */   public SamplingGrid(int sqrtNumArea)
/*     */   {
/*  68 */     this.grid = new AreaGrid[sqrtNumArea][sqrtNumArea];
/*     */   }
/*     */ 
/*     */   public void initGrid(int ax, int ay, int width, int height)
/*     */   {
/*  73 */     this.grid[ax][ay] = new AreaGrid(width, height);
/*     */   }
/*     */ 
/*     */   public void setXLine(int ax, int ay, int x, Line line)
/*     */   {
/*  78 */     this.grid[ax][ay].setXLine(x, line);
/*     */   }
/*     */ 
/*     */   public void setYLine(int ax, int ay, int y, Line line)
/*     */   {
/*  83 */     this.grid[ax][ay].setYLine(y, line);
/*     */   }
/*     */ 
/*     */   public Line getXLine(int ax, int ay, int x) throws ArrayIndexOutOfBoundsException
/*     */   {
/*  88 */     return this.grid[ax][ay].getXLine(x);
/*     */   }
/*     */ 
/*     */   public Line getYLine(int ax, int ay, int y) throws ArrayIndexOutOfBoundsException
/*     */   {
/*  93 */     return this.grid[ax][ay].getYLine(y);
/*     */   }
/*     */ 
/*     */   public Line[] getXLines(int ax, int ay)
/*     */   {
/*  98 */     return this.grid[ax][ay].getXLines();
/*     */   }
/*     */ 
/*     */   public Line[] getYLines(int ax, int ay)
/*     */   {
/* 103 */     return this.grid[ax][ay].getYLines();
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 108 */     return this.grid[0].length;
/*     */   }
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 113 */     return this.grid.length;
/*     */   }
/*     */ 
/*     */   public int getWidth(int ax, int ay)
/*     */   {
/* 118 */     return this.grid[ax][ay].getWidth();
/*     */   }
/*     */ 
/*     */   public int getHeight(int ax, int ay)
/*     */   {
/* 123 */     return this.grid[ax][ay].getHeight();
/*     */   }
/*     */ 
/*     */   public int getTotalWidth()
/*     */   {
/* 128 */     int total = 0;
/* 129 */     for (int i = 0; i < this.grid.length; i++)
/*     */     {
/* 131 */       total += this.grid[i][0].getWidth();
/* 132 */       if (i > 0)
/* 133 */         total--;
/*     */     }
/* 135 */     return total;
/*     */   }
/*     */ 
/*     */   public int getTotalHeight()
/*     */   {
/* 140 */     int total = 0;
/* 141 */     for (int i = 0; i < this.grid[0].length; i++)
/*     */     {
/* 143 */       total += this.grid[0][i].getHeight();
/* 144 */       if (i > 0)
/* 145 */         total--;
/*     */     }
/* 147 */     return total;
/*     */   }
/*     */ 
/*     */   public int getX(int ax, int x)
/*     */   {
/* 153 */     int total = x;
/* 154 */     for (int i = 0; i < ax; i++)
/*     */     {
/* 156 */       total += this.grid[i][0].getWidth() - 1;
/*     */     }
/* 158 */     return total;
/*     */   }
/*     */ 
/*     */   public int getY(int ay, int y)
/*     */   {
/* 163 */     int total = y;
/* 164 */     for (int i = 0; i < ay; i++)
/*     */     {
/* 166 */       total += this.grid[0][i].getHeight() - 1;
/*     */     }
/* 168 */     return total;
/*     */   }
/*     */ 
/*     */   public void adjust(Point adjust) {
/* 172 */     int dx = adjust.getX(); int dy = adjust.getY();
/* 173 */     for (int ay = 0; ay < this.grid[0].length; ay++)
/* 174 */       for (int ax = 0; ax < this.grid.length; ax++) {
/* 175 */         for (int i = 0; i < this.grid[ax][ay].xLine.length; i++)
/* 176 */           this.grid[ax][ay].xLine[i].translate(dx, dy);
/* 177 */         for (int j = 0; j < this.grid[ax][ay].yLine.length; j++)
/* 178 */           this.grid[ax][ay].yLine[j].translate(dx, dy);
/*     */       }
/*     */   }
/*     */ 
/*     */   private class AreaGrid
/*     */   {
/*     */     protected Line[] xLine;
/*     */     protected Line[] yLine;
/*     */ 
/*     */     public AreaGrid(int width, int height)
/*     */     {
/*  19 */       this.xLine = new Line[width];
/*  20 */       this.yLine = new Line[height];
/*     */     }
/*     */ 
/*     */     public int getWidth()
/*     */     {
/*  25 */       return this.xLine.length;
/*     */     }
/*     */ 
/*     */     public int getHeight()
/*     */     {
/*  30 */       return this.yLine.length;
/*     */     }
/*     */ 
/*     */     public Line getXLine(int x) throws ArrayIndexOutOfBoundsException
/*     */     {
/*  35 */       return this.xLine[x];
/*     */     }
/*     */ 
/*     */     public Line getYLine(int y) throws ArrayIndexOutOfBoundsException
/*     */     {
/*  40 */       return this.yLine[y];
/*     */     }
/*     */ 
/*     */     public Line[] getXLines()
/*     */     {
/*  45 */       return this.xLine;
/*     */     }
/*     */ 
/*     */     public Line[] getYLines()
/*     */     {
/*  50 */       return this.yLine;
/*     */     }
/*     */ 
/*     */     public void setXLine(int x, Line line)
/*     */     {
/*  55 */       this.xLine[x] = line;
/*     */     }
/*     */ 
/*     */     public void setYLine(int y, Line line)
/*     */     {
/*  60 */       this.yLine[y] = line;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.geom.SamplingGrid
 * JD-Core Version:    0.6.0
 */