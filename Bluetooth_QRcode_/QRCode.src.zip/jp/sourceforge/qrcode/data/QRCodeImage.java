package jp.sourceforge.qrcode.data;

public abstract interface QRCodeImage
{
  public abstract int getWidth();

  public abstract int getHeight();

  public abstract int getPixel(int paramInt1, int paramInt2);
}

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.data.QRCodeImage
 * JD-Core Version:    0.6.0
 */