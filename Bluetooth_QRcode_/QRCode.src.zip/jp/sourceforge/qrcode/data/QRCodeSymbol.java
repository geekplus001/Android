/*     */ package jp.sourceforge.qrcode.data;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import jp.sourceforge.qrcode.ecc.BCH15_5;
/*     */ import jp.sourceforge.qrcode.geom.Point;
/*     */ import jp.sourceforge.qrcode.pattern.LogicalSeed;
/*     */ 
/*     */ public class QRCodeSymbol
/*     */ {
/*     */   int version;
/*     */   int errorCollectionLevel;
/*     */   int maskPattern;
/*     */   int dataCapacity;
/*     */   boolean[][] moduleMatrix;
/*     */   int width;
/*     */   int height;
/*     */   Point[][] alignmentPattern;
/*  17 */   final int[][] numErrorCollectionCode = { 
/*  18 */     { 7, 10, 13, 17 }, 
/*  19 */     { 10, 16, 22, 28 }, { 15, 26, 36, 44 }, { 20, 36, 52, 64 }, { 26, 48, 72, 88 }, { 36, 64, 96, 112 }, 
/*  20 */     { 40, 72, 108, 130 }, { 48, 88, 132, 156 }, { 60, 110, 160, 192 }, { 72, 130, 192, 224 }, { 80, 150, 224, 264 }, { 96, 176, 260, 308 }, { 104, 198, 288, 352 }, 
/*  21 */     { 120, 216, 320, 384 }, { 132, 240, 360, 432 }, { 144, 280, 408, 480 }, { 168, 308, 448, 532 }, { 180, 338, 504, 588 }, { 196, 364, 546, 650 }, { 224, 416, 600, 700 }, 
/*  22 */     { 224, 442, 644, 750 }, { 252, 476, 690, 816 }, { 270, 504, 750, 900 }, { 300, 560, 810, 960 }, { 312, 588, 870, 1050 }, { 336, 644, 952, 1110 }, { 360, 700, 1020, 1200 }, 
/*  23 */     { 390, 728, 1050, 1260 }, { 420, 784, 1140, 1350 }, { 450, 812, 1200, 1440 }, { 480, 868, 1290, 1530 }, { 510, 924, 1350, 1620 }, { 540, 980, 1440, 1710 }, { 570, 1036, 1530, 1800 }, 
/*  24 */     { 570, 1064, 1590, 1890 }, { 600, 1120, 1680, 1980 }, { 630, 1204, 1770, 2100 }, { 660, 1260, 1860, 2220 }, { 720, 1316, 1950, 2310 }, { 750, 1372, 2040, 2430 } };
/*     */ 
/*  27 */   final int[][] numRSBlocks = { 
/*  28 */     { 1, 1, 1, 1 }, 
/*  29 */     { 1, 1, 1, 1 }, { 1, 1, 2, 2 }, { 1, 2, 2, 4 }, { 1, 2, 4, 4 }, { 2, 4, 4, 4 }, 
/*  30 */     { 2, 4, 6, 5 }, { 2, 4, 6, 6 }, { 2, 5, 8, 8 }, { 4, 5, 8, 8 }, { 4, 5, 8, 11 }, { 4, 8, 10, 11 }, { 4, 9, 12, 16 }, 
/*  31 */     { 4, 9, 16, 16 }, { 6, 10, 12, 18 }, { 6, 10, 17, 16 }, { 6, 11, 16, 19 }, { 6, 13, 18, 21 }, { 7, 14, 21, 25 }, { 8, 16, 20, 25 }, 
/*  32 */     { 8, 17, 23, 25 }, { 9, 17, 23, 34 }, { 9, 18, 25, 30 }, { 10, 20, 27, 32 }, { 12, 21, 29, 35 }, { 12, 23, 34, 37 }, { 12, 25, 34, 40 }, 
/*  33 */     { 13, 26, 35, 42 }, { 14, 28, 38, 45 }, { 15, 29, 40, 48 }, { 16, 31, 43, 51 }, { 17, 33, 45, 54 }, { 18, 35, 48, 57 }, { 19, 37, 51, 60 }, 
/*  34 */     { 19, 38, 53, 63 }, { 20, 40, 56, 66 }, { 21, 43, 59, 70 }, { 22, 45, 62, 74 }, { 24, 47, 65, 77 }, { 25, 49, 68, 81 } };
/*     */ 
/*     */   public boolean getElement(int x, int y)
/*     */   {
/*  38 */     return this.moduleMatrix[x][y];
/*     */   }
/*     */ 
/*     */   public int getNumErrorCollectionCode()
/*     */   {
/*  43 */     return this.numErrorCollectionCode[(this.version - 1)][this.errorCollectionLevel];
/*     */   }
/*     */ 
/*     */   public int getNumRSBlocks() {
/*  47 */     return this.numRSBlocks[(this.version - 1)][this.errorCollectionLevel];
/*     */   }
/*     */ 
/*     */   public QRCodeSymbol(boolean[][] moduleMatrix) {
/*  51 */     this.moduleMatrix = moduleMatrix;
/*  52 */     this.width = moduleMatrix.length;
/*  53 */     this.height = moduleMatrix[0].length;
/*  54 */     initialize();
/*     */   }
/*     */ 
/*     */   void initialize()
/*     */   {
/*  61 */     this.version = ((this.width - 17) / 4);
/*  62 */     Point[][] alignmentPattern = new Point[1][1];
/*     */ 
/*  64 */     int[] logicalSeeds = new int[1];
/*     */ 
/*  82 */     if ((this.version >= 2) && (this.version <= 40))
/*     */     {
/*  89 */       logicalSeeds = LogicalSeed.getSeed(this.version);
/*  90 */       alignmentPattern = new Point[logicalSeeds.length][logicalSeeds.length];
/*     */     }
/*     */ 
/*  94 */     for (int col = 0; col < logicalSeeds.length; col++) {
/*  95 */       for (int row = 0; row < logicalSeeds.length; row++) {
/*  96 */         alignmentPattern[row][col] = new Point(logicalSeeds[row], logicalSeeds[col]);
/*     */       }
/*     */     }
/*  99 */     this.alignmentPattern = alignmentPattern;
/*     */ 
/* 102 */     this.dataCapacity = calcDataCapacity();
/*     */ 
/* 104 */     boolean[] formatInformation = readFormatInformation();
/* 105 */     decodeFormatInformation(formatInformation);
/*     */ 
/* 107 */     unmask();
/*     */   }
/*     */   public int getVersion() {
/* 110 */     return this.version;
/*     */   }
/*     */   public String getVersionReference() {
/* 113 */     char[] versionReferenceCharacter = { 'L', 'M', 'Q', 'H' };
/*     */ 
/* 115 */     return Integer.toString(this.version) + "-" + 
/* 116 */       versionReferenceCharacter[this.errorCollectionLevel];
/*     */   }
/*     */ 
/*     */   public Point[][] getAlignmentPattern() {
/* 120 */     return this.alignmentPattern;
/*     */   }
/*     */ 
/*     */   boolean[] readFormatInformation() {
/* 124 */     boolean[] modules = new boolean[15];
/*     */ 
/* 127 */     for (int i = 0; i <= 5; i++) {
/* 128 */       modules[i] = getElement(8, i);
/*     */     }
/* 130 */     modules[6] = getElement(8, 7);
/* 131 */     modules[7] = getElement(8, 8);
/* 132 */     modules[8] = getElement(7, 8);
/*     */ 
/* 134 */     for (int i = 9; i <= 14; i++) {
/* 135 */       modules[i] = getElement(14 - i, 8);
/*     */     }
/*     */ 
/* 138 */     int maskPattern = 21522;
/*     */ 
/* 140 */     for (int i = 0; i <= 14; i++) {
/* 141 */       boolean xorBit = false;
/* 142 */       if ((maskPattern >>> i & 0x1) == 1)
/* 143 */         xorBit = true;
/*     */       else {
/* 145 */         xorBit = false;
/*     */       }
/*     */ 
/* 148 */       if (modules[i] == xorBit)
/* 149 */         modules[i] = false;
/*     */       else {
/* 151 */         modules[i] = true;
/*     */       }
/*     */     }
/* 154 */     BCH15_5 corrector = new BCH15_5(modules);
/* 155 */     boolean[] output = corrector.correct();
/*     */ 
/* 159 */     boolean[] formatInformation = new boolean[5];
/* 160 */     for (int i = 0; i < 5; i++) {
/* 161 */       formatInformation[i] = output[(10 + i)];
/*     */     }
/* 163 */     return formatInformation;
/*     */   }
/*     */ 
/*     */   void unmask()
/*     */   {
/* 168 */     boolean[][] maskPattern = generateMaskPattern();
/*     */ 
/* 170 */     int size = getWidth();
/*     */ 
/* 172 */     for (int y = 0; y < size; y++)
/* 173 */       for (int x = 0; x < size; x++)
/* 174 */         if (maskPattern[x][y] != 0)
/* 175 */           reverseElement(x, y);
/*     */   }
/*     */ 
/*     */   boolean[][] generateMaskPattern()
/*     */   {
/* 183 */     int maskPatternReferer = getMaskPatternReferer();
/*     */ 
/* 185 */     int width = getWidth();
/* 186 */     int height = getHeight();
/* 187 */     boolean[][] maskPattern = new boolean[width][height];
/* 188 */     for (int y = 0; y < height; y++) {
/* 189 */       for (int x = 0; x < width; x++) {
/* 190 */         if (isInFunctionPattern(x, y))
/*     */           continue;
/* 192 */         switch (maskPatternReferer) {
/*     */         case 0:
/* 194 */           if ((y + x) % 2 != 0) continue;
/* 195 */           maskPattern[x][y] = 1;
/* 196 */           break;
/*     */         case 1:
/* 198 */           if (y % 2 != 0) continue;
/* 199 */           maskPattern[x][y] = 1;
/* 200 */           break;
/*     */         case 2:
/* 202 */           if (x % 3 != 0) continue;
/* 203 */           maskPattern[x][y] = 1;
/* 204 */           break;
/*     */         case 3:
/* 206 */           if ((y + x) % 3 != 0) continue;
/* 207 */           maskPattern[x][y] = 1;
/* 208 */           break;
/*     */         case 4:
/* 210 */           if ((y / 2 + x / 3) % 2 != 0) continue;
/* 211 */           maskPattern[x][y] = 1;
/* 212 */           break;
/*     */         case 5:
/* 214 */           if (y * x % 2 + y * x % 3 != 0) continue;
/* 215 */           maskPattern[x][y] = 1;
/* 216 */           break;
/*     */         case 6:
/* 218 */           if ((y * x % 2 + y * x % 3) % 2 != 0) continue;
/* 219 */           maskPattern[x][y] = 1;
/* 220 */           break;
/*     */         case 7:
/* 222 */           if ((y * x % 3 + (y + x) % 2) % 2 != 0) continue;
/* 223 */           maskPattern[x][y] = 1;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 228 */     return maskPattern;
/*     */   }
/*     */ 
/*     */   private int calcDataCapacity() {
/* 232 */     int numFunctionPatternModule = 0;
/* 233 */     int numFormatAndVersionInfoModule = 0;
/* 234 */     int version = getVersion();
/*     */ 
/* 237 */     if (version <= 6)
/* 238 */       numFormatAndVersionInfoModule = 31;
/*     */     else {
/* 240 */       numFormatAndVersionInfoModule = 67;
/*     */     }
/*     */ 
/* 244 */     int sqrtCenters = version / 7 + 2;
/*     */ 
/* 248 */     int modulesLeft = version == 1 ? 192 : 192 + (sqrtCenters * sqrtCenters - 3) * 25;
/*     */ 
/* 251 */     numFunctionPatternModule = modulesLeft + 8 * version + 2 - (sqrtCenters - 2) * 10;
/*     */ 
/* 253 */     int dataCapacity = (this.width * this.width - numFunctionPatternModule - numFormatAndVersionInfoModule) / 8;
/*     */ 
/* 255 */     return dataCapacity;
/*     */   }
/*     */ 
/*     */   public int getDataCapacity()
/*     */   {
/* 260 */     return this.dataCapacity;
/*     */   }
/*     */ 
/*     */   void decodeFormatInformation(boolean[] formatInformation) {
/* 264 */     if (formatInformation[4] == 0) {
/* 265 */       if (formatInformation[3] != 0)
/* 266 */         this.errorCollectionLevel = 0;
/*     */       else
/* 268 */         this.errorCollectionLevel = 1;
/*     */     }
/* 270 */     else if (formatInformation[3] != 0)
/* 271 */       this.errorCollectionLevel = 2;
/*     */     else {
/* 273 */       this.errorCollectionLevel = 3;
/*     */     }
/* 275 */     for (int i = 2; i >= 0; i--)
/* 276 */       if (formatInformation[i] != 0)
/* 277 */         this.maskPattern += (1 << i); 
/*     */   }
/*     */ 
/*     */   public int getErrorCollectionLevel() {
/* 280 */     return this.errorCollectionLevel;
/*     */   }
/*     */   public int getMaskPatternReferer() {
/* 283 */     return this.maskPattern;
/*     */   }
/*     */ 
/*     */   public String getMaskPatternRefererAsString()
/*     */   {
/* 288 */     String maskPattern = Integer.toString(getMaskPatternReferer(), 2);
/* 289 */     int length = maskPattern.length();
/* 290 */     for (int i = 0; i < 3 - length; i++)
/* 291 */       maskPattern = "0" + maskPattern;
/* 292 */     return maskPattern;
/*     */   }
/*     */ 
/*     */   public int getWidth() {
/* 296 */     return this.width;
/*     */   }
/*     */   public int getHeight() {
/* 299 */     return this.height;
/*     */   }
/*     */ 
/*     */   public int[] getBlocks() {
/* 303 */     int width = getWidth();
/*     */ 
/* 306 */     int height = getHeight();
/* 307 */     int x = width - 1;
/* 308 */     int y = height - 1;
/* 309 */     Vector codeBits = new Vector();
/* 310 */     Vector codeWords = new Vector();
/* 311 */     int tempWord = 0;
/* 312 */     int figure = 7;
/* 313 */     int isNearFinish = 0;
/* 314 */     boolean READ_UP = true;
/* 315 */     boolean READ_DOWN = false;
/* 316 */     boolean direction = true;
/*     */     do
/*     */     {
/* 319 */       codeBits.addElement(new Boolean(getElement(x, y)));
/*     */ 
/* 325 */       if (getElement(x, y)) {
/* 326 */         tempWord += (1 << figure);
/*     */       }
/*     */ 
/* 329 */       figure--;
/* 330 */       if (figure == -1) {
/* 331 */         codeWords.addElement(new Integer(tempWord));
/*     */ 
/* 334 */         figure = 7;
/* 335 */         tempWord = 0;
/*     */       }
/*     */       do
/*     */       {
/* 339 */         if (direction) {
/* 340 */           if ((x + isNearFinish) % 2 == 0) {
/* 341 */             x--;
/*     */           }
/* 343 */           else if (y > 0) {
/* 344 */             x++;
/* 345 */             y--;
/*     */           }
/*     */           else {
/* 348 */             x--;
/* 349 */             if (x == 6) {
/* 350 */               x--;
/* 351 */               isNearFinish = 1;
/*     */             }
/* 353 */             direction = false;
/*     */           }
/*     */ 
/*     */         }
/* 359 */         else if ((x + isNearFinish) % 2 == 0) {
/* 360 */           x--;
/*     */         }
/* 362 */         else if (y < height - 1) {
/* 363 */           x++;
/* 364 */           y++;
/*     */         }
/*     */         else {
/* 367 */           x--;
/* 368 */           if (x == 6) {
/* 369 */             x--;
/* 370 */             isNearFinish = 1;
/*     */           }
/* 372 */           direction = true;
/*     */         }
/*     */       }
/* 338 */       while (
/* 376 */         isInFunctionPattern(x, y));
/*     */     }
/* 378 */     while (x != -1);
/*     */ 
/* 380 */     int[] gotWords = new int[codeWords.size()];
/* 381 */     for (int i = 0; i < codeWords.size(); i++) {
/* 382 */       Integer temp = (Integer)codeWords.elementAt(i);
/* 383 */       gotWords[i] = temp.intValue();
/*     */     }
/* 385 */     return gotWords;
/*     */   }
/*     */ 
/*     */   public void reverseElement(int x, int y) {
/* 389 */     this.moduleMatrix[x][y] = (this.moduleMatrix[x][y] != 0 ? 0 : 1);
/*     */   }
/*     */   public boolean isInFunctionPattern(int targetX, int targetY) {
/* 392 */     if ((targetX < 9) && (targetY < 9))
/* 393 */       return true;
/* 394 */     if ((targetX > getWidth() - 9) && (targetY < 9))
/* 395 */       return true;
/* 396 */     if ((targetX < 9) && (targetY > getHeight() - 9)) {
/* 397 */       return true;
/*     */     }
/* 399 */     if (this.version >= 7) {
/* 400 */       if ((targetX > getWidth() - 12) && (targetY < 6))
/* 401 */         return true;
/* 402 */       if ((targetX < 6) && (targetY > getHeight() - 12)) {
/* 403 */         return true;
/*     */       }
/*     */     }
/* 406 */     if ((targetX == 6) || (targetY == 6)) {
/* 407 */       return true;
/*     */     }
/*     */ 
/* 410 */     Point[][] alignmentPattern = getAlignmentPattern();
/* 411 */     int sideLength = alignmentPattern.length;
/*     */ 
/* 413 */     for (int y = 0; y < sideLength; y++) {
/* 414 */       for (int x = 0; x < sideLength; x++) {
/* 415 */         if (((x != 0) || (y != 0)) && ((x != sideLength - 1) || (y != 0)) && ((x != 0) || (y != sideLength - 1)) && 
/* 416 */           (Math.abs(alignmentPattern[x][y].getX() - targetX) < 3) && 
/* 417 */           (Math.abs(alignmentPattern[x][y].getY() - targetY) < 3)) {
/* 418 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 422 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.data.QRCodeSymbol
 * JD-Core Version:    0.6.0
 */