package jp.sourceforge.qrcode.util;

public abstract interface Color
{
  public static final int GRAY = 11184810;
  public static final int LIGHTGRAY = 12303291;
  public static final int DARKGRAY = 4473924;
  public static final int BLACK = 0;
  public static final int WHITE = 16777215;
  public static final int BLUE = 8947967;
  public static final int GREEN = 8978312;
  public static final int LIGHTBLUE = 12303359;
  public static final int LIGHTGREEN = 12320699;
  public static final int RED = 267946120;
  public static final int ORANGE = 16777096;
  public static final int LIGHTRED = 16759739;
}

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.util.Color
 * JD-Core Version:    0.6.0
 */