package jp.sourceforge.qrcode.util;

import jp.sourceforge.qrcode.geom.Line;
import jp.sourceforge.qrcode.geom.Point;

public abstract interface DebugCanvas
{
  public abstract void println(String paramString);

  public abstract void drawPoint(Point paramPoint, int paramInt);

  public abstract void drawCross(Point paramPoint, int paramInt);

  public abstract void drawPoints(Point[] paramArrayOfPoint, int paramInt);

  public abstract void drawLine(Line paramLine, int paramInt);

  public abstract void drawLines(Line[] paramArrayOfLine, int paramInt);

  public abstract void drawPolygon(Point[] paramArrayOfPoint, int paramInt);

  public abstract void drawMatrix(boolean[][] paramArrayOfBoolean);
}

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.util.DebugCanvas
 * JD-Core Version:    0.6.0
 */