/*    */ package jp.sourceforge.qrcode.util;
/*    */ 
/*    */ public class ContentConverter
/*    */ {
/*  5 */   static char n = '\n';
/*    */ 
/*    */   public static String convert(String targetString) {
/*  8 */     if (targetString == null)
/*  9 */       return targetString;
/* 10 */     if (targetString.indexOf("MEBKM:") > -1)
/* 11 */       targetString = convertDocomoBookmark(targetString);
/* 12 */     if (targetString.indexOf("MECARD:") > -1)
/* 13 */       targetString = convertDocomoAddressBook(targetString);
/* 14 */     if (targetString.indexOf("MATMSG:") > -1)
/* 15 */       targetString = convertDocomoMailto(targetString);
/* 16 */     if (targetString.indexOf("http\\://") > -1)
/* 17 */       targetString = replaceString(targetString, "http\\://", "\nhttp://");
/* 18 */     return targetString;
/*    */   }
/*    */ 
/*    */   private static String convertDocomoBookmark(String targetString)
/*    */   {
/* 23 */     targetString = removeString(targetString, "MEBKM:");
/* 24 */     targetString = removeString(targetString, "TITLE:");
/* 25 */     targetString = removeString(targetString, ";");
/* 26 */     targetString = removeString(targetString, "URL:");
/* 27 */     return targetString;
/*    */   }
/*    */ 
/*    */   private static String convertDocomoAddressBook(String targetString)
/*    */   {
/* 33 */     targetString = removeString(targetString, "MECARD:");
/* 34 */     targetString = removeString(targetString, ";");
/* 35 */     targetString = replaceString(targetString, "N:", "NAME1:");
/* 36 */     targetString = replaceString(targetString, "SOUND:", n + "NAME2:");
/* 37 */     targetString = replaceString(targetString, "TEL:", n + "TEL1:");
/* 38 */     targetString = replaceString(targetString, "EMAIL:", n + "MAIL1:");
/* 39 */     targetString = targetString + n;
/* 40 */     return targetString;
/*    */   }
/*    */ 
/*    */   private static String convertDocomoMailto(String s)
/*    */   {
/* 45 */     String s1 = s;
/* 46 */     char c = '\n';
/* 47 */     s1 = removeString(s1, "MATMSG:");
/* 48 */     s1 = removeString(s1, ";");
/* 49 */     s1 = replaceString(s1, "TO:", "MAILTO:");
/* 50 */     s1 = replaceString(s1, "SUB:", c + "SUBJECT:");
/* 51 */     s1 = replaceString(s1, "BODY:", c + "BODY:");
/* 52 */     s1 = s1 + c;
/* 53 */     return s1;
/*    */   }
/*    */ 
/*    */   private static String replaceString(String s, String s1, String s2)
/*    */   {
/* 58 */     String s3 = s;
/* 59 */     for (int i = s3.indexOf(s1, 0); i > -1; i = s3.indexOf(s1, i + s2.length())) {
/* 60 */       s3 = s3.substring(0, i) + s2 + s3.substring(i + s1.length());
/*    */     }
/* 62 */     return s3;
/*    */   }
/*    */ 
/*    */   private static String removeString(String s, String s1)
/*    */   {
/* 67 */     return replaceString(s, s1, "");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.util.ContentConverter
 * JD-Core Version:    0.6.0
 */