package jp.sourceforge.qrcode.util;

import jp.sourceforge.qrcode.geom.Line;
import jp.sourceforge.qrcode.geom.Point;

public class DebugCanvasAdapter
  implements DebugCanvas
{
  public void println(String string)
  {
  }

  public void drawPoint(Point point, int color)
  {
  }

  public void drawCross(Point point, int color)
  {
  }

  public void drawPoints(Point[] points, int color)
  {
  }

  public void drawLine(Line line, int color)
  {
  }

  public void drawLines(Line[] lines, int color)
  {
  }

  public void drawPolygon(Point[] points, int color)
  {
  }

  public void drawMatrix(boolean[][] matrix)
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.util.DebugCanvasAdapter
 * JD-Core Version:    0.6.0
 */