/*    */ package jp.sourceforge.qrcode.util;
/*    */ 
/*    */ public class QRCodeUtility
/*    */ {
/*    */   public static int sqrt(int val)
/*    */   {
/* 13 */     int g = 0; int b = 32768; int bshft = 15;
/*    */     do
/*    */     {
/*    */       int temp;
/* 15 */       if (val >= (temp = (g << 1) + b << bshft--)) {
/* 16 */         g += b;
/* 17 */         val -= temp;
/*    */       }
/*    */     }
/* 19 */     while (b >>= 1 > 0);
/*    */ 
/* 21 */     return g;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.util.QRCodeUtility
 * JD-Core Version:    0.6.0
 */