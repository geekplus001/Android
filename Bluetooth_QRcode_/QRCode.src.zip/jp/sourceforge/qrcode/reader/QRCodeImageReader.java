/*     */ package jp.sourceforge.qrcode.reader;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import jp.sourceforge.qrcode.QRCodeDecoder;
/*     */ import jp.sourceforge.qrcode.data.QRCodeSymbol;
/*     */ import jp.sourceforge.qrcode.exception.AlignmentPatternNotFoundException;
/*     */ import jp.sourceforge.qrcode.exception.FinderPatternNotFoundException;
/*     */ import jp.sourceforge.qrcode.exception.InvalidVersionException;
/*     */ import jp.sourceforge.qrcode.exception.SymbolNotFoundException;
/*     */ import jp.sourceforge.qrcode.exception.VersionInformationException;
/*     */ import jp.sourceforge.qrcode.geom.Axis;
/*     */ import jp.sourceforge.qrcode.geom.Line;
/*     */ import jp.sourceforge.qrcode.geom.Point;
/*     */ import jp.sourceforge.qrcode.geom.SamplingGrid;
/*     */ import jp.sourceforge.qrcode.pattern.AlignmentPattern;
/*     */ import jp.sourceforge.qrcode.pattern.FinderPattern;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvas;
/*     */ import jp.sourceforge.qrcode.util.QRCodeUtility;
/*     */ 
/*     */ public class QRCodeImageReader
/*     */ {
/*     */   DebugCanvas canvas;
/*  26 */   public static int DECIMAL_POINT = 21;
/*     */   public static final boolean POINT_DARK = true;
/*     */   public static final boolean POINT_LIGHT = false;
/*     */   SamplingGrid samplingGrid;
/*     */   boolean[][] bitmap;
/*     */ 
/*     */   public QRCodeImageReader()
/*     */   {
/*  35 */     this.canvas = QRCodeDecoder.getCanvas();
/*     */   }
/*     */ 
/*     */   boolean[][] applyMedianFilter(boolean[][] image, int threshold)
/*     */   {
/*  48 */     boolean[][] filteredMatrix = new boolean[image.length][image[0].length];
/*     */ 
/*  51 */     for (int y = 1; y < image[0].length - 1; y++) {
/*  52 */       for (int x = 1; x < image.length - 1; x++)
/*     */       {
/*  54 */         int numPointDark = 0;
/*  55 */         for (int fy = -1; fy < 2; fy++) {
/*  56 */           for (int fx = -1; fx < 2; fx++) {
/*  57 */             if (image[(x + fx)][(y + fy)] != 0) {
/*  58 */               numPointDark++;
/*     */             }
/*     */           }
/*     */         }
/*  62 */         if (numPointDark > threshold) {
/*  63 */           filteredMatrix[x][y] = 1;
/*     */         }
/*     */       }
/*     */     }
/*  67 */     return filteredMatrix;
/*     */   }
/*     */   boolean[][] applyCrossMaskingMedianFilter(boolean[][] image, int threshold) {
/*  70 */     boolean[][] filteredMatrix = new boolean[image.length][image[0].length];
/*     */ 
/*  73 */     for (int y = 2; y < image[0].length - 2; y++) {
/*  74 */       for (int x = 2; x < image.length - 2; x++)
/*     */       {
/*  76 */         int numPointDark = 0;
/*  77 */         for (int f = -2; f < 3; f++) {
/*  78 */           if (image[(x + f)][y] != 0) {
/*  79 */             numPointDark++;
/*     */           }
/*  81 */           if (image[x][(y + f)] != 0) {
/*  82 */             numPointDark++;
/*     */           }
/*     */         }
/*  85 */         if (numPointDark > threshold) {
/*  86 */           filteredMatrix[x][y] = 1;
/*     */         }
/*     */       }
/*     */     }
/*  90 */     return filteredMatrix;
/*     */   }
/*     */   boolean[][] filterImage(int[][] image) {
/*  93 */     imageToGrayScale(image);
/*  94 */     boolean[][] bitmap = grayScaleToBitmap(image);
/*  95 */     return bitmap;
/*     */   }
/*     */ 
/*     */   void imageToGrayScale(int[][] image) {
/*  99 */     for (int y = 0; y < image[0].length; y++)
/* 100 */       for (int x = 0; x < image.length; x++) {
/* 101 */         int r = image[x][y] >> 16 & 0xFF;
/* 102 */         int g = image[x][y] >> 8 & 0xFF;
/* 103 */         int b = image[x][y] & 0xFF;
/* 104 */         int m = (r * 30 + g * 59 + b * 11) / 100;
/* 105 */         image[x][y] = m;
/*     */       }
/*     */   }
/*     */ 
/*     */   boolean[][] grayScaleToBitmap(int[][] grayScale)
/*     */   {
/* 111 */     int[][] middle = getMiddleBrightnessPerArea(grayScale);
/* 112 */     int sqrtNumArea = middle.length;
/* 113 */     int areaWidth = grayScale.length / sqrtNumArea;
/* 114 */     int areaHeight = grayScale[0].length / sqrtNumArea;
/* 115 */     boolean[][] bitmap = new boolean[grayScale.length][grayScale[0].length];
/*     */ 
/* 117 */     for (int ay = 0; ay < sqrtNumArea; ay++) {
/* 118 */       for (int ax = 0; ax < sqrtNumArea; ax++) {
/* 119 */         for (int dy = 0; dy < areaHeight; dy++) {
/* 120 */           for (int dx = 0; dx < areaWidth; dx++) {
/* 121 */             bitmap[(areaWidth * ax + dx)][(areaHeight * ay + dy)] = (grayScale[(areaWidth * ax + dx)][(areaHeight * ay + dy)] < middle[ax][ay] ? 1 : 0);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 126 */     return bitmap;
/*     */   }
/*     */ 
/*     */   int[][] getMiddleBrightnessPerArea(int[][] image) {
/* 130 */     int numSqrtArea = 4;
/*     */ 
/* 132 */     int areaWidth = image.length / 4;
/* 133 */     int areaHeight = image[0].length / 4;
/* 134 */     int[][][] minmax = new int[4][4][2];
/* 135 */     for (int ay = 0; ay < 4; ay++) {
/* 136 */       for (int ax = 0; ax < 4; ax++) {
/* 137 */         minmax[ax][ay][0] = 'ÿ';
/* 138 */         for (int dy = 0; dy < areaHeight; dy++) {
/* 139 */           for (int dx = 0; dx < areaWidth; dx++) {
/* 140 */             int target = image[(areaWidth * ax + dx)][(areaHeight * ay + dy)];
/* 141 */             if (target < minmax[ax][ay][0]) minmax[ax][ay][0] = target;
/* 142 */             if (target <= minmax[ax][ay][1]) continue; minmax[ax][ay][1] = target;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 148 */     int[][] middle = new int[4][4];
/* 149 */     for (int ay = 0; ay < 4; ay++) {
/* 150 */       for (int ax = 0; ax < 4; ax++) {
/* 151 */         middle[ax][ay] = ((minmax[ax][ay][0] + minmax[ax][ay][1]) / 2);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 158 */     return middle;
/*     */   }
/*     */ 
/*     */   public QRCodeSymbol getQRCodeSymbol(int[][] image) throws SymbolNotFoundException
/*     */   {
/* 163 */     int longSide = image.length < image[0].length ? image[0].length : image.length;
/* 164 */     DECIMAL_POINT = 23 - QRCodeUtility.sqrt(longSide / 256);
/* 165 */     this.bitmap = filterImage(image);
/* 166 */     this.canvas.println("Drawing matrix.");
/* 167 */     this.canvas.drawMatrix(this.bitmap);
/*     */ 
/* 169 */     this.canvas.println("Scanning Finder Pattern.");
/* 170 */     FinderPattern finderPattern = null;
/*     */     try {
/* 172 */       finderPattern = FinderPattern.findFinderPattern(this.bitmap);
/*     */     } catch (FinderPatternNotFoundException e) {
/* 174 */       this.canvas.println("Not found, now retrying...");
/* 175 */       this.bitmap = applyCrossMaskingMedianFilter(this.bitmap, 5);
/* 176 */       this.canvas.drawMatrix(this.bitmap);
/*     */       try {
/* 178 */         finderPattern = FinderPattern.findFinderPattern(this.bitmap);
/*     */       } catch (FinderPatternNotFoundException e2) {
/* 180 */         throw new SymbolNotFoundException(e2.getMessage());
/*     */       } catch (VersionInformationException e2) {
/* 182 */         throw new SymbolNotFoundException(e2.getMessage());
/*     */       }
/*     */     } catch (VersionInformationException e) {
/* 185 */       throw new SymbolNotFoundException(e.getMessage());
/*     */     }
/*     */ 
/* 189 */     this.canvas.println("FinderPattern at");
/* 190 */     String finderPatternCoordinates = 
/* 191 */       finderPattern.getCenter(0).toString() + 
/* 192 */       finderPattern.getCenter(1).toString() + 
/* 193 */       finderPattern.getCenter(2).toString();
/* 194 */     this.canvas.println(finderPatternCoordinates);
/* 195 */     int[] sincos = finderPattern.getAngle();
/* 196 */     this.canvas.println("Angle*4098: Sin " + Integer.toString(sincos[0]) + "  " + "Cos " + Integer.toString(sincos[1]));
/*     */ 
/* 198 */     int version = finderPattern.getVersion();
/* 199 */     this.canvas.println("Version: " + Integer.toString(version));
/* 200 */     if ((version < 1) || (version > 40)) {
/* 201 */       throw new InvalidVersionException("Invalid version: " + version);
/*     */     }
/* 203 */     AlignmentPattern alignmentPattern = null;
/*     */     try {
/* 205 */       alignmentPattern = AlignmentPattern.findAlignmentPattern(this.bitmap, finderPattern);
/*     */     } catch (AlignmentPatternNotFoundException e) {
/* 207 */       throw new SymbolNotFoundException(e.getMessage());
/*     */     }
/*     */ 
/* 210 */     int matrixLength = alignmentPattern.getCenter().length;
/* 211 */     this.canvas.println("AlignmentPatterns at");
/* 212 */     for (int y = 0; y < matrixLength; y++) {
/* 213 */       String alignmentPatternCoordinates = "";
/* 214 */       for (int x = 0; x < matrixLength; x++) {
/* 215 */         alignmentPatternCoordinates = alignmentPatternCoordinates + alignmentPattern.getCenter()[x][y].toString();
/*     */       }
/* 217 */       this.canvas.println(alignmentPatternCoordinates);
/*     */     }
/*     */ 
/* 221 */     this.canvas.println("Creating sampling grid.");
/*     */ 
/* 224 */     this.samplingGrid = getSamplingGrid(finderPattern, alignmentPattern);
/* 225 */     this.canvas.println("Reading grid.");
/* 226 */     boolean[][] qRCodeMatrix = (boolean[][])null;
/*     */     try {
/* 228 */       qRCodeMatrix = getQRCodeMatrix(this.bitmap, this.samplingGrid);
/*     */     } catch (ArrayIndexOutOfBoundsException e) {
/* 230 */       throw new SymbolNotFoundException("Sampling grid exceeded image boundary");
/*     */     }
/*     */ 
/* 233 */     return new QRCodeSymbol(qRCodeMatrix);
/*     */   }
/*     */ 
/*     */   public QRCodeSymbol getQRCodeSymbolWithAdjustedGrid(Point adjust) throws IllegalStateException, SymbolNotFoundException
/*     */   {
/* 238 */     if ((this.bitmap == null) || (this.samplingGrid == null)) {
/* 239 */       throw new IllegalStateException("This method must be called after QRCodeImageReader.getQRCodeSymbol() called");
/*     */     }
/* 241 */     this.samplingGrid.adjust(adjust);
/* 242 */     this.canvas.println("Sampling grid adjusted d(" + adjust.getX() + "," + adjust.getY() + ")");
/*     */ 
/* 244 */     boolean[][] qRCodeMatrix = (boolean[][])null;
/*     */     try {
/* 246 */       qRCodeMatrix = getQRCodeMatrix(this.bitmap, this.samplingGrid);
/*     */     } catch (ArrayIndexOutOfBoundsException e) {
/* 248 */       throw new SymbolNotFoundException("Sampling grid exceeded image boundary");
/*     */     }
/* 250 */     return new QRCodeSymbol(qRCodeMatrix);
/*     */   }
/*     */ 
/*     */   SamplingGrid getSamplingGrid(FinderPattern finderPattern, AlignmentPattern alignmentPattern)
/*     */   {
/* 258 */     Point[][] centers = alignmentPattern.getCenter();
/*     */ 
/* 260 */     int version = finderPattern.getVersion();
/* 261 */     int sqrtCenters = version / 7 + 2;
/*     */ 
/* 263 */     centers[0][0] = finderPattern.getCenter(0);
/* 264 */     centers[(sqrtCenters - 1)][0] = finderPattern.getCenter(1);
/* 265 */     centers[0][(sqrtCenters - 1)] = finderPattern.getCenter(2);
/*     */ 
/* 267 */     int sqrtNumArea = sqrtCenters - 1;
/*     */ 
/* 270 */     SamplingGrid samplingGrid = new SamplingGrid(sqrtNumArea);
/*     */ 
/* 278 */     Axis axis = new Axis(finderPattern.getAngle(), finderPattern.getModuleSize());
/*     */ 
/* 282 */     for (int ay = 0; ay < sqrtNumArea; ay++) {
/* 283 */       for (int ax = 0; ax < sqrtNumArea; ax++) {
/* 284 */         ModulePitch modulePitch = new ModulePitch();
/* 285 */         Line baseLineX = new Line();
/* 286 */         Line baseLineY = new Line();
/* 287 */         axis.setModulePitch(finderPattern.getModuleSize());
/*     */ 
/* 289 */         Point[][] logicalCenters = AlignmentPattern.getLogicalCenter(finderPattern);
/*     */ 
/* 291 */         Point upperLeftPoint = centers[ax][ay];
/* 292 */         Point upperRightPoint = centers[(ax + 1)][ay];
/* 293 */         Point lowerLeftPoint = centers[ax][(ay + 1)];
/* 294 */         Point lowerRightPoint = centers[(ax + 1)][(ay + 1)];
/*     */ 
/* 296 */         Point logicalUpperLeftPoint = logicalCenters[ax][ay];
/* 297 */         Point logicalUpperRightPoint = logicalCenters[(ax + 1)][ay];
/* 298 */         Point logicalLowerLeftPoint = logicalCenters[ax][(ay + 1)];
/* 299 */         Point logicalLowerRightPoint = logicalCenters[(ax + 1)][(ay + 1)];
/*     */ 
/* 301 */         if ((ax == 0) && (ay == 0))
/*     */         {
/* 303 */           if (sqrtNumArea == 1) {
/* 304 */             upperLeftPoint = axis.translate(upperLeftPoint, -3, -3);
/* 305 */             upperRightPoint = axis.translate(upperRightPoint, 3, -3);
/* 306 */             lowerLeftPoint = axis.translate(lowerLeftPoint, -3, 3);
/* 307 */             lowerRightPoint = axis.translate(lowerRightPoint, 6, 6);
/*     */ 
/* 309 */             logicalUpperLeftPoint.translate(-6, -6);
/* 310 */             logicalUpperRightPoint.translate(3, -3);
/* 311 */             logicalLowerLeftPoint.translate(-3, 3);
/* 312 */             logicalLowerRightPoint.translate(6, 6);
/*     */           }
/*     */           else {
/* 315 */             upperLeftPoint = axis.translate(upperLeftPoint, -3, -3);
/* 316 */             upperRightPoint = axis.translate(upperRightPoint, 0, -6);
/* 317 */             lowerLeftPoint = axis.translate(lowerLeftPoint, -6, 0);
/*     */ 
/* 319 */             logicalUpperLeftPoint.translate(-6, -6);
/* 320 */             logicalUpperRightPoint.translate(0, -6);
/* 321 */             logicalLowerLeftPoint.translate(-6, 0);
/*     */           }
/*     */         }
/* 324 */         else if ((ax == 0) && (ay == sqrtNumArea - 1))
/*     */         {
/* 326 */           upperLeftPoint = axis.translate(upperLeftPoint, -6, 0);
/* 327 */           lowerLeftPoint = axis.translate(lowerLeftPoint, -3, 3);
/* 328 */           lowerRightPoint = axis.translate(lowerRightPoint, 0, 6);
/*     */ 
/* 331 */           logicalUpperLeftPoint.translate(-6, 0);
/* 332 */           logicalLowerLeftPoint.translate(-6, 6);
/* 333 */           logicalLowerRightPoint.translate(0, 6);
/*     */         }
/* 335 */         else if ((ax == sqrtNumArea - 1) && (ay == 0))
/*     */         {
/* 337 */           upperLeftPoint = axis.translate(upperLeftPoint, 0, -6);
/* 338 */           upperRightPoint = axis.translate(upperRightPoint, 3, -3);
/* 339 */           lowerRightPoint = axis.translate(lowerRightPoint, 6, 0);
/*     */ 
/* 341 */           logicalUpperLeftPoint.translate(0, -6);
/* 342 */           logicalUpperRightPoint.translate(6, -6);
/* 343 */           logicalLowerRightPoint.translate(6, 0);
/*     */         }
/* 345 */         else if ((ax == sqrtNumArea - 1) && (ay == sqrtNumArea - 1))
/*     */         {
/* 347 */           lowerLeftPoint = axis.translate(lowerLeftPoint, 0, 6);
/* 348 */           upperRightPoint = axis.translate(upperRightPoint, 6, 0);
/* 349 */           lowerRightPoint = axis.translate(lowerRightPoint, 6, 6);
/*     */ 
/* 351 */           logicalLowerLeftPoint.translate(0, 6);
/* 352 */           logicalUpperRightPoint.translate(6, 0);
/* 353 */           logicalLowerRightPoint.translate(6, 6);
/*     */         }
/* 355 */         else if (ax == 0)
/*     */         {
/* 357 */           upperLeftPoint = axis.translate(upperLeftPoint, -6, 0);
/* 358 */           lowerLeftPoint = axis.translate(lowerLeftPoint, -6, 0);
/*     */ 
/* 360 */           logicalUpperLeftPoint.translate(-6, 0);
/* 361 */           logicalLowerLeftPoint.translate(-6, 0);
/*     */         }
/* 364 */         else if (ax == sqrtNumArea - 1)
/*     */         {
/* 366 */           upperRightPoint = axis.translate(upperRightPoint, 6, 0);
/* 367 */           lowerRightPoint = axis.translate(lowerRightPoint, 6, 0);
/*     */ 
/* 369 */           logicalUpperRightPoint.translate(6, 0);
/* 370 */           logicalLowerRightPoint.translate(6, 0);
/*     */         }
/* 372 */         else if (ay == 0)
/*     */         {
/* 374 */           upperLeftPoint = axis.translate(upperLeftPoint, 0, -6);
/* 375 */           upperRightPoint = axis.translate(upperRightPoint, 0, -6);
/*     */ 
/* 377 */           logicalUpperLeftPoint.translate(0, -6);
/* 378 */           logicalUpperRightPoint.translate(0, -6);
/*     */         }
/* 381 */         else if (ay == sqrtNumArea - 1)
/*     */         {
/* 383 */           lowerLeftPoint = axis.translate(lowerLeftPoint, 0, 6);
/* 384 */           lowerRightPoint = axis.translate(lowerRightPoint, 0, 6);
/*     */ 
/* 386 */           logicalLowerLeftPoint.translate(0, 6);
/* 387 */           logicalLowerRightPoint.translate(0, 6);
/*     */         }
/*     */ 
/* 390 */         if (ax == 0)
/*     */         {
/* 392 */           logicalUpperRightPoint.translate(1, 0);
/* 393 */           logicalLowerRightPoint.translate(1, 0);
/*     */         }
/*     */         else
/*     */         {
/* 397 */           logicalUpperLeftPoint.translate(-1, 0);
/* 398 */           logicalLowerLeftPoint.translate(-1, 0);
/*     */         }
/*     */ 
/* 401 */         if (ay == 0)
/*     */         {
/* 403 */           logicalLowerLeftPoint.translate(0, 1);
/* 404 */           logicalLowerRightPoint.translate(0, 1);
/*     */         }
/*     */         else
/*     */         {
/* 408 */           logicalUpperLeftPoint.translate(0, -1);
/* 409 */           logicalUpperRightPoint.translate(0, -1);
/*     */         }
/*     */ 
/* 412 */         int logicalWidth = logicalUpperRightPoint.getX() - logicalUpperLeftPoint.getX();
/* 413 */         int logicalHeight = logicalLowerLeftPoint.getY() - logicalUpperLeftPoint.getY();
/*     */ 
/* 415 */         if (version < 7) {
/* 416 */           logicalWidth += 3;
/* 417 */           logicalHeight += 3;
/*     */         }
/*     */ 
/* 420 */         modulePitch.top = getAreaModulePitch(upperLeftPoint, upperRightPoint, logicalWidth - 1);
/* 421 */         modulePitch.left = getAreaModulePitch(upperLeftPoint, lowerLeftPoint, logicalHeight - 1);
/* 422 */         modulePitch.bottom = getAreaModulePitch(lowerLeftPoint, lowerRightPoint, logicalWidth - 1);
/* 423 */         modulePitch.right = getAreaModulePitch(upperRightPoint, lowerRightPoint, logicalHeight - 1);
/*     */ 
/* 425 */         baseLineX.setP1(upperLeftPoint);
/* 426 */         baseLineY.setP1(upperLeftPoint);
/* 427 */         baseLineX.setP2(lowerLeftPoint);
/* 428 */         baseLineY.setP2(upperRightPoint);
/*     */ 
/* 430 */         samplingGrid.initGrid(ax, ay, logicalWidth, logicalHeight);
/*     */ 
/* 432 */         for (int i = 0; i < logicalWidth; i++) {
/* 433 */           Line gridLineX = new Line(baseLineX.getP1(), baseLineX.getP2());
/*     */ 
/* 435 */           axis.setOrigin(gridLineX.getP1());
/* 436 */           axis.setModulePitch(modulePitch.top);
/* 437 */           gridLineX.setP1(axis.translate(i, 0));
/*     */ 
/* 439 */           axis.setOrigin(gridLineX.getP2());
/* 440 */           axis.setModulePitch(modulePitch.bottom);
/* 441 */           gridLineX.setP2(axis.translate(i, 0));
/*     */ 
/* 443 */           samplingGrid.setXLine(ax, ay, i, gridLineX);
/*     */         }
/*     */ 
/* 446 */         for (int i = 0; i < logicalHeight; i++)
/*     */         {
/* 448 */           Line gridLineY = new Line(baseLineY.getP1(), baseLineY.getP2());
/*     */ 
/* 450 */           axis.setOrigin(gridLineY.getP1());
/* 451 */           axis.setModulePitch(modulePitch.left);
/* 452 */           gridLineY.setP1(axis.translate(0, i));
/*     */ 
/* 454 */           axis.setOrigin(gridLineY.getP2());
/* 455 */           axis.setModulePitch(modulePitch.right);
/* 456 */           gridLineY.setP2(axis.translate(0, i));
/*     */ 
/* 458 */           samplingGrid.setYLine(ax, ay, i, gridLineY);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 464 */     return samplingGrid;
/*     */   }
/*     */ 
/*     */   int getAreaModulePitch(Point start, Point end, int logicalDistance)
/*     */   {
/* 472 */     Line tempLine = new Line(start, end);
/* 473 */     int realDistance = tempLine.getLength();
/* 474 */     int modulePitch = (realDistance << DECIMAL_POINT) / logicalDistance;
/* 475 */     return modulePitch;
/*     */   }
/*     */ 
/*     */   boolean[][] getQRCodeMatrix(boolean[][] image, SamplingGrid gridLines)
/*     */     throws ArrayIndexOutOfBoundsException
/*     */   {
/* 482 */     int gridSize = gridLines.getTotalWidth();
/*     */ 
/* 488 */     this.canvas.println("gridSize=" + gridSize);
/*     */ 
/* 490 */     Point bottomRightPoint = null;
/* 491 */     boolean[][] sampledMatrix = new boolean[gridSize][gridSize];
/* 492 */     for (int ay = 0; ay < gridLines.getHeight(); ay++) {
/* 493 */       for (int ax = 0; ax < gridLines.getWidth(); ax++) {
/* 494 */         Vector sampledPoints = new Vector();
/* 495 */         for (int y = 0; y < gridLines.getHeight(ax, ay); y++) {
/* 496 */           for (int x = 0; x < gridLines.getWidth(ax, ay); x++) {
/* 497 */             int x1 = gridLines.getXLine(ax, ay, x).getP1().getX();
/* 498 */             int y1 = gridLines.getXLine(ax, ay, x).getP1().getY();
/* 499 */             int x2 = gridLines.getXLine(ax, ay, x).getP2().getX();
/* 500 */             int y2 = gridLines.getXLine(ax, ay, x).getP2().getY();
/* 501 */             int x3 = gridLines.getYLine(ax, ay, y).getP1().getX();
/* 502 */             int y3 = gridLines.getYLine(ax, ay, y).getP1().getY();
/* 503 */             int x4 = gridLines.getYLine(ax, ay, y).getP2().getX();
/* 504 */             int y4 = gridLines.getYLine(ax, ay, y).getP2().getY();
/*     */ 
/* 506 */             int e = (y2 - y1) * (x3 - x4) - (y4 - y3) * (x1 - x2);
/* 507 */             int f = (x1 * y2 - x2 * y1) * (x3 - x4) - (x3 * y4 - x4 * y3) * (x1 - x2);
/* 508 */             int g = (x3 * y4 - x4 * y3) * (y2 - y1) - (x1 * y2 - x2 * y1) * (y4 - y3);
/* 509 */             sampledMatrix[gridLines.getX(ax, x)][gridLines.getY(ay, y)] = image[(f / e)][(g / e)];
/* 510 */             if ((ay != gridLines.getHeight() - 1) || (ax != gridLines.getWidth() - 1) || 
/* 511 */               (y != gridLines.getHeight(ax, ay) - 1) || (x != gridLines.getWidth(ax, ay) - 1)) continue;
/* 512 */             bottomRightPoint = new Point(f / e, g / e);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 520 */     if ((bottomRightPoint != null) && ((bottomRightPoint.getX() > image.length - 1) || (bottomRightPoint.getY() > image[0].length - 1)))
/* 521 */       throw new ArrayIndexOutOfBoundsException("Sampling grid pointed out of image");
/* 522 */     this.canvas.drawPoint(bottomRightPoint, 8947967);
/*     */ 
/* 524 */     return sampledMatrix;
/*     */   }
/*     */ 
/*     */   protected class ModulePitch
/*     */   {
/*     */     public int top;
/*     */     public int left;
/*     */     public int bottom;
/*     */     public int right;
/*     */ 
/*     */     protected ModulePitch()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.reader.QRCodeImageReader
 * JD-Core Version:    0.6.0
 */