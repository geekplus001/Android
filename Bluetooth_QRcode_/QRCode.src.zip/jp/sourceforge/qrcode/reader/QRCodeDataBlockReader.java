/*     */ package jp.sourceforge.qrcode.reader;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jp.sourceforge.qrcode.QRCodeDecoder;
/*     */ import jp.sourceforge.qrcode.exception.InvalidDataBlockException;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvas;
/*     */ 
/*     */ public class QRCodeDataBlockReader
/*     */ {
/*     */   int[] blocks;
/*     */   int dataLengthMode;
/*     */   int blockPointer;
/*     */   int bitPointer;
/*     */   int dataLength;
/*     */   int numErrorCorrectionCode;
/*     */   DebugCanvas canvas;
/*     */   static final int MODE_NUMBER = 1;
/*     */   static final int MODE_ROMAN_AND_NUMBER = 2;
/*     */   static final int MODE_8BIT_BYTE = 4;
/*     */   static final int MODE_KANJI = 8;
/*  27 */   final int[][] sizeOfDataLengthInfo = { 
/*  28 */     { 10, 9, 8, 8 }, { 12, 11, 16, 10 }, { 14, 13, 16, 12 } };
/*     */ 
/*     */   public QRCodeDataBlockReader(int[] blocks, int version, int numErrorCorrectionCode)
/*     */   {
/*  32 */     this.blockPointer = 0;
/*  33 */     this.bitPointer = 7;
/*  34 */     this.dataLength = 0;
/*  35 */     this.blocks = blocks;
/*  36 */     this.numErrorCorrectionCode = numErrorCorrectionCode;
/*  37 */     if (version <= 9) this.dataLengthMode = 0;
/*  38 */     else if ((version >= 10) && (version <= 26)) this.dataLengthMode = 1;
/*  39 */     else if ((version >= 27) && (version <= 40)) this.dataLengthMode = 2;
/*  40 */     this.canvas = QRCodeDecoder.getCanvas();
/*     */   }
/*     */ 
/*     */   int getNextBits(int numBits)
/*     */     throws ArrayIndexOutOfBoundsException
/*     */   {
/*  47 */     int bits = 0;
/*  48 */     if (numBits < this.bitPointer + 1) {
/*  49 */       int mask = 0;
/*  50 */       for (int i = 0; i < numBits; i++) {
/*  51 */         mask += (1 << i);
/*     */       }
/*  53 */       mask <<= this.bitPointer - numBits + 1;
/*     */ 
/*  55 */       bits = (this.blocks[this.blockPointer] & mask) >> this.bitPointer - numBits + 1;
/*  56 */       this.bitPointer -= numBits;
/*  57 */       return bits;
/*     */     }
/*  59 */     if (numBits < this.bitPointer + 1 + 8) {
/*  60 */       int mask1 = 0;
/*  61 */       for (int i = 0; i < this.bitPointer + 1; i++) {
/*  62 */         mask1 += (1 << i);
/*     */       }
/*  64 */       bits = (this.blocks[this.blockPointer] & mask1) << numBits - (this.bitPointer + 1);
/*  65 */       this.blockPointer += 1;
/*  66 */       bits += (this.blocks[this.blockPointer] >> 8 - (numBits - (this.bitPointer + 1)));
/*     */ 
/*  68 */       this.bitPointer -= numBits % 8;
/*  69 */       if (this.bitPointer < 0) {
/*  70 */         this.bitPointer += 8;
/*     */       }
/*  72 */       return bits;
/*     */     }
/*  74 */     if (numBits < this.bitPointer + 1 + 16) {
/*  75 */       int mask1 = 0;
/*  76 */       int mask3 = 0;
/*     */ 
/*  80 */       for (int i = 0; i < this.bitPointer + 1; i++) {
/*  81 */         mask1 += (1 << i);
/*     */       }
/*  83 */       int bitsFirstBlock = (this.blocks[this.blockPointer] & mask1) << numBits - (this.bitPointer + 1);
/*  84 */       this.blockPointer += 1;
/*     */ 
/*  86 */       int bitsSecondBlock = this.blocks[this.blockPointer] << numBits - (this.bitPointer + 1 + 8);
/*  87 */       this.blockPointer += 1;
/*     */ 
/*  89 */       for (int i = 0; i < numBits - (this.bitPointer + 1 + 8); i++) {
/*  90 */         mask3 += (1 << i);
/*     */       }
/*  92 */       mask3 <<= 8 - (numBits - (this.bitPointer + 1 + 8));
/*  93 */       int bitsThirdBlock = (this.blocks[this.blockPointer] & mask3) >> 8 - (numBits - (this.bitPointer + 1 + 8));
/*     */ 
/*  95 */       bits = bitsFirstBlock + bitsSecondBlock + bitsThirdBlock;
/*  96 */       this.bitPointer -= (numBits - 8) % 8;
/*  97 */       if (this.bitPointer < 0) {
/*  98 */         this.bitPointer += 8;
/*     */       }
/* 100 */       return bits;
/*     */     }
/*     */ 
/* 103 */     System.out.println("ERROR!");
/* 104 */     return 0;
/*     */   }
/*     */ 
/*     */   int getNextMode()
/*     */     throws ArrayIndexOutOfBoundsException
/*     */   {
/* 110 */     if (this.blockPointer > this.blocks.length - this.numErrorCorrectionCode - 2) {
/* 111 */       return 0;
/*     */     }
/* 113 */     return getNextBits(4);
/*     */   }
/*     */ 
/*     */   int guessMode(int mode)
/*     */   {
/* 124 */     switch (mode) {
/*     */     case 3:
/* 126 */       return 1;
/*     */     case 5:
/* 128 */       return 4;
/*     */     case 6:
/* 130 */       return 4;
/*     */     case 7:
/* 132 */       return 4;
/*     */     case 9:
/* 134 */       return 8;
/*     */     case 10:
/* 136 */       return 8;
/*     */     case 11:
/* 138 */       return 8;
/*     */     case 12:
/* 140 */       return 4;
/*     */     case 13:
/* 142 */       return 4;
/*     */     case 14:
/* 144 */       return 4;
/*     */     case 15:
/* 146 */       return 4;
/*     */     case 4:
/* 148 */     case 8: } return 8;
/*     */   }
/*     */ 
/*     */   int getDataLength(int modeIndicator) throws ArrayIndexOutOfBoundsException
/*     */   {
/* 153 */     int index = 0;
/*     */ 
/* 155 */     while (modeIndicator >> index != 1)
/*     */     {
/* 157 */       index++;
/*     */     }
/*     */ 
/* 160 */     return getNextBits(this.sizeOfDataLengthInfo[this.dataLengthMode][index]);
/*     */   }
/*     */ 
/*     */   public byte[] getDataByte() throws InvalidDataBlockException {
/* 164 */     this.canvas.println("Reading data blocks.");
/* 165 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/*     */       while (true) {
/* 169 */         int mode = getNextMode();
/*     */ 
/* 171 */         if (mode == 0) {
/* 172 */           if (output.size() > 0) {
/*     */             break;
/*     */           }
/* 175 */           throw new InvalidDataBlockException("Empty data block");
/*     */         }
/*     */ 
/* 180 */         if ((mode != 1) && (mode != 2) && 
/* 181 */           (mode != 4) && (mode != 8))
/*     */         {
/* 185 */           throw new InvalidDataBlockException("Invalid mode: " + mode + " in (block:" + this.blockPointer + " bit:" + this.bitPointer + ")");
/*     */         }
/* 187 */         this.dataLength = getDataLength(mode);
/* 188 */         if (this.dataLength < 1) {
/* 189 */           throw new InvalidDataBlockException("Invalid data length: " + this.dataLength);
/*     */         }
/* 191 */         switch (mode)
/*     */         {
/*     */         case 1:
/* 194 */           output.write(getFigureString(this.dataLength).getBytes());
/* 195 */           break;
/*     */         case 2:
/* 198 */           output.write(getRomanAndFigureString(this.dataLength).getBytes());
/* 199 */           break;
/*     */         case 4:
/* 202 */           output.write(get8bitByteArray(this.dataLength));
/* 203 */           break;
/*     */         case 8:
/* 206 */           output.write(getKanjiString(this.dataLength).getBytes());
/*     */         case 3:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 215 */       throw new InvalidDataBlockException("Data Block Error in (block:" + this.blockPointer + " bit:" + this.bitPointer + ")");
/*     */     } catch (IOException e) {
/* 217 */       throw new InvalidDataBlockException(e.getMessage());
/*     */     }
/* 219 */     return output.toByteArray();
/*     */   }
/*     */ 
/*     */   public String getDataString() throws ArrayIndexOutOfBoundsException {
/* 223 */     this.canvas.println("Reading data blocks...");
/* 224 */     String dataString = "";
/*     */     while (true) {
/* 226 */       int mode = getNextMode();
/* 227 */       this.canvas.println("mode: " + mode);
/* 228 */       if (mode == 0)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 233 */       if ((mode != 1) && (mode != 2) && 
/* 234 */         (mode != 4));
/* 240 */       this.dataLength = getDataLength(mode);
/* 241 */       this.canvas.println(Integer.toString(this.blocks[this.blockPointer]));
/* 242 */       System.out.println("length: " + this.dataLength);
/* 243 */       switch (mode)
/*     */       {
/*     */       case 1:
/* 246 */         dataString = dataString + getFigureString(this.dataLength);
/* 247 */         break;
/*     */       case 2:
/* 250 */         dataString = dataString + getRomanAndFigureString(this.dataLength);
/* 251 */         break;
/*     */       case 4:
/* 254 */         dataString = dataString + get8bitByteString(this.dataLength);
/* 255 */         break;
/*     */       case 8:
/* 258 */         dataString = dataString + getKanjiString(this.dataLength);
/*     */       case 3:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       }
/*     */     }
/* 264 */     System.out.println("");
/* 265 */     return dataString;
/*     */   }
/*     */ 
/*     */   String getFigureString(int dataLength) throws ArrayIndexOutOfBoundsException
/*     */   {
/* 270 */     int length = dataLength;
/* 271 */     int intData = 0;
/* 272 */     String strData = "";
/*     */     do {
/* 274 */       if (length >= 3) {
/* 275 */         intData = getNextBits(10);
/* 276 */         if (intData < 100) strData = strData + "0";
/* 277 */         if (intData < 10) strData = strData + "0";
/* 278 */         length -= 3;
/*     */       }
/* 280 */       else if (length == 2) {
/* 281 */         intData = getNextBits(7);
/* 282 */         if (intData < 10) strData = strData + "0";
/* 283 */         length -= 2;
/*     */       }
/* 285 */       else if (length == 1) {
/* 286 */         intData = getNextBits(4);
/* 287 */         length--;
/*     */       }
/* 289 */       strData = strData + Integer.toString(intData);
/* 290 */     }while (length > 0);
/*     */ 
/* 292 */     return strData;
/*     */   }
/*     */ 
/*     */   String getRomanAndFigureString(int dataLength) throws ArrayIndexOutOfBoundsException {
/* 296 */     int length = dataLength;
/* 297 */     int intData = 0;
/* 298 */     String strData = "";
/* 299 */     char[] tableRomanAndFigure = { 
/* 300 */       '0', '1', '2', '3', '4', '5', 
/* 301 */       '6', '7', '8', '9', 'A', 'B', 
/* 302 */       'C', 'D', 'E', 'F', 'G', 'H', 
/* 303 */       'I', 'J', 'K', 'L', 'M', 'N', 
/* 304 */       'O', 'P', 'Q', 'R', 'S', 'T', 
/* 305 */       'U', 'V', 'W', 'X', 'Y', 'Z', 
/* 306 */       ' ', '$', '%', '*', '+', '-', 
/* 307 */       '.', '/', ':' };
/*     */     do
/*     */     {
/* 310 */       if (length > 1) {
/* 311 */         intData = getNextBits(11);
/* 312 */         int firstLetter = intData / 45;
/* 313 */         int secondLetter = intData % 45;
/* 314 */         strData = strData + String.valueOf(tableRomanAndFigure[firstLetter]);
/* 315 */         strData = strData + String.valueOf(tableRomanAndFigure[secondLetter]);
/* 316 */         length -= 2;
/*     */       }
/* 318 */       else if (length == 1) {
/* 319 */         intData = getNextBits(6);
/* 320 */         strData = strData + String.valueOf(tableRomanAndFigure[intData]);
/* 321 */         length--;
/*     */       }
/*     */     }
/* 323 */     while (length > 0);
/*     */ 
/* 325 */     return strData;
/*     */   }
/*     */ 
/*     */   public byte[] get8bitByteArray(int dataLength) throws ArrayIndexOutOfBoundsException {
/* 329 */     int length = dataLength;
/* 330 */     int intData = 0;
/* 331 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/*     */     do
/*     */     {
/* 334 */       intData = getNextBits(8);
/* 335 */       output.write((byte)intData);
/* 336 */       length--;
/* 337 */     }while (length > 0);
/* 338 */     return output.toByteArray();
/*     */   }
/*     */ 
/*     */   String get8bitByteString(int dataLength) throws ArrayIndexOutOfBoundsException {
/* 342 */     int length = dataLength;
/* 343 */     int intData = 0;
/* 344 */     String strData = "";
/*     */     do {
/* 346 */       intData = getNextBits(8);
/* 347 */       strData = strData + (char)intData;
/* 348 */       length--;
/* 349 */     }while (length > 0);
/* 350 */     return strData;
/*     */   }
/*     */ 
/*     */   String getKanjiString(int dataLength) throws ArrayIndexOutOfBoundsException {
/* 354 */     int length = dataLength;
/* 355 */     int intData = 0;
/* 356 */     String unicodeString = "";
/*     */     do {
/* 358 */       intData = getNextBits(13);
/* 359 */       int lowerByte = intData % 192;
/* 360 */       int higherByte = intData / 192;
/*     */ 
/* 362 */       int tempWord = (higherByte << 8) + lowerByte;
/* 363 */       int shiftjisWord = 0;
/* 364 */       if (tempWord + 33088 <= 40956) {
/* 365 */         shiftjisWord = tempWord + 33088;
/*     */       }
/*     */       else {
/* 368 */         shiftjisWord = tempWord + 49472;
/*     */       }
/*     */ 
/* 371 */       byte[] tempByte = new byte[2];
/* 372 */       tempByte[0] = (byte)(shiftjisWord >> 8);
/* 373 */       tempByte[1] = (byte)(shiftjisWord & 0xFF);
/*     */       try {
/* 375 */         unicodeString = unicodeString + new String(tempByte, "Shift_JIS");
/*     */       } catch (UnsupportedEncodingException e) {
/* 377 */         e.printStackTrace();
/*     */       }
/* 379 */       length--;
/* 380 */     }while (length > 0);
/*     */ 
/* 383 */     return unicodeString;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.reader.QRCodeDataBlockReader
 * JD-Core Version:    0.6.0
 */