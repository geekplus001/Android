/*     */ package jp.sourceforge.qrcode.pattern;
/*     */ 
/*     */ import jp.sourceforge.qrcode.QRCodeDecoder;
/*     */ import jp.sourceforge.qrcode.exception.AlignmentPatternNotFoundException;
/*     */ import jp.sourceforge.qrcode.exception.InvalidVersionException;
/*     */ import jp.sourceforge.qrcode.geom.Axis;
/*     */ import jp.sourceforge.qrcode.geom.Line;
/*     */ import jp.sourceforge.qrcode.geom.Point;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvas;
/*     */ 
/*     */ public class AlignmentPattern
/*     */ {
/*     */   static final int RIGHT = 1;
/*     */   static final int BOTTOM = 2;
/*     */   static final int LEFT = 3;
/*     */   static final int TOP = 4;
/*  17 */   static DebugCanvas canvas = QRCodeDecoder.getCanvas();
/*     */   Point[][] center;
/*     */   int patternDistance;
/*     */ 
/*     */   AlignmentPattern(Point[][] center, int patternDistance)
/*     */   {
/*  23 */     this.center = center;
/*  24 */     this.patternDistance = patternDistance;
/*     */   }
/*     */ 
/*     */   public static AlignmentPattern findAlignmentPattern(boolean[][] image, FinderPattern finderPattern)
/*     */     throws AlignmentPatternNotFoundException, InvalidVersionException
/*     */   {
/*  30 */     Point[][] logicalCenters = getLogicalCenter(finderPattern);
/*  31 */     int logicalDistance = logicalCenters[1][0].getX() - logicalCenters[0][0].getX();
/*     */ 
/*  33 */     Point[][] centers = (Point[][])null;
/*  34 */     centers = getCenter(image, finderPattern, logicalCenters);
/*  35 */     return new AlignmentPattern(centers, logicalDistance);
/*     */   }
/*     */ 
/*     */   public Point[][] getCenter()
/*     */   {
/*  40 */     return this.center;
/*     */   }
/*     */ 
/*     */   public void setCenter(Point[][] center)
/*     */   {
/*  45 */     this.center = center;
/*     */   }
/*     */ 
/*     */   public int getLogicalDistance() {
/*  49 */     return this.patternDistance;
/*     */   }
/*     */ 
/*     */   static Point[][] getCenter(boolean[][] image, FinderPattern finderPattern, Point[][] logicalCenters) throws AlignmentPatternNotFoundException
/*     */   {
/*  54 */     int moduleSize = finderPattern.getModuleSize();
/*     */ 
/*  56 */     Axis axis = new Axis(finderPattern.getAngle(), moduleSize);
/*  57 */     int sqrtCenters = logicalCenters.length;
/*  58 */     Point[][] centers = new Point[sqrtCenters][sqrtCenters];
/*     */ 
/*  60 */     axis.setOrigin(finderPattern.getCenter(0));
/*  61 */     centers[0][0] = axis.translate(3, 3);
/*  62 */     canvas.drawCross(centers[0][0], 8947967);
/*     */ 
/*  64 */     axis.setOrigin(finderPattern.getCenter(1));
/*  65 */     centers[(sqrtCenters - 1)][0] = axis.translate(-3, 3);
/*  66 */     canvas.drawCross(centers[(sqrtCenters - 1)][0], 8947967);
/*     */ 
/*  68 */     axis.setOrigin(finderPattern.getCenter(2));
/*  69 */     centers[0][(sqrtCenters - 1)] = axis.translate(3, -3);
/*  70 */     canvas.drawCross(centers[0][(sqrtCenters - 1)], 8947967);
/*     */ 
/*  72 */     Point tmpPoint = centers[0][0];
/*     */ 
/*  74 */     for (int y = 0; y < sqrtCenters; y++) {
/*  75 */       for (int x = 0; x < sqrtCenters; x++) {
/*  76 */         if (((x == 0) && (y == 0)) || ((x == 0) && (y == sqrtCenters - 1)) || ((x == sqrtCenters - 1) && (y == 0)))
/*     */         {
/*     */           continue;
/*     */         }
/*  80 */         Point target = null;
/*  81 */         if (y == 0) {
/*  82 */           if ((x > 0) && (x < sqrtCenters - 1)) {
/*  83 */             target = axis.translate(centers[(x - 1)][y], logicalCenters[x][y].getX() - logicalCenters[(x - 1)][y].getX(), 0);
/*  84 */             centers[x][y] = new Point(target.getX(), target.getY());
/*  85 */             canvas.drawCross(centers[x][y], 267946120);
/*     */           }
/*     */         }
/*  88 */         else if (x == 0) {
/*  89 */           if ((y > 0) && (y < sqrtCenters - 1)) {
/*  90 */             target = axis.translate(centers[x][(y - 1)], 0, logicalCenters[x][y].getY() - logicalCenters[x][(y - 1)].getY());
/*  91 */             centers[x][y] = new Point(target.getX(), target.getY());
/*  92 */             canvas.drawCross(centers[x][y], 267946120);
/*     */           }
/*     */         }
/*     */         else {
/*  96 */           Point t1 = axis.translate(centers[(x - 1)][y], logicalCenters[x][y].getX() - logicalCenters[(x - 1)][y].getX(), 0);
/*  97 */           Point t2 = axis.translate(centers[x][(y - 1)], 0, logicalCenters[x][y].getY() - logicalCenters[x][(y - 1)].getY());
/*  98 */           centers[x][y] = new Point((t1.getX() + t2.getX()) / 2, (t1.getY() + t2.getY()) / 2 + 1);
/*     */         }
/* 100 */         if (finderPattern.getVersion() > 1) {
/* 101 */           Point precisionCenter = getPrecisionCenter(image, centers[x][y]);
/*     */ 
/* 104 */           canvas.drawCross(centers[x][y], 267946120);
/* 105 */           int dx = precisionCenter.getX() - centers[x][y].getX();
/* 106 */           int dy = precisionCenter.getY() - centers[x][y].getY();
/* 107 */           canvas.println("Adjust AP(" + x + "," + y + ") to d(" + dx + "," + dy + ")");
/*     */ 
/* 109 */           centers[x][y] = precisionCenter;
/*     */         }
/*     */ 
/* 112 */         canvas.drawCross(centers[x][y], 8947967);
/* 113 */         canvas.drawLine(new Line(tmpPoint, centers[x][y]), 12303359);
/* 114 */         tmpPoint = centers[x][y];
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 164 */     return centers;
/*     */   }
/*     */ 
/*     */   static Point getPrecisionCenter(boolean[][] image, Point targetPoint)
/*     */     throws AlignmentPatternNotFoundException
/*     */   {
/* 235 */     int tx = targetPoint.getX(); int ty = targetPoint.getY();
/* 236 */     if ((tx < 0) || (ty < 0) || (tx > image.length - 1) || (ty > image[0].length - 1)) {
/* 237 */       throw new AlignmentPatternNotFoundException("Alignment Pattern finder exceeded out of image");
/*     */     }
/* 239 */     if (image[targetPoint.getX()][targetPoint.getY()] == 0) {
/* 240 */       int scope = 0;
/* 241 */       boolean found = false;
/* 242 */       while (!found) {
/* 243 */         scope++;
/* 244 */         for (int dy = scope; dy > -scope; dy--)
/* 245 */           for (int dx = scope; dx > -scope; dx--) {
/* 246 */             int x = targetPoint.getX() + dx;
/* 247 */             int y = targetPoint.getY() + dy;
/* 248 */             if ((x < 0) || (y < 0) || (x > image.length - 1) || (y > image[0].length - 1))
/* 249 */               throw new AlignmentPatternNotFoundException("Alignment Pattern finder exceeded out of image");
/* 250 */             if (image[x][y] != 0) {
/* 251 */               targetPoint = new Point(targetPoint.getX() + dx, targetPoint.getY() + dy);
/* 252 */               canvas.drawPoint(targetPoint, 267946120);
/* 253 */               found = true;
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     int rx;
/*     */     int lx;
/* 260 */     int x = lx = rx = targetPoint.getX();
/*     */     int dy;
/*     */     int uy;
/* 261 */     int y = uy = dy = targetPoint.getY();
/*     */     while (true)
/*     */     {
/* 264 */       lx--; if (lx < 1) break; if (targetPointOnTheCorner(image, lx, y, lx - 1, y))
/* 265 */         break; 
/*     */     }while (true) { rx++; if (rx >= image.length - 1) break; if (targetPointOnTheCorner(image, rx, y, rx + 1, y))
/* 266 */         break;  } do {
/* 266 */       uy--; if (uy < 1) break; 
/* 266 */     }while (!targetPointOnTheCorner(image, x, uy, x, uy - 1));
/* 267 */     while ((dy < image[0].length - 1) && (!targetPointOnTheCorner(image, x, dy, x, dy + 1))) dy++;
/*     */ 
/* 269 */     return new Point((lx + rx + 1) / 2, (uy + dy + 1) / 2);
/*     */   }
/*     */ 
/*     */   static boolean targetPointOnTheCorner(boolean[][] image, int x, int y, int nx, int ny) {
/* 273 */     if ((x < 0) || (y < 0) || (nx < 0) || (ny < 0) || (x > image.length) || (y > image[0].length) || (nx > image.length) || (ny > image[0].length))
/*     */     {
/* 275 */       throw new AlignmentPatternNotFoundException("Alignment Pattern Finder exceeded image edge");
/*     */     }
/*     */ 
/* 280 */     return (image[x][y] == 0) && 
/* 280 */       (image[nx][ny] != 0);
/*     */   }
/*     */ 
/*     */   public static Point[][] getLogicalCenter(FinderPattern finderPattern)
/*     */   {
/* 286 */     int version = finderPattern.getVersion();
/* 287 */     Point[][] logicalCenters = new Point[1][1];
/* 288 */     int[] logicalSeeds = new int[1];
/*     */ 
/* 296 */     logicalSeeds = LogicalSeed.getSeed(version);
/* 297 */     logicalCenters = new Point[logicalSeeds.length][logicalSeeds.length];
/*     */ 
/* 300 */     for (int col = 0; col < logicalCenters.length; col++) {
/* 301 */       for (int row = 0; row < logicalCenters.length; row++) {
/* 302 */         logicalCenters[row][col] = new Point(logicalSeeds[row], logicalSeeds[col]);
/*     */       }
/*     */     }
/* 305 */     return logicalCenters;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.pattern.AlignmentPattern
 * JD-Core Version:    0.6.0
 */