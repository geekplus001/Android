/*    */ package jp.sourceforge.qrcode.pattern;
/*    */ 
/*    */ public class LogicalSeed
/*    */ {
/* 17 */   private static int[][] seed = new int[40][];
/*    */ 
/* 18 */   static { seed[0] = { 6, 14 };
/* 19 */     seed[1] = { 6, 18 };
/* 20 */     seed[2] = { 6, 22 };
/* 21 */     seed[3] = { 6, 26 };
/* 22 */     seed[4] = { 6, 30 };
/* 23 */     seed[5] = { 6, 34 };
/* 24 */     seed[6] = { 6, 22, 38 };
/* 25 */     seed[7] = { 6, 24, 42 };
/* 26 */     seed[8] = { 6, 26, 46 };
/* 27 */     seed[9] = { 6, 28, 50 };
/* 28 */     seed[10] = { 6, 30, 54 };
/* 29 */     seed[11] = { 6, 32, 58 };
/* 30 */     seed[12] = { 6, 34, 62 };
/* 31 */     seed[13] = { 6, 26, 46, 66 };
/* 32 */     seed[14] = { 6, 26, 48, 70 };
/* 33 */     seed[15] = { 6, 26, 50, 74 };
/* 34 */     seed[16] = { 6, 30, 54, 78 };
/* 35 */     seed[17] = { 6, 30, 56, 82 };
/* 36 */     seed[18] = { 6, 30, 58, 86 };
/* 37 */     seed[19] = { 6, 34, 62, 90 };
/* 38 */     seed[20] = { 6, 28, 50, 72, 94 };
/* 39 */     seed[21] = { 6, 26, 50, 74, 98 };
/* 40 */     seed[22] = { 6, 30, 54, 78, 102 };
/* 41 */     seed[23] = { 6, 28, 54, 80, 106 };
/* 42 */     seed[24] = { 6, 32, 58, 84, 110 };
/* 43 */     seed[25] = { 6, 30, 58, 86, 114 };
/* 44 */     seed[26] = { 6, 34, 62, 90, 118 };
/* 45 */     seed[27] = { 6, 26, 50, 74, 98, 122 };
/* 46 */     seed[28] = { 6, 30, 54, 78, 102, 126 };
/* 47 */     seed[29] = { 6, 26, 52, 78, 104, 130 };
/* 48 */     seed[30] = { 6, 30, 56, 82, 108, 134 };
/* 49 */     seed[31] = { 6, 34, 60, 86, 112, 138 };
/* 50 */     seed[32] = { 6, 30, 58, 86, 114, 142 };
/* 51 */     seed[33] = { 6, 34, 62, 90, 118, 146 };
/* 52 */     seed[34] = { 6, 30, 54, 78, 102, 126, 150 };
/* 53 */     seed[35] = { 6, 24, 50, 76, 102, 128, 154 };
/* 54 */     seed[36] = { 6, 28, 54, 80, 106, 132, 158 };
/* 55 */     seed[37] = { 6, 32, 58, 84, 110, 136, 162 };
/* 56 */     seed[38] = { 6, 26, 54, 82, 110, 138, 166 };
/* 57 */     seed[39] = { 6, 30, 58, 86, 114, 142, 170 };
/*    */   }
/*    */ 
/*    */   public static int[] getSeed(int version)
/*    */     throws IndexOutOfBoundsException
/*    */   {
/* 65 */     return seed[(version - 1)];
/*    */   }
/*    */ 
/*    */   public static int getSeed(int version, int patternNumber)
/*    */     throws IndexOutOfBoundsException
/*    */   {
/* 73 */     return seed[(version - 1)][patternNumber];
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.pattern.LogicalSeed
 * JD-Core Version:    0.6.0
 */