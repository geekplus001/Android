/*     */ package jp.sourceforge.qrcode.pattern;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import jp.sourceforge.qrcode.QRCodeDecoder;
/*     */ import jp.sourceforge.qrcode.exception.FinderPatternNotFoundException;
/*     */ import jp.sourceforge.qrcode.exception.InvalidVersionException;
/*     */ import jp.sourceforge.qrcode.exception.InvalidVersionInfoException;
/*     */ import jp.sourceforge.qrcode.exception.VersionInformationException;
/*     */ import jp.sourceforge.qrcode.geom.Axis;
/*     */ import jp.sourceforge.qrcode.geom.Line;
/*     */ import jp.sourceforge.qrcode.geom.Point;
/*     */ import jp.sourceforge.qrcode.reader.QRCodeImageReader;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvas;
/*     */ 
/*     */ public class FinderPattern
/*     */ {
/*     */   public static final int UL = 0;
/*     */   public static final int UR = 1;
/*     */   public static final int DL = 2;
/*  21 */   static final int[] VersionInfoBit = { 
/*  22 */     31892, 34236, 39577, 42195, 48118, 51042, 55367, 
/*  23 */     58893, 63784, 68472, 70749, 76311, 79154, 84390, 
/*  24 */     87683, 92361, 96236, 102084, 102881, 110507, 110734, 
/*  25 */     117786, 119615, 126325, 127568, 133589, 136944, 141498, 
/*  26 */     145311, 150283, 152622, 158308, 161089, 167017 };
/*     */ 
/*  29 */   static DebugCanvas canvas = QRCodeDecoder.getCanvas();
/*     */   Point[] center;
/*     */   int version;
/*     */   int[] sincos;
/*     */   int[] width;
/*     */   int[] moduleSize;
/*     */ 
/*     */   public static FinderPattern findFinderPattern(boolean[][] image)
/*     */     throws FinderPatternNotFoundException, VersionInformationException
/*     */   {
/*  39 */     Line[] lineAcross = findLineAcross(image);
/*  40 */     Line[] lineCross = findLineCross(lineAcross);
/*  41 */     Point[] center = (Point[])null;
/*     */     try {
/*  43 */       center = getCenter(lineCross);
/*     */     } catch (FinderPatternNotFoundException e) {
/*  45 */       throw e;
/*     */     }
/*  47 */     int[] sincos = getAngle(center);
/*  48 */     center = sort(center, sincos);
/*  49 */     int[] width = getWidth(image, center, sincos);
/*     */ 
/*  51 */     int[] moduleSize = { (width[0] << QRCodeImageReader.DECIMAL_POINT) / 7, 
/*  52 */       (width[1] << QRCodeImageReader.DECIMAL_POINT) / 7, 
/*  53 */       (width[2] << QRCodeImageReader.DECIMAL_POINT) / 7 };
/*  54 */     int version = calcRoughVersion(center, width);
/*  55 */     if (version > 6) {
/*     */       try {
/*  57 */         version = calcExactVersion(center, sincos, moduleSize, image);
/*     */       }
/*     */       catch (VersionInformationException localVersionInformationException)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/*  64 */     return new FinderPattern(center, version, sincos, width, moduleSize);
/*     */   }
/*     */ 
/*     */   FinderPattern(Point[] center, int version, int[] sincos, int[] width, int[] moduleSize) {
/*  68 */     this.center = center;
/*  69 */     this.version = version;
/*  70 */     this.sincos = sincos;
/*  71 */     this.width = width;
/*  72 */     this.moduleSize = moduleSize;
/*     */   }
/*     */ 
/*     */   public Point[] getCenter() {
/*  76 */     return this.center;
/*     */   }
/*     */ 
/*     */   public Point getCenter(int position) {
/*  80 */     if ((position >= 0) && (position <= 2)) {
/*  81 */       return this.center[position];
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public int getWidth(int position) {
/*  87 */     return this.width[position];
/*     */   }
/*     */ 
/*     */   public int[] getAngle() {
/*  91 */     return this.sincos;
/*     */   }
/*     */ 
/*     */   public int getVersion() {
/*  95 */     return this.version;
/*     */   }
/*     */ 
/*     */   public int getModuleSize() {
/*  99 */     return this.moduleSize[0];
/*     */   }
/*     */   public int getModuleSize(int place) {
/* 102 */     return this.moduleSize[place];
/*     */   }
/*     */   public int getSqrtNumModules() {
/* 105 */     return 17 + 4 * this.version;
/*     */   }
/*     */ 
/*     */   static Line[] findLineAcross(boolean[][] image)
/*     */   {
/* 115 */     int READ_HORIZONTAL = 0;
/* 116 */     int READ_VERTICAL = 1;
/*     */ 
/* 118 */     int imageWidth = image.length;
/* 119 */     int imageHeight = image[0].length;
/*     */ 
/* 122 */     Point current = new Point();
/* 123 */     Vector lineAcross = new Vector();
/*     */ 
/* 126 */     int[] lengthBuffer = new int[5];
/* 127 */     int bufferPointer = 0;
/*     */ 
/* 129 */     int direction = 0;
/* 130 */     boolean lastElement = false;
/*     */     while (true)
/*     */     {
/* 134 */       boolean currentElement = image[current.getX()][current.getY()];
/* 135 */       if (currentElement == lastElement) {
/* 136 */         lengthBuffer[bufferPointer] += 1;
/*     */       }
/*     */       else {
/* 139 */         if ((!currentElement) && 
/* 140 */           (checkPattern(lengthBuffer, bufferPointer)))
/*     */         {
/*     */           int y1;
/*     */           int x2;
/*     */           int x1;
/*     */           int y1;
/*     */           int y2;
/* 142 */           if (direction == 0)
/*     */           {
/* 144 */             int x1 = current.getX();
/* 145 */             for (int j = 0; j < 5; j++) {
/* 146 */               x1 -= lengthBuffer[j];
/*     */             }
/* 148 */             int x2 = current.getX() - 1;
/*     */             int y2;
/* 149 */             y1 = y2 = current.getY();
/*     */           }
/*     */           else {
/* 152 */             x1 = x2 = current.getX();
/*     */ 
/* 155 */             y1 = current.getY();
/* 156 */             for (int j = 0; j < 5; j++) {
/* 157 */               y1 -= lengthBuffer[j];
/*     */             }
/* 159 */             y2 = current.getY() - 1;
/*     */           }
/* 161 */           lineAcross.addElement(new Line(x1, y1, x2, y2));
/*     */         }
/*     */ 
/* 164 */         bufferPointer = (bufferPointer + 1) % 5;
/* 165 */         lengthBuffer[bufferPointer] = 1;
/* 166 */         lastElement = !lastElement;
/*     */       }
/*     */ 
/* 170 */       if (direction == 0) {
/* 171 */         if (current.getX() < imageWidth - 1) {
/* 172 */           current.translate(1, 0); continue;
/*     */         }
/* 174 */         if (current.getY() < imageHeight - 1) {
/* 175 */           current.set(0, current.getY() + 1);
/* 176 */           lengthBuffer = new int[5]; continue;
/*     */         }
/*     */ 
/* 179 */         current.set(0, 0);
/* 180 */         lengthBuffer = new int[5];
/* 181 */         direction = 1; continue;
/*     */       }
/*     */ 
/* 185 */       if (current.getY() < imageHeight - 1) {
/* 186 */         current.translate(0, 1); continue;
/* 187 */       }if (current.getX() >= imageWidth - 1) break;
/* 188 */       current.set(current.getX() + 1, 0);
/* 189 */       lengthBuffer = new int[5];
/*     */     }
/*     */ 
/* 197 */     Line[] foundLines = new Line[lineAcross.size()];
/*     */ 
/* 199 */     for (int i = 0; i < foundLines.length; i++) {
/* 200 */       foundLines[i] = ((Line)lineAcross.elementAt(i));
/*     */     }
/* 202 */     canvas.drawLines(foundLines, 12320699);
/* 203 */     return foundLines;
/*     */   }
/*     */ 
/*     */   static boolean checkPattern(int[] buffer, int pointer) {
/* 207 */     int[] modelRatio = { 1, 1, 3, 1, 1 };
/*     */ 
/* 209 */     int baselength = 0;
/* 210 */     for (int i = 0; i < 5; i++) {
/* 211 */       baselength += buffer[i];
/*     */     }
/*     */ 
/* 214 */     baselength <<= QRCodeImageReader.DECIMAL_POINT;
/* 215 */     baselength /= 7;
/* 216 */     for (int i = 0; i < 5; i++) {
/* 217 */       int leastlength = baselength * modelRatio[i] - baselength / 2;
/* 218 */       int mostlength = baselength * modelRatio[i] + baselength / 2;
/*     */ 
/* 222 */       int targetlength = buffer[((pointer + i + 1) % 5)] << QRCodeImageReader.DECIMAL_POINT;
/* 223 */       if ((targetlength < leastlength) || (targetlength > mostlength)) {
/* 224 */         return false;
/*     */       }
/*     */     }
/* 227 */     return true;
/*     */   }
/*     */ 
/*     */   static Line[] findLineCross(Line[] lineAcross)
/*     */   {
/* 234 */     Vector crossLines = new Vector();
/* 235 */     Vector lineNeighbor = new Vector();
/* 236 */     Vector lineCandidate = new Vector();
/*     */ 
/* 238 */     for (int i = 0; i < lineAcross.length; i++) {
/* 239 */       lineCandidate.addElement(lineAcross[i]);
/*     */     }
/* 241 */     for (int i = 0; i < lineCandidate.size() - 1; i++) {
/* 242 */       lineNeighbor.removeAllElements();
/* 243 */       lineNeighbor.addElement(lineCandidate.elementAt(i));
/* 244 */       for (int j = i + 1; j < lineCandidate.size(); j++) {
/* 245 */         if (Line.isNeighbor((Line)lineNeighbor.lastElement(), (Line)lineCandidate.elementAt(j))) {
/* 246 */           lineNeighbor.addElement(lineCandidate.elementAt(j));
/* 247 */           Line compareLine = (Line)lineNeighbor.lastElement();
/* 248 */           if ((lineNeighbor.size() * 5 <= compareLine.getLength()) || 
/* 249 */             (j != lineCandidate.size() - 1)) continue;
/* 250 */           crossLines.addElement(lineNeighbor.elementAt(lineNeighbor.size() / 2));
/* 251 */           for (int k = 0; k < lineNeighbor.size(); k++)
/* 252 */             lineCandidate.removeElement(lineNeighbor.elementAt(k));
/*     */         }
/*     */         else
/*     */         {
/* 256 */           if ((!cantNeighbor((Line)lineNeighbor.lastElement(), (Line)lineCandidate.elementAt(j))) && 
/* 257 */             (j != lineCandidate.size() - 1)) continue;
/* 258 */           Line compareLine = (Line)lineNeighbor.lastElement();
/*     */ 
/* 263 */           if (lineNeighbor.size() * 6 <= compareLine.getLength()) break;
/* 264 */           crossLines.addElement(lineNeighbor.elementAt(lineNeighbor.size() / 2));
/* 265 */           for (int k = 0; k < lineNeighbor.size(); k++) {
/* 266 */             lineCandidate.removeElement(lineNeighbor.elementAt(k));
/*     */           }
/*     */ 
/* 269 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 274 */     Line[] foundLines = new Line[crossLines.size()];
/* 275 */     for (int i = 0; i < foundLines.length; i++) {
/* 276 */       foundLines[i] = ((Line)crossLines.elementAt(i));
/*     */     }
/* 278 */     return foundLines;
/*     */   }
/*     */ 
/*     */   static boolean cantNeighbor(Line line1, Line line2) {
/* 282 */     if (Line.isCross(line1, line2))
/* 283 */       return true;
/* 284 */     return Math.abs(line1.getP1().getY() - line2.getP1().getY()) > 1;
/*     */   }
/*     */ 
/*     */   static int[] getAngle(Point[] centers)
/*     */   {
/* 290 */     Line[] additionalLine = new Line[3];
/*     */ 
/* 292 */     for (int i = 0; i < additionalLine.length; i++) {
/* 293 */       additionalLine[i] = 
/* 294 */         new Line(centers[i], 
/* 294 */         centers[((i + 1) % additionalLine.length)]);
/*     */     }
/*     */ 
/* 297 */     Line remoteLine = Line.getLongest(additionalLine);
/* 298 */     Point originPoint = new Point();
/* 299 */     for (int i = 0; i < centers.length; i++) {
/* 300 */       if ((remoteLine.getP1().equals(centers[i])) || 
/* 301 */         (remoteLine.getP2().equals(centers[i]))) continue;
/* 302 */       originPoint = centers[i];
/* 303 */       break;
/*     */     }
/*     */ 
/* 306 */     canvas.println("originPoint is: " + originPoint);
/* 307 */     Point remotePoint = new Point();
/*     */ 
/* 312 */     if (((originPoint.getY() <= remoteLine.getP1().getY() ? 1 : 0) & (
/* 312 */       originPoint.getY() <= remoteLine.getP2().getY() ? 1 : 0)) != 0) {
/* 313 */       if (remoteLine.getP1().getX() < remoteLine.getP2().getX())
/* 314 */         remotePoint = remoteLine.getP2();
/*     */       else
/* 316 */         remotePoint = remoteLine.getP1();
/*     */     }
/* 318 */     else if (((originPoint.getX() >= remoteLine.getP1().getX() ? 1 : 0) & (
/* 318 */       originPoint.getX() >= remoteLine.getP2().getX() ? 1 : 0)) != 0) {
/* 319 */       if (remoteLine.getP1().getY() < remoteLine.getP2().getY())
/* 320 */         remotePoint = remoteLine.getP2();
/*     */       else
/* 322 */         remotePoint = remoteLine.getP1();
/*     */     }
/* 324 */     else if (((originPoint.getY() >= remoteLine.getP1().getY() ? 1 : 0) & (
/* 324 */       originPoint.getY() >= remoteLine.getP2().getY() ? 1 : 0)) != 0) {
/* 325 */       if (remoteLine.getP1().getX() < remoteLine.getP2().getX())
/* 326 */         remotePoint = remoteLine.getP1();
/*     */       else
/* 328 */         remotePoint = remoteLine.getP2();
/*     */     }
/* 330 */     else if (remoteLine.getP1().getY() < remoteLine.getP2().getY())
/* 331 */       remotePoint = remoteLine.getP1();
/*     */     else {
/* 333 */       remotePoint = remoteLine.getP2();
/*     */     }
/* 335 */     int r = new Line(originPoint, remotePoint).getLength();
/*     */ 
/* 337 */     int[] angle = new int[2];
/* 338 */     angle[0] = ((remotePoint.getY() - originPoint.getY() << QRCodeImageReader.DECIMAL_POINT) / r);
/* 339 */     angle[1] = ((remotePoint.getX() - originPoint.getX() << QRCodeImageReader.DECIMAL_POINT) / r);
/*     */ 
/* 341 */     return angle;
/*     */   }
/*     */ 
/*     */   static Point[] getCenter(Line[] crossLines) throws FinderPatternNotFoundException
/*     */   {
/* 346 */     Vector centers = new Vector();
/* 347 */     for (int i = 0; i < crossLines.length - 1; i++) {
/* 348 */       Line compareLine = crossLines[i];
/* 349 */       for (int j = i + 1; j < crossLines.length; j++) {
/* 350 */         Line comparedLine = crossLines[j];
/* 351 */         if (Line.isCross(compareLine, comparedLine)) {
/* 352 */           int x = 0;
/* 353 */           int y = 0;
/* 354 */           if (compareLine.isHorizontal()) {
/* 355 */             x = compareLine.getCenter().getX();
/* 356 */             y = comparedLine.getCenter().getY();
/*     */           }
/*     */           else {
/* 359 */             x = comparedLine.getCenter().getX();
/* 360 */             y = compareLine.getCenter().getY();
/*     */           }
/* 362 */           centers.addElement(new Point(x, y));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 367 */     Point[] foundPoints = new Point[centers.size()];
/*     */ 
/* 369 */     for (int i = 0; i < foundPoints.length; i++) {
/* 370 */       foundPoints[i] = ((Point)centers.elementAt(i));
/*     */     }
/*     */ 
/* 375 */     if (foundPoints.length == 3) {
/* 376 */       canvas.drawPolygon(foundPoints, 267946120);
/* 377 */       return foundPoints;
/*     */     }
/*     */ 
/* 380 */     throw new FinderPatternNotFoundException("Invalid number of Finder Pattern detected");
/*     */   }
/*     */ 
/*     */   static Point[] sort(Point[] centers, int[] angle)
/*     */   {
/* 386 */     Point[] sortedCenters = new Point[3];
/*     */ 
/* 388 */     int quadrant = getURQuadrant(angle);
/* 389 */     switch (quadrant) {
/*     */     case 1:
/* 391 */       sortedCenters[1] = getPointAtSide(centers, 1, 2);
/* 392 */       sortedCenters[2] = getPointAtSide(centers, 2, 4);
/* 393 */       break;
/*     */     case 2:
/* 395 */       sortedCenters[1] = getPointAtSide(centers, 2, 4);
/* 396 */       sortedCenters[2] = getPointAtSide(centers, 8, 4);
/* 397 */       break;
/*     */     case 3:
/* 399 */       sortedCenters[1] = getPointAtSide(centers, 4, 8);
/* 400 */       sortedCenters[2] = getPointAtSide(centers, 1, 8);
/* 401 */       break;
/*     */     case 4:
/* 403 */       sortedCenters[1] = getPointAtSide(centers, 8, 1);
/* 404 */       sortedCenters[2] = getPointAtSide(centers, 2, 1);
/*     */     }
/*     */ 
/* 409 */     for (int i = 0; i < centers.length; i++) {
/* 410 */       if ((centers[i].equals(sortedCenters[1])) || 
/* 411 */         (centers[i].equals(sortedCenters[2]))) continue;
/* 412 */       sortedCenters[0] = centers[i];
/*     */     }
/*     */ 
/* 416 */     return sortedCenters;
/*     */   }
/*     */ 
/*     */   static int getURQuadrant(int[] angle) {
/* 420 */     int sin = angle[0];
/* 421 */     int cos = angle[1];
/* 422 */     if ((sin >= 0) && (cos > 0))
/* 423 */       return 1;
/* 424 */     if ((sin > 0) && (cos <= 0))
/* 425 */       return 2;
/* 426 */     if ((sin <= 0) && (cos < 0))
/* 427 */       return 3;
/* 428 */     if ((sin < 0) && (cos >= 0)) {
/* 429 */       return 4;
/*     */     }
/* 431 */     return 0;
/*     */   }
/*     */ 
/*     */   static Point getPointAtSide(Point[] points, int side1, int side2) {
/* 435 */     Point sidePoint = new Point();
/* 436 */     int x = (side1 == 1) || (side2 == 1) ? 0 : 2147483647;
/* 437 */     int y = (side1 == 2) || (side2 == 2) ? 0 : 2147483647;
/* 438 */     sidePoint = new Point(x, y);
/*     */ 
/* 440 */     for (int i = 0; i < points.length; i++)
/* 441 */       switch (side1) {
/*     */       case 1:
/* 443 */         if (sidePoint.getX() < points[i].getX()) {
/* 444 */           sidePoint = points[i];
/*     */         } else {
/* 446 */           if (sidePoint.getX() != points[i].getX()) continue;
/* 447 */           if (side2 == 2) {
/* 448 */             if (sidePoint.getY() >= points[i].getY()) continue;
/* 449 */             sidePoint = points[i];
/*     */           }
/*     */           else
/*     */           {
/* 453 */             if (sidePoint.getY() <= points[i].getY()) continue;
/* 454 */             sidePoint = points[i];
/*     */           }
/*     */         }
/*     */ 
/* 458 */         break;
/*     */       case 2:
/* 460 */         if (sidePoint.getY() < points[i].getY()) {
/* 461 */           sidePoint = points[i];
/*     */         } else {
/* 463 */           if (sidePoint.getY() != points[i].getY()) continue;
/* 464 */           if (side2 == 1) {
/* 465 */             if (sidePoint.getX() >= points[i].getX()) continue;
/* 466 */             sidePoint = points[i];
/*     */           }
/*     */           else
/*     */           {
/* 470 */             if (sidePoint.getX() <= points[i].getX()) continue;
/* 471 */             sidePoint = points[i];
/*     */           }
/*     */         }
/*     */ 
/* 475 */         break;
/*     */       case 4:
/* 477 */         if (sidePoint.getX() > points[i].getX()) {
/* 478 */           sidePoint = points[i];
/*     */         } else {
/* 480 */           if (sidePoint.getX() != points[i].getX()) continue;
/* 481 */           if (side2 == 2) {
/* 482 */             if (sidePoint.getY() >= points[i].getY()) continue;
/* 483 */             sidePoint = points[i];
/*     */           }
/*     */           else
/*     */           {
/* 487 */             if (sidePoint.getY() <= points[i].getY()) continue;
/* 488 */             sidePoint = points[i];
/*     */           }
/*     */         }
/*     */ 
/* 492 */         break;
/*     */       case 8:
/* 494 */         if (sidePoint.getY() > points[i].getY()) {
/* 495 */           sidePoint = points[i];
/*     */         } else {
/* 497 */           if (sidePoint.getY() != points[i].getY()) continue;
/* 498 */           if (side2 == 1) {
/* 499 */             if (sidePoint.getX() >= points[i].getX()) continue;
/* 500 */             sidePoint = points[i];
/*     */           }
/*     */           else
/*     */           {
/* 504 */             if (sidePoint.getX() <= points[i].getX()) continue;
/* 505 */             sidePoint = points[i];
/*     */           }
/*     */         }
/*     */       case 3:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       }
/* 512 */     return sidePoint;
/*     */   }
/*     */ 
/*     */   static int[] getWidth(boolean[][] image, Point[] centers, int[] sincos)
/*     */     throws ArrayIndexOutOfBoundsException
/*     */   {
/* 518 */     int[] width = new int[3];
/*     */ 
/* 520 */     for (int i = 0; i < 3; i++) {
/* 521 */       boolean flag = false;
/*     */ 
/* 523 */       int y = centers[i].getY();
/* 524 */       for (int lx = centers[i].getX(); lx >= 0; lx--) {
/* 525 */         if ((image[lx][y] == 0) || 
/* 526 */           (image[(lx - 1)][y] != 0)) continue;
/* 527 */         if (flag) break; flag = true;
/*     */       }
/*     */ 
/* 531 */       flag = false;
/* 532 */       for (int rx = centers[i].getX(); rx < image.length; rx++) {
/* 533 */         if ((image[rx][y] == 0) || 
/* 534 */           (image[(rx + 1)][y] != 0)) continue;
/* 535 */         if (flag) break; flag = true;
/*     */       }
/*     */ 
/* 539 */       width[i] = (rx - lx + 1);
/*     */     }
/* 541 */     return width;
/*     */   }
/*     */ 
/*     */   static int calcRoughVersion(Point[] center, int[] width) {
/* 545 */     int dp = QRCodeImageReader.DECIMAL_POINT;
/* 546 */     int lengthAdditionalLine = new Line(center[0], center[1]).getLength() << dp;
/* 547 */     int avarageWidth = (width[0] + width[1] << dp) / 14;
/* 548 */     int roughVersion = (lengthAdditionalLine / avarageWidth - 10) / 4;
/* 549 */     if ((lengthAdditionalLine / avarageWidth - 10) % 4 >= 2) {
/* 550 */       roughVersion++;
/*     */     }
/*     */ 
/* 553 */     return roughVersion;
/*     */   }
/*     */ 
/*     */   static int calcExactVersion(Point[] centers, int[] angle, int[] moduleSize, boolean[][] image)
/*     */     throws InvalidVersionInfoException, InvalidVersionException
/*     */   {
/* 560 */     boolean[] versionInformation = new boolean[18];
/* 561 */     Point[] points = new Point[18];
/*     */ 
/* 563 */     Axis axis = new Axis(angle, moduleSize[1]);
/* 564 */     axis.setOrigin(centers[1]);
/*     */ 
/* 566 */     for (int y = 0; y < 6; y++) {
/* 567 */       for (int x = 0; x < 3; x++) {
/* 568 */         Point target = axis.translate(x - 7, y - 3);
/* 569 */         versionInformation[(x + y * 3)] = image[target.getX()][target.getY()];
/* 570 */         points[(x + y * 3)] = target;
/*     */       }
/*     */     }
/* 573 */     canvas.drawPoints(points, 267946120);
/*     */ 
/* 575 */     int exactVersion = 0;
/*     */     try {
/* 577 */       exactVersion = checkVersionInfo(versionInformation);
/*     */     } catch (InvalidVersionInfoException e) {
/* 579 */       canvas.println("Version info error. now retry with other place one.");
/* 580 */       axis.setOrigin(centers[2]);
/* 581 */       axis.setModulePitch(moduleSize[2]);
/*     */ 
/* 583 */       for (int x = 0; x < 6; x++) {
/* 584 */         for (int y = 0; y < 3; y++) {
/* 585 */           Point target = axis.translate(x - 3, y - 7);
/* 586 */           versionInformation[(y + x * 3)] = image[target.getX()][target.getY()];
/* 587 */           points[(x + y * 3)] = target;
/*     */         }
/*     */       }
/* 590 */       canvas.drawPoints(points, 267946120);
/*     */       try
/*     */       {
/* 593 */         exactVersion = checkVersionInfo(versionInformation);
/*     */       } catch (VersionInformationException e2) {
/* 595 */         throw e2;
/*     */       }
/*     */     }
/* 598 */     return exactVersion;
/*     */   }
/*     */ 
/*     */   static int checkVersionInfo(boolean[] target)
/*     */     throws InvalidVersionInfoException
/*     */   {
/* 605 */     int errorCount = 0;
/* 606 */     for (int versionBase = 0; versionBase < VersionInfoBit.length; versionBase++) {
/* 607 */       errorCount = 0;
/* 608 */       for (int j = 0; j < 18; j++) {
/* 609 */         if ((target[j] ^ ((VersionInfoBit[versionBase] >> j) % 2 == 1 ? 1 : 0)) != 0)
/* 610 */           errorCount++;
/*     */       }
/* 612 */       if (errorCount <= 3) break;
/*     */     }
/* 614 */     if (errorCount <= 3) {
/* 615 */       return 7 + versionBase;
/*     */     }
/* 617 */     throw new InvalidVersionInfoException("Too many errors in version information");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.pattern.FinderPattern
 * JD-Core Version:    0.6.0
 */