/*     */ package jp.sourceforge.qrcode;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import jp.sourceforge.qrcode.data.QRCodeImage;
/*     */ import jp.sourceforge.qrcode.data.QRCodeSymbol;
/*     */ import jp.sourceforge.qrcode.exception.DecodingFailedException;
/*     */ import jp.sourceforge.qrcode.exception.InvalidDataBlockException;
/*     */ import jp.sourceforge.qrcode.exception.SymbolNotFoundException;
/*     */ import jp.sourceforge.qrcode.geom.Point;
/*     */ import jp.sourceforge.qrcode.reader.QRCodeDataBlockReader;
/*     */ import jp.sourceforge.qrcode.reader.QRCodeImageReader;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvas;
/*     */ import jp.sourceforge.qrcode.util.DebugCanvasAdapter;
/*     */ import jp.sourceforge.reedsolomon.RsDecode;
/*     */ 
/*     */ public class QRCodeDecoder
/*     */ {
/*     */   int numTryDecode;
/*     */   QRCodeSymbol qrCodeSymbol;
/*     */   Vector results;
/*  25 */   Vector lastResults = new Vector();
/*     */   static DebugCanvas canvas;
/*     */   QRCodeImageReader imageReader;
/*     */   int numLastCorrectionFailures;
/*     */ 
/*     */   public static void setCanvas(DebugCanvas canvas)
/*     */   {
/*  49 */     canvas = canvas;
/*     */   }
/*     */ 
/*     */   public static DebugCanvas getCanvas() {
/*  53 */     return canvas;
/*     */   }
/*     */ 
/*     */   public QRCodeDecoder() {
/*  57 */     this.numTryDecode = 0;
/*  58 */     this.results = new Vector();
/*  59 */     canvas = new DebugCanvasAdapter();
/*     */   }
/*     */ 
/*     */   public byte[] decode(QRCodeImage qrCodeImage) throws DecodingFailedException {
/*  63 */     Point[] adjusts = getAdjustPoints();
/*  64 */     Vector results = new Vector();
/*  65 */     this.numTryDecode = 0;
/*  66 */     while (this.numTryDecode < adjusts.length) {
/*     */       try {
/*  68 */         DecodeResult result = decode(qrCodeImage, adjusts[this.numTryDecode]);
/*  69 */         if (result.isCorrectionSucceeded())
/*  70 */           return result.getDecodedBytes();
/*     */         DecodeResult result;
/*  73 */         results.addElement(result);
/*  74 */         canvas.println("Decoding succeeded but could not correct");
/*  75 */         canvas.println("all errors. Retrying..");
/*     */       }
/*     */       catch (DecodingFailedException dfe) {
/*  78 */         if (dfe.getMessage().indexOf("Finder Pattern") >= 0)
/*  79 */           throw dfe;
/*     */       } finally {
/*  81 */         this.numTryDecode += 1;
/*     */       }
/*     */     }
/*     */ 
/*  85 */     if (results.size() == 0) {
/*  86 */       throw new DecodingFailedException("Give up decoding");
/*     */     }
/*  88 */     int minErrorIndex = -1;
/*  89 */     int minError = 2147483647;
/*  90 */     for (int i = 0; i < results.size(); i++) {
/*  91 */       DecodeResult result = (DecodeResult)results.elementAt(i);
/*  92 */       if (result.getNumCorrectuionFailures() < minError) {
/*  93 */         minError = result.getNumCorrectuionFailures();
/*  94 */         minErrorIndex = i;
/*     */       }
/*     */     }
/*  97 */     canvas.println("All trials need for correct error");
/*  98 */     canvas.println("Reporting #" + minErrorIndex + " that,");
/*  99 */     canvas.println("corrected minimum errors (" + minError + ")");
/* 100 */     canvas.println("Decoding finished.");
/* 101 */     return ((DecodeResult)results.elementAt(minErrorIndex)).getDecodedBytes();
/*     */   }
/*     */ 
/*     */   Point[] getAdjustPoints()
/*     */   {
/* 110 */     Vector adjustPoints = new Vector();
/* 111 */     for (int d = 0; d < 4; d++)
/* 112 */       adjustPoints.addElement(new Point(1, 1));
/* 113 */     int lastX = 0; int lastY = 0;
/* 114 */     for (int y = 0; y > -4; y--) {
/* 115 */       for (int x = 0; x > -4; x--) {
/* 116 */         if ((x != y) && ((x + y) % 2 == 0)) {
/* 117 */           adjustPoints.addElement(new Point(x - lastX, y - lastY));
/* 118 */           lastX = x;
/* 119 */           lastY = y;
/*     */         }
/*     */       }
/*     */     }
/* 123 */     Point[] adjusts = new Point[adjustPoints.size()];
/* 124 */     for (int i = 0; i < adjusts.length; i++)
/* 125 */       adjusts[i] = ((Point)adjustPoints.elementAt(i));
/* 126 */     return adjusts;
/*     */   }
/*     */ 
/*     */   DecodeResult decode(QRCodeImage qrCodeImage, Point adjust) throws DecodingFailedException
/*     */   {
/*     */     try {
/* 132 */       if (this.numTryDecode == 0) {
/* 133 */         canvas.println("Decoding started");
/* 134 */         int[][] intImage = imageToIntArray(qrCodeImage);
/* 135 */         this.imageReader = new QRCodeImageReader();
/* 136 */         this.qrCodeSymbol = this.imageReader.getQRCodeSymbol(intImage);
/*     */       } else {
/* 138 */         canvas.println("--");
/* 139 */         canvas.println("Decoding restarted #" + this.numTryDecode);
/* 140 */         this.qrCodeSymbol = this.imageReader.getQRCodeSymbolWithAdjustedGrid(adjust);
/*     */       }
/*     */     } catch (SymbolNotFoundException e) {
/* 143 */       throw new DecodingFailedException(e.getMessage());
/*     */     }
/* 145 */     canvas.println("Created QRCode symbol.");
/* 146 */     canvas.println("Reading symbol.");
/* 147 */     canvas.println("Version: " + this.qrCodeSymbol.getVersionReference());
/* 148 */     canvas.println("Mask pattern: " + this.qrCodeSymbol.getMaskPatternRefererAsString());
/*     */ 
/* 150 */     int[] blocks = this.qrCodeSymbol.getBlocks();
/* 151 */     canvas.println("Correcting data errors.");
/*     */ 
/* 153 */     blocks = correctDataBlocks(blocks);
/*     */     try
/*     */     {
/* 156 */       byte[] decodedByteArray = 
/* 157 */         getDecodedByteArray(blocks, this.qrCodeSymbol.getVersion(), this.qrCodeSymbol.getNumErrorCollectionCode());
/* 158 */       return new DecodeResult(decodedByteArray, this.numLastCorrectionFailures);
/*     */     } catch (InvalidDataBlockException e) {
/* 160 */       canvas.println(e.getMessage());
/* 161 */     }throw new DecodingFailedException(e.getMessage());
/*     */   }
/*     */ 
/*     */   int[][] imageToIntArray(QRCodeImage image)
/*     */   {
/* 167 */     int width = image.getWidth();
/* 168 */     int height = image.getHeight();
/* 169 */     int[][] intImage = new int[width][height];
/* 170 */     for (int y = 0; y < height; y++) {
/* 171 */       for (int x = 0; x < width; x++) {
/* 172 */         intImage[x][y] = image.getPixel(x, y);
/*     */       }
/*     */     }
/* 175 */     return intImage;
/*     */   }
/*     */ 
/*     */   int[] correctDataBlocks(int[] blocks) {
/* 179 */     int numSucceededCorrections = 0;
/* 180 */     int numCorrectionFailures = 0;
/* 181 */     int dataCapacity = this.qrCodeSymbol.getDataCapacity();
/* 182 */     int[] dataBlocks = new int[dataCapacity];
/* 183 */     int numErrorCollectionCode = this.qrCodeSymbol.getNumErrorCollectionCode();
/* 184 */     int numRSBlocks = this.qrCodeSymbol.getNumRSBlocks();
/* 185 */     int eccPerRSBlock = numErrorCollectionCode / numRSBlocks;
/* 186 */     if (numRSBlocks == 1) {
/* 187 */       RsDecode corrector = new RsDecode(eccPerRSBlock / 2);
/* 188 */       int ret = corrector.decode(blocks);
/* 189 */       if (ret > 0)
/* 190 */         numSucceededCorrections += ret;
/* 191 */       else if (ret < 0)
/* 192 */         numCorrectionFailures++;
/* 193 */       return blocks;
/*     */     }
/*     */ 
/* 196 */     int numLongerRSBlocks = dataCapacity % numRSBlocks;
/* 197 */     if (numLongerRSBlocks == 0) {
/* 198 */       int lengthRSBlock = dataCapacity / numRSBlocks;
/* 199 */       int[][] RSBlocks = new int[numRSBlocks][lengthRSBlock];
/*     */ 
/* 201 */       for (int i = 0; i < numRSBlocks; i++) {
/* 202 */         for (int j = 0; j < lengthRSBlock; j++) {
/* 203 */           RSBlocks[i][j] = blocks[(j * numRSBlocks + i)];
/*     */         }
/* 205 */         canvas.println("eccPerRSBlock=" + eccPerRSBlock);
/* 206 */         RsDecode corrector = new RsDecode(eccPerRSBlock / 2);
/* 207 */         int ret = corrector.decode(RSBlocks[i]);
/* 208 */         if (ret > 0)
/* 209 */           numSucceededCorrections += ret;
/* 210 */         else if (ret < 0) {
/* 211 */           numCorrectionFailures++;
/*     */         }
/*     */       }
/* 214 */       int p = 0;
/* 215 */       for (int i = 0; i < numRSBlocks; i++) {
/* 216 */         for (int j = 0; j < lengthRSBlock - eccPerRSBlock; j++)
/* 217 */           dataBlocks[(p++)] = RSBlocks[i][j];
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 222 */       int lengthShorterRSBlock = dataCapacity / numRSBlocks;
/* 223 */       int lengthLongerRSBlock = dataCapacity / numRSBlocks + 1;
/* 224 */       int numShorterRSBlocks = numRSBlocks - numLongerRSBlocks;
/* 225 */       int[][] shorterRSBlocks = new int[numShorterRSBlocks][lengthShorterRSBlock];
/* 226 */       int[][] longerRSBlocks = new int[numLongerRSBlocks][lengthLongerRSBlock];
/* 227 */       for (int i = 0; i < numRSBlocks; i++) {
/* 228 */         if (i < numShorterRSBlocks) {
/* 229 */           int mod = 0;
/* 230 */           for (int j = 0; j < lengthShorterRSBlock; j++) {
/* 231 */             if (j == lengthShorterRSBlock - eccPerRSBlock) mod = numLongerRSBlocks;
/* 232 */             shorterRSBlocks[i][j] = blocks[(j * numRSBlocks + i + mod)];
/*     */           }
/* 234 */           canvas.println("eccPerRSBlock(shorter)=" + eccPerRSBlock);
/* 235 */           RsDecode corrector = new RsDecode(eccPerRSBlock / 2);
/* 236 */           int ret = corrector.decode(shorterRSBlocks[i]);
/* 237 */           if (ret > 0)
/* 238 */             numSucceededCorrections += ret;
/* 239 */           else if (ret < 0)
/* 240 */             numCorrectionFailures++;
/*     */         }
/*     */         else
/*     */         {
/* 244 */           int mod = 0;
/* 245 */           for (int j = 0; j < lengthLongerRSBlock; j++) {
/* 246 */             if (j == lengthShorterRSBlock - eccPerRSBlock) mod = numShorterRSBlocks;
/* 247 */             longerRSBlocks[(i - numShorterRSBlocks)][j] = blocks[(j * numRSBlocks + i - mod)];
/*     */           }
/* 249 */           canvas.println("eccPerRSBlock(longer)=" + eccPerRSBlock);
/* 250 */           RsDecode corrector = new RsDecode(eccPerRSBlock / 2);
/* 251 */           int ret = corrector.decode(longerRSBlocks[(i - numShorterRSBlocks)]);
/* 252 */           if (ret > 0)
/* 253 */             numSucceededCorrections += ret;
/* 254 */           else if (ret < 0)
/* 255 */             numCorrectionFailures++;
/*     */         }
/*     */       }
/* 258 */       int p = 0;
/* 259 */       for (int i = 0; i < numRSBlocks; i++) {
/* 260 */         if (i < numShorterRSBlocks) {
/* 261 */           for (int j = 0; j < lengthShorterRSBlock - eccPerRSBlock; j++) {
/* 262 */             dataBlocks[(p++)] = shorterRSBlocks[i][j];
/*     */           }
/*     */         }
/*     */         else {
/* 266 */           for (int j = 0; j < lengthLongerRSBlock - eccPerRSBlock; j++) {
/* 267 */             dataBlocks[(p++)] = longerRSBlocks[(i - numShorterRSBlocks)][j];
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 272 */     if (numSucceededCorrections > 0)
/* 273 */       canvas.println(String.valueOf(numSucceededCorrections) + " data errors corrected successfully.");
/*     */     else
/* 275 */       canvas.println("No errors found.");
/* 276 */     this.numLastCorrectionFailures = numCorrectionFailures;
/* 277 */     return dataBlocks;
/*     */   }
/*     */ 
/*     */   byte[] getDecodedByteArray(int[] blocks, int version, int numErrorCorrectionCode)
/*     */     throws InvalidDataBlockException
/*     */   {
/* 283 */     QRCodeDataBlockReader reader = new QRCodeDataBlockReader(blocks, version, numErrorCorrectionCode);
/*     */     try {
/* 285 */       byteArray = reader.getDataByte();
/*     */     }
/*     */     catch (InvalidDataBlockException e)
/*     */     {
/*     */       byte[] byteArray;
/* 287 */       throw e;
/*     */     }
/*     */     byte[] byteArray;
/* 289 */     return byteArray;
/*     */   }
/*     */ 
/*     */   class DecodeResult
/*     */   {
/*     */     int numCorrectionFailures;
/*     */     byte[] decodedBytes;
/*     */ 
/*     */     public DecodeResult(byte[] decodedBytes, int numCorrectionFailures)
/*     */     {
/*  34 */       this.decodedBytes = decodedBytes;
/*  35 */       this.numCorrectionFailures = numCorrectionFailures;
/*     */     }
/*     */     public byte[] getDecodedBytes() {
/*  38 */       return this.decodedBytes;
/*     */     }
/*     */     public int getNumCorrectuionFailures() {
/*  41 */       return this.numCorrectionFailures;
/*     */     }
/*     */     public boolean isCorrectionSucceeded() {
/*  44 */       return QRCodeDecoder.this.numLastCorrectionFailures == 0;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.qrcode.QRCodeDecoder
 * JD-Core Version:    0.6.0
 */