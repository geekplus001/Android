/*     */ package jp.sourceforge.reedsolomon;
/*     */ 
/*     */ public class RsDecode
/*     */ {
/*     */   public static final int RS_PERM_ERROR = -1;
/*     */   public static final int RS_CORRECT_ERROR = -2;
/*  12 */   private static final Galois galois = Galois.getInstance();
/*     */   private int npar;
/*     */ 
/*     */   public RsDecode(int npar)
/*     */   {
/*  16 */     this.npar = npar;
/*     */   }
/*     */ 
/*     */   public int calcSigmaMBM(int[] sigma, int[] omega, int[] syn)
/*     */   {
/*  36 */     int[] sg0 = new int[this.npar];
/*  37 */     int[] sg1 = new int[this.npar];
/*  38 */     sg0[1] = 1;
/*  39 */     sg1[0] = 1;
/*  40 */     int jisu0 = 1;
/*  41 */     int jisu1 = 0;
/*  42 */     int m = -1;
/*     */ 
/*  44 */     for (int n = 0; n < this.npar; n++)
/*     */     {
/*  46 */       int d = syn[n];
/*  47 */       for (int i = 1; i <= jisu1; i++) {
/*  48 */         d ^= galois.mul(sg1[i], syn[(n - i)]);
/*     */       }
/*  50 */       if (d != 0) {
/*  51 */         int logd = galois.toLog(d);
/*  52 */         int[] wk = new int[this.npar];
/*  53 */         for (int i = 0; i <= n; i++) {
/*  54 */           sg1[i] ^= galois.mulExp(sg0[i], logd);
/*     */         }
/*  56 */         int js = n - m;
/*  57 */         if (js > jisu1) {
/*  58 */           m = n - jisu1;
/*  59 */           jisu1 = js;
/*  60 */           if (jisu1 > this.npar / 2) {
/*  61 */             return -1;
/*     */           }
/*  63 */           for (int i = 0; i <= jisu0; i++) {
/*  64 */             sg0[i] = galois.divExp(sg1[i], logd);
/*     */           }
/*  66 */           jisu0 = jisu1;
/*     */         }
/*  68 */         sg1 = wk;
/*     */       }
/*  70 */       System.arraycopy(sg0, 0, sg0, 1, Math.min(sg0.length - 1, jisu0));
/*  71 */       sg0[0] = 0;
/*  72 */       jisu0++;
/*     */     }
/*  74 */     galois.mulPoly(omega, sg1, syn);
/*  75 */     System.arraycopy(sg1, 0, sigma, 0, Math.min(sg1.length, sigma.length));
/*  76 */     return jisu1;
/*     */   }
/*     */ 
/*     */   private int chienSearch(int[] pos, int n, int jisu, int[] sigma)
/*     */   {
/* 104 */     int last = sigma[1];
/*     */ 
/* 106 */     if (jisu == 1)
/*     */     {
/* 108 */       if (galois.toLog(last) >= n) {
/* 109 */         return -2;
/*     */       }
/* 111 */       pos[0] = last;
/* 112 */       return 0;
/*     */     }
/*     */ 
/* 115 */     int posIdx = jisu - 1;
/* 116 */     for (int i = 0; i < n; i++)
/*     */     {
/* 124 */       int z = 255 - i;
/* 125 */       int wk = 1;
/* 126 */       for (int j = 1; j <= jisu; j++) {
/* 127 */         wk ^= galois.mulExp(sigma[j], z * j % 255);
/*     */       }
/* 129 */       if (wk == 0) {
/* 130 */         int pv = galois.toExp(i);
/* 131 */         last ^= pv;
/* 132 */         pos[(posIdx--)] = pv;
/* 133 */         if (posIdx != 0)
/*     */           continue;
/* 135 */         if (galois.toLog(last) >= n) {
/* 136 */           return -2;
/*     */         }
/* 138 */         pos[0] = last;
/* 139 */         return 0;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 144 */     return -2;
/*     */   }
/*     */ 
/*     */   private void doForney(int[] data, int length, int jisu, int[] pos, int[] sigma, int[] omega)
/*     */   {
/* 172 */     for (int i = 0; i < jisu; i++) {
/* 173 */       int ps = pos[i];
/* 174 */       int zlog = 255 - galois.toLog(ps);
/*     */ 
/* 177 */       int ov = omega[0];
/* 178 */       for (int j = 1; j < jisu; j++) {
/* 179 */         ov ^= galois.mulExp(omega[j], zlog * j % 255);
/*     */       }
/*     */ 
/* 183 */       int dv = sigma[1];
/* 184 */       for (int j = 2; j < jisu; j += 2) {
/* 185 */         dv ^= galois.mulExp(sigma[(j + 1)], zlog * j % 255);
/*     */       }
/*     */ 
/* 193 */       data[galois.toPos(length, ps)] ^= galois.mul(ps, galois.div(ov, dv));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int decode(int[] data, int length, boolean noCorrect)
/*     */   {
/* 212 */     if ((length < this.npar) || (length > 255)) {
/* 213 */       return -1;
/*     */     }
/*     */ 
/* 216 */     int[] syn = new int[this.npar];
/* 217 */     if (galois.calcSyndrome(data, length, syn)) {
/* 218 */       return 0;
/*     */     }
/*     */ 
/* 221 */     int[] sigma = new int[this.npar / 2 + 2];
/* 222 */     int[] omega = new int[this.npar / 2 + 1];
/* 223 */     int jisu = calcSigmaMBM(sigma, omega, syn);
/* 224 */     if (jisu <= 0) {
/* 225 */       return -2;
/*     */     }
/*     */ 
/* 228 */     int[] pos = new int[jisu];
/* 229 */     int r = chienSearch(pos, length, jisu, sigma);
/* 230 */     if (r < 0) {
/* 231 */       return r;
/*     */     }
/* 233 */     if (!noCorrect)
/*     */     {
/* 235 */       doForney(data, length, jisu, pos, sigma, omega);
/*     */     }
/* 237 */     return jisu;
/*     */   }
/*     */ 
/*     */   public int decode(int[] data, int length) {
/* 241 */     return decode(data, length, false);
/*     */   }
/*     */ 
/*     */   public int decode(int[] data) {
/* 245 */     return decode(data, data.length, false);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.reedsolomon.RsDecode
 * JD-Core Version:    0.6.0
 */