/*    */ package jp.sourceforge.reedsolomon;
/*    */ 
/*    */ public final class BCH_15_5
/*    */ {
/*    */   private static final int GX = 311;
/* 11 */   private static final BCH_15_5 instance = new BCH_15_5();
/* 12 */   private int[] trueCodes = new int[32];
/*    */ 
/*    */   private BCH_15_5() {
/* 15 */     makeTrueCodes();
/*    */   }
/*    */ 
/*    */   public static BCH_15_5 getInstance() {
/* 19 */     return instance;
/*    */   }
/*    */ 
/*    */   private void makeTrueCodes()
/*    */   {
/* 26 */     for (int i = 0; i < this.trueCodes.length; i++)
/* 27 */       this.trueCodes[i] = slowEncode(i);
/*    */   }
/*    */ 
/*    */   private int slowEncode(int data)
/*    */   {
/* 32 */     int wk = 0;
/* 33 */     data <<= 5;
/* 34 */     for (int i = 0; i < 5; i++) {
/* 35 */       wk <<= 1;
/* 36 */       data <<= 1;
/* 37 */       if (((wk ^ data) & 0x400) != 0) {
/* 38 */         wk ^= 311;
/*    */       }
/*    */     }
/* 41 */     return data & 0x7C00 | wk & 0x3FF;
/*    */   }
/*    */ 
/*    */   public int encode(int data) {
/* 45 */     return this.trueCodes[(data & 0x1F)];
/*    */   }
/*    */ 
/*    */   private static int calcDistance(int c1, int c2)
/*    */   {
/* 56 */     int n = 0;
/* 57 */     int wk = c1 ^ c2;
/* 58 */     while (wk != 0) {
/* 59 */       if ((wk & 0x1) != 0) {
/* 60 */         n++;
/*    */       }
/* 62 */       wk >>= 1;
/*    */     }
/* 64 */     return n;
/*    */   }
/*    */ 
/*    */   public int decode(int data)
/*    */   {
/* 77 */     data &= 32767;
/*    */ 
/* 86 */     for (int i = 0; i < this.trueCodes.length; i++) {
/* 87 */       int code = this.trueCodes[i];
/* 88 */       if (calcDistance(data, code) <= 3) {
/* 89 */         return code;
/*    */       }
/*    */     }
/* 92 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.reedsolomon.BCH_15_5
 * JD-Core Version:    0.6.0
 */