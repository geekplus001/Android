/*    */ package jp.sourceforge.reedsolomon;
/*    */ 
/*    */ public class RsEncode
/*    */ {
/*    */   public static final int RS_PERM_ERROR = -1;
/* 11 */   private static final Galois galois = Galois.getInstance();
/*    */   private int npar;
/*    */   private int[] encodeGx;
/*    */ 
/*    */   public RsEncode(int npar)
/*    */   {
/* 16 */     this.npar = npar;
/* 17 */     makeEncodeGx();
/*    */   }
/*    */ 
/*    */   private void makeEncodeGx()
/*    */   {
/* 30 */     this.encodeGx = new int[this.npar];
/* 31 */     this.encodeGx[(this.npar - 1)] = 1;
/* 32 */     for (int kou = 0; kou < this.npar; kou++) {
/* 33 */       int ex = galois.toExp(kou);
/*    */ 
/* 35 */       for (int i = 0; i < this.npar - 1; i++)
/*    */       {
/* 37 */         this.encodeGx[i] = (galois.mul(this.encodeGx[i], ex) ^ this.encodeGx[(i + 1)]);
/*    */       }
/* 39 */       this.encodeGx[(this.npar - 1)] = galois.mul(this.encodeGx[(this.npar - 1)], ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public int encode(int[] data, int length, int[] parity, int parityStartPos)
/*    */   {
/* 59 */     if ((length < 0) || (length + this.npar > 255)) {
/* 60 */       return -1;
/*    */     }
/*    */ 
/* 69 */     int[] wr = new int[this.npar];
/*    */ 
/* 71 */     for (int idx = 0; idx < length; idx++) {
/* 72 */       int code = data[idx];
/* 73 */       int ib = wr[0] ^ code;
/* 74 */       for (int i = 0; i < this.npar - 1; i++) {
/* 75 */         wr[i] = (wr[(i + 1)] ^ galois.mul(ib, this.encodeGx[i]));
/*    */       }
/* 77 */       wr[(this.npar - 1)] = galois.mul(ib, this.encodeGx[(this.npar - 1)]);
/*    */     }
/* 79 */     if (parity != null) {
/* 80 */       System.arraycopy(wr, 0, parity, parityStartPos, this.npar);
/*    */     }
/* 82 */     return 0;
/*    */   }
/*    */ 
/*    */   public int encode(int[] data, int length, int[] parity) {
/* 86 */     return encode(data, length, parity, 0);
/*    */   }
/*    */ 
/*    */   public int encode(int[] data, int[] parity) {
/* 90 */     return encode(data, data.length, parity, 0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.reedsolomon.RsEncode
 * JD-Core Version:    0.6.0
 */