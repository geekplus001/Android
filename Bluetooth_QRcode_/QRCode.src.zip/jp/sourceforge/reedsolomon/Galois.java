/*     */ package jp.sourceforge.reedsolomon;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public final class Galois
/*     */ {
/*     */   public static final int POLYNOMIAL = 29;
/*  13 */   private static final Galois instance = new Galois();
/*  14 */   private int[] expTbl = new int[510];
/*  15 */   private int[] logTbl = new int[256];
/*     */ 
/*     */   private Galois() {
/*  18 */     initGaloisTable();
/*     */   }
/*     */ 
/*     */   public static Galois getInstance() {
/*  22 */     return instance;
/*     */   }
/*     */ 
/*     */   private void initGaloisTable()
/*     */   {
/*  29 */     int d = 1;
/*  30 */     for (int i = 0; i < 255; i++)
/*     */     {
/*     */       int tmp22_21 = d; this.expTbl[(255 + i)] = tmp22_21; this.expTbl[i] = tmp22_21;
/*  32 */       this.logTbl[d] = i;
/*  33 */       d <<= 1;
/*  34 */       if ((d & 0x100) != 0)
/*  35 */         d = (d ^ 0x1D) & 0xFF;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int toExp(int a)
/*     */   {
/*  47 */     return this.expTbl[a];
/*     */   }
/*     */ 
/*     */   public int toLog(int a)
/*     */   {
/*  57 */     return this.logTbl[a];
/*     */   }
/*     */ 
/*     */   public int toPos(int length, int a)
/*     */   {
/*  71 */     return length - 1 - this.logTbl[a];
/*     */   }
/*     */ 
/*     */   public int mul(int a, int b)
/*     */   {
/*  83 */     return (a == 0) || (b == 0) ? 0 : this.expTbl[(this.logTbl[a] + this.logTbl[b])];
/*     */   }
/*     */ 
/*     */   public int mulExp(int a, int b)
/*     */   {
/*  95 */     return a == 0 ? 0 : this.expTbl[(this.logTbl[a] + b)];
/*     */   }
/*     */ 
/*     */   public int div(int a, int b)
/*     */   {
/* 107 */     return a == 0 ? 0 : this.expTbl[(this.logTbl[a] - this.logTbl[b] + 255)];
/*     */   }
/*     */ 
/*     */   public int divExp(int a, int b)
/*     */   {
/* 119 */     return a == 0 ? 0 : this.expTbl[(this.logTbl[a] - b + 255)];
/*     */   }
/*     */ 
/*     */   public int inv(int a)
/*     */   {
/* 130 */     return this.expTbl[(255 - this.logTbl[a])];
/*     */   }
/*     */ 
/*     */   public void mulPoly(int[] seki, int[] a, int[] b)
/*     */   {
/* 142 */     Arrays.fill(seki, 0);
/* 143 */     for (int ia = 0; ia < a.length; ia++)
/* 144 */       if (a[ia] != 0) {
/* 145 */         int loga = this.logTbl[a[ia]];
/* 146 */         int ib2 = Math.min(b.length, seki.length - ia);
/* 147 */         for (int ib = 0; ib < ib2; ib++)
/* 148 */           if (b[ib] != 0)
/* 149 */             seki[(ia + ib)] ^= this.expTbl[(loga + this.logTbl[b[ib]])];
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean calcSyndrome(int[] data, int length, int[] syn)
/*     */   {
/* 168 */     int hasErr = 0;
/* 169 */     for (int i = 0; i < syn.length; i++) {
/* 170 */       int wk = 0;
/* 171 */       for (int idx = 0; idx < length; idx++) {
/* 172 */         wk = data[idx] ^ (wk == 0 ? 0 : this.expTbl[(this.logTbl[wk] + i)]);
/*     */       }
/* 174 */       syn[i] = wk;
/* 175 */       hasErr |= wk;
/*     */     }
/* 177 */     return hasErr == 0;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\QRCode.jar
 * Qualified Name:     jp.sourceforge.reedsolomon.Galois
 * JD-Core Version:    0.6.0
 */